/**
 * Webina Copyright 2019 Jacob Durrant
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
(self["webpackChunkwebina"] = self["webpackChunkwebina"] || []).push([[143],{

/***/ 896:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


;// CONCATENATED MODULE: ./src/Utils.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
// For functions that don't really need to be within the Vue framework.
/**
 * Creates a new object with a property updated.
 * @param  {any}    obj  The original object.
 * @param  {string} key  The new key.
 * @param  {any}    val  The new value.
 * @returns any  A new object with the key/value updated.
 */
function getNewObjWithUpdate(obj, key, val) {
    let newObj = {};
    const keys = Object.keys(obj);
    const keysLen = keys.length;
    for (let i = 0; i < keysLen; i++) {
        const k = keys[i];
        const v = obj[k];
        if ((v !== undefined) && (v !== null) && (!isNaN(v))) {
            newObj[k] = v;
        }
    }
    newObj[key] = val;
    return newObj;
}
/**
 * Detect whether webassembly is supported.
 * @returns boolean  True if supported. False otherwise
 */
function webAssemblySupported() {
    // https://stackoverflow.com/questions/47879864/how-can-i-check-if-a-browser-supports-webassembly
    try {
        if (typeof WebAssembly === "object"
            && typeof WebAssembly.instantiate === "function") {
            const module = new WebAssembly.Module(Uint8Array.of(0x0, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00));
            if (module instanceof WebAssembly.Module)
                return new WebAssembly.Instance(module) instanceof WebAssembly.Instance;
        }
    }
    catch (e) {
    }
    return false;
}
;
/**
 * Detect whether running in firefox.
 * @returns boolean  True if firefox. False otherwise.
 */
function isFirefox() {
    // See https://stackoverflow.com/questions/7000190/detect-all-firefox-versions-in-js
    return navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
}
/**
 * Get the path of the index.html file. Allows webina to run even fromm a
 * subdir.
 * @returns string  The path.
 */
function curPath() {
    let url = window.location.pathname.replace("index.html", "");
    if (url.slice(url.length - 1) !== "/") {
        url = url + "/";
    }
    return url;
}
/**
 * Given a filename, replace its extension.
 * @param  {string} filename  The original filename.
 * @param  {string} newExt    The new extension.
 * @returns string  The new filename.
 */
function replaceExt(filename, newExt) {
    if (filename.indexOf(".") !== -1) {
        let prts = filename.split(".");
        filename = prts.slice(0, prts.length - 1).join(".");
    }
    return filename + "." + newExt;
}
/**
 * Given some PDB text, keep only those lines that describe protein atoms.
 * @param  {string} pdbTxt  The original PDB text.
 * @returns string  the PDB text containing only the protein atoms.
 */
function keepOnlyProteinAtoms(pdbTxt) {
    let proteinResidues = [
        "ALA", "ARG", "ASH", "ASN", "ASP", "ASX", "CYM", "CYS", "CYX",
        "GLH", "GLN", "GLU", "GLX", "GLY", "HID", "HIE", "HIP", "HIS",
        "HSD", "HSE", "HSP", "ILE", "LEU", "LYN", "LYS", "MET", "MSE",
        "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"
    ];
    let lines = pdbTxt.split("\n");
    let l = lines.length;
    let linesToKeep = "";
    for (let i = 0; i < l; i++) {
        if ((lines[i].substr(0, 5) !== "ATOM ") && (lines[i].substr(0, 7) !== "HETATM ")) {
            // Not an atom line.
            continue;
        }
        if (proteinResidues.indexOf(lines[i].substr(17, 3)) !== -1) {
            linesToKeep += lines[i] + "\n";
        }
    }
    return linesToKeep;
}

;// CONCATENATED MODULE: ./src/Version.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
let VERSION = "1.0.3";

;// CONCATENATED MODULE: ./src/UI/ThreeDMol.ts
/* provided dependency */ var jQuery = __webpack_require__(755);
/* provided dependency */ var $3Dmol = __webpack_require__(494);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

let bigMolAlreadyModalDisplayed = false;
/** An object containing the vue-component computed functions. */
let computedFunctions = {
    /**
     * Get the value of the receptorContents variable.
     * @returns string  The value.
     */
    "receptorContents"() {
        return Store_store.state["receptorContents"];
    },
    /**
     * Get the value of the ligandContents variable.
     * @returns string  The value.
     */
    "ligandContents"() {
        return Store_store.state["ligandContents"];
    },
    /**
     * Get the value of the dockedContents variable.
     * @returns string  The value.
     */
    "dockedContents"() {
        return Store_store.state["dockedContents"];
    },
    /**
     * Get the value of the crystalContents variable.
     * @returns string  The value.
     */
    "crystalContents"() {
        return Store_store.state["crystalContents"];
    },
    /**
     * Get the value of the vinaParams variable.
     * @returns string  The value.
     */
    vinaParams() {
        return Store_store.state["vinaParams"];
    },
    /**
     * Get the value of the surfBtnVariant variable.
     * @returns string|boolean|undefined  The value.
     */
    "surfBtnVariant"() {
        return (this["renderProteinSurface"] === true) ? undefined : "default";
    },
    /**
     * Get the value of the allAtmBtnVariant variable.
     * @returns string|boolean|undefined  The value.
     */
    "allAtmBtnVariant"() {
        return (this["renderProteinSticks"] === true) ? undefined : "default";
    },
    /**
     * Get the value of the crystalBtnVariant variable.
     * @returns string|boolean|undefined  The value.
     */
    "crystalBtnVariant"() {
        return (this["renderCrystal"] === true) ? undefined : "default";
    },
    /**
     * Determines whether the appropriate PDB content has been loaded.
     * @returns boolean|undefined  True if it has been loaded, false otherwise.
     */
    "appropriatePdbLoaded"() {
        switch (this["type"]) {
            case "receptor":
                // @ts-ignore
                return this.appropriateReceptorPdbLoaded;
            case "ligand":
                // @ts-ignore
                return this.appropriateLigandPdbLoaded;
            case "docked":
                // @ts-ignore
                return this.appropriateDockedPdbLoaded;
        }
    },
    /**
     * Determines whether the appropriate receptor PDB content has
     * been loaded.
     * @returns boolean  True if it has been loaded, false otherwise.
     */
    appropriateReceptorPdbLoaded() {
        return Store_store.state["receptorContents"] !== "" || Store_store.state["crystalContents"] !== "";
    },
    /**
     * Determines whether the appropriate ligand PDB content has been
     * loaded.
     * @returns boolean  True if it has been loaded, false otherwise.
     */
    appropriateLigandPdbLoaded() {
        return Store_store.state["ligandContents"] !== "";
    },
    /**
     * Determines whether the appropriate docked PDB content has been
     * loaded.
     * @returns boolean  True if it has been loaded, false otherwise.
     */
    appropriateDockedPdbLoaded() {
        return (Store_store.state["receptorContents"] !== "") && (Store_store.state["dockedContents"] !== "");
    }
};
/** An object containing the vue-component methods functions. */
let methodsFunctions = {
    /**
     * Runs when a new model has been added.
     * @param  {number} duration  How long to wait before adding that
     *                            model to 3dmol.js widget.
     * @returns void
     */
    modelAdded(duration) {
        // First, check to make sure the added model is relevant to
        // this 3dmoljs instance.
        if (this["appropriatePdbLoaded"] === false) {
            return;
        }
        // Put app into waiting state.
        jQuery("body").addClass("waiting");
        this["msg"] = "Loading...";
        setTimeout(() => {
            // Initialize the viewer if necessary.
            if (this["viewer"] === undefined) {
                let element = jQuery("#" + this["type"] + "-3dmol");
                let config = {
                    backgroundColor: "white"
                };
                this["viewer"] = $3Dmol.createViewer(element, config);
            }
            let loadPDBTxt = (typeStr, callBack) => {
                let origPDBContent = this[typeStr + "Contents"];
                let pdb = pdbqtToPDB(origPDBContent, Store_store);
                if (pdb !== "") {
                    if (this[typeStr + "PdbOfLoaded"] !== pdb) {
                        // console.log(this["type"], "Adding " + typeStr, pdb.length);
                        this[typeStr + "PdbOfLoaded"] = pdb;
                        let prevModel = this[typeStr + "Mol"];
                        if (prevModel !== undefined) {
                            this["viewer"].removeModel(prevModel);
                        }
                        this["viewer"].resize();
                        this[typeStr + "Mol"] = this["viewer"].addModel(pdb, "pdb", { "keepH": true });
                        modelForZooming = this[typeStr + "Mol"];
                        callBack(modelForZooming);
                    }
                }
                else if (origPDBContent !== "") {
                    // It's empty, but shouldn't be. Probably not
                    // properly formed.
                    // this["viewer"].removeModel(this[typeStr + "Mol"]);
                    // this["viewer"].removeAllShapes();
                    // this["viewer"].resize();
                    Store_store.commit("openModal", {
                        title: "Invalid Input File!",
                        body: "<p>The selected input file is not properly formatted. The molecular viewer has not been updated. Please select a properly formatted PDBQT or PDB file, as appropriate.</p>"
                    });
                }
            };
            // Convert pdbqt to pdb
            let modelForZooming;
            if (["receptor", "docked"].indexOf(this["type"]) !== -1) {
                let somethingChanged;
                loadPDBTxt("receptor", (mol) => {
                    somethingChanged = true;
                    this["viewer"].removeAllSurfaces();
                    this["surfaceObj"] = undefined;
                    // this["renderProteinSurface"] = false;
                    this.receptorAdded(mol);
                });
                loadPDBTxt("crystal", (mol) => {
                    somethingChanged = true;
                    this.ligandAdded(mol, true);
                });
                loadPDBTxt("docked", (mol) => {
                    somethingChanged = true;
                    this.ligandAdded(mol);
                });
                if (somethingChanged === true) {
                    // this["viewer"].resize();  // To make sure. Had some problems in testing.
                    this["viewer"].render();
                    this["viewer"].zoomTo({ "model": modelForZooming }, duration);
                    this["viewer"].zoom(0.8, duration);
                }
            }
            if (["ligand"].indexOf(this["type"]) !== -1) {
                loadPDBTxt("ligand", (mol) => {
                    this.ligandAdded(mol);
                });
                // this["viewer"].resize();  // To make sure. Had some problems in testing.
                this["viewer"].render();
                this["viewer"].zoomTo({ "model": modelForZooming }, duration);
                this["viewer"].zoom(0.8, duration);
            }
            // Stop waiting state.
            jQuery("body").removeClass("waiting");
        }, 50);
    },
    /**
     * Runs when a receptor has been added.
     * @param  {any} mol  The 3dmol.js molecule object.
     * @returns void
     */
    receptorAdded(mol) {
        // Get the center of the protein
        let atoms = mol.selectedAtoms({});
        let len = atoms.length;
        let xTot = 0;
        let yTot = 0;
        let zTot = 0;
        let minX = 1e100;
        let minY = 1e100;
        let minZ = 1e100;
        let maxX = -1e100;
        let maxY = -1e100;
        let maxZ = -1e100;
        for (let i = 0; i < len; i++) {
            let atom = atoms[i];
            let x = atom.x;
            let y = atom.y;
            let z = atom.z;
            xTot += x;
            yTot += y;
            zTot += z;
            if (x > maxX) {
                maxX = x;
            }
            if (y > maxY) {
                maxY = y;
            }
            if (z > maxZ) {
                maxZ = z;
            }
            if (x < minX) {
                minX = x;
            }
            if (y < minY) {
                minY = y;
            }
            if (z < minZ) {
                minZ = z;
            }
        }
        let centerX = xTot / len;
        let centerY = yTot / len;
        let centerZ = zTot / len;
        let sizeX = 0.25 * (maxX - minX);
        let sizeY = 0.25 * (maxY - minY);
        let sizeZ = 0.25 * (maxZ - minZ);
        this.setVinaParamIfUndefined("center_x", +centerX.toFixed(2));
        this.setVinaParamIfUndefined("center_y", +centerY.toFixed(2));
        this.setVinaParamIfUndefined("center_z", +centerZ.toFixed(2));
        this.setVinaParamIfUndefined("size_x", +sizeX.toFixed(2));
        this.setVinaParamIfUndefined("size_y", +sizeY.toFixed(2));
        this.setVinaParamIfUndefined("size_z", +sizeZ.toFixed(2));
        // Make the atoms of the protein clickable if it is receptor.
        if (this["type"] === "receptor") {
            this.makeAtomsClickable(mol);
        }
        this.showSurfaceAsAppropriate();
        this.showSticksAsAppropriate();
    },
    /**
     * Runs when a ligand has been added.
     * @param  {any} mol  The 3dmol.js molecule object.
     * @returns void
     */
    ligandAdded(mol, isCrystal = false) {
        let stickStyle = {};
        mol.setStyle({}, {
            "stick": { "radius": 0.4 }
        });
        this["viewer"]["render"]();
        if (isCrystal === true) {
            this.makeAtomsClickable(mol);
            this.showCrystalAsAppropriate();
        }
    },
    /**
     * Makes the atoms of a 3dmol.js molecule clicable.
     * @param  {any} mol  The 3dmol.js molecule.
     * @returns void
     */
    makeAtomsClickable(mol) {
        mol.setClickable({}, true, (e) => {
            Store_store.commit("setVinaParam", {
                name: "center_x",
                val: e["x"]
            });
            Store_store.commit("setVinaParam", {
                name: "center_y",
                val: e["y"]
            });
            Store_store.commit("setVinaParam", {
                name: "center_z",
                val: e["z"]
            });
        });
        // Also make labels.
        let atoms = mol.selectedAtoms({});
        let len = atoms.length;
        for (let i = 0; i < len; i++) {
            let atom = atoms[i];
            this["viewer"].setHoverable({}, true, (atom) => {
                let lbl = atom["resn"].trim() + atom["resi"].toString() + ":" + atom["atom"].trim();
                atom["chain"] = atom["chain"].trim();
                if (atom["chain"] !== "") {
                    lbl += ":" + atom["chain"];
                }
                this["viewer"].addLabel(lbl, { "position": atom, "backgroundOpacity": 0.8 });
            }, (atom) => {
                this["viewer"].removeAllLabels();
            });
        }
    },
    /**
     * Sets a vina parameter only if it is currently undefined. Used
     * for setting default values, I think.
     * @param  {string} name  The variable name.
     * @param  {any}    val   The value.
     * @returns void
     */
    setVinaParamIfUndefined(name, val) {
        if (Store_store.state["vinaParams"][name] === undefined) {
            Store_store.commit("setVinaParam", {
                name,
                val
            });
            Store_store.commit("setValidationParam", {
                name,
                val: true
            });
        }
    },
    /**
     * Show a molecular surface representation if it is appropriate
     * given user settings.
     * @returns void
     */
    showSurfaceAsAppropriate() {
        // If no protein has been loaded, no need to proceed.
        if (this["receptorMol"] === undefined) {
            return;
        }
        if (this["renderProteinSurface"] === true) {
            // You're supposed to render the surface. What if it
            // doesn't exist yet?
            if (this["surfaceObj"] === undefined) {
                this["viewer"].removeAllSurfaces();
                this["surfaceObj"] = this["viewer"].addSurface($3Dmol.SurfaceType.MS, {
                    "color": 'white',
                    "opacity": 0.85
                }, {
                    "model": this["receptorMol"]
                });
            }
            // Now it exists for sure. Make sure it is visible.
            this["viewer"]["setSurfaceMaterialStyle"](this["surfaceObj"]["surfid"], {
                "color": 'white',
                "opacity": 0.85
            });
            this["viewer"]["render"]();
        }
        else {
            // So you need to hide the surface, if it exists.
            if (this["surfaceObj"] !== undefined) {
                this["viewer"]["setSurfaceMaterialStyle"](this["surfaceObj"]["surfid"], { "opacity": 0 });
                this["viewer"]["render"]();
            }
        }
    },
    /**
     * Show a sticks representation if it is appropriate given user
     * settings.
     * @returns void
     */
    showSticksAsAppropriate() {
        // If no protein has been loaded, no need to proceed.
        if (this["receptorMol"] === undefined) {
            return;
        }
        if (this["renderProteinSticks"] === true) {
            // Set up the style.
            this["receptorMol"].setStyle({}, {
                "stick": { "radius": 0.15 },
                "cartoon": { "color": 'spectrum' },
            });
            this["viewer"]["render"]();
        }
        else {
            // Set up the style.
            this["receptorMol"].setStyle({}, {}); // This is better. Clear first.
            this["viewer"]["render"]();
            this["receptorMol"].setStyle({}, { "cartoon": { "color": 'spectrum' } });
            this["viewer"]["render"]();
        }
    },
    /**
     * Show a yellow sticks representation if it is appropriate given
     * user settings.
     * @returns void
     */
    showCrystalAsAppropriate() {
        // If no protein has been loaded, no need to proceed.
        if (this["crystalMol"] === undefined) {
            return;
        }
        if (this["renderCrystal"] === true) {
            // Set up the style.
            this["crystalMol"].setStyle({}, {
                "stick": {
                    "radius": 0.3,
                    "color": "yellow"
                    // "colorscheme": "yellowCarbon"
                }
            });
            this["viewer"]["render"]();
        }
        else {
            // Set up the style.
            this["crystalMol"].setStyle({}, {});
            this["viewer"]["render"]();
        }
    },
    /**
     * Toggles the surface representation on and off.
     * @returns void
     */
    "toggleSurface"() {
        this["renderProteinSurface"] = !this["renderProteinSurface"];
        this.showSurfaceAsAppropriate();
    },
    /**
     * Toggles the sricks representation on and off.
     * @returns void
     */
    "toggleSticks"() {
        this["renderProteinSticks"] = !this["renderProteinSticks"];
        this.showSticksAsAppropriate();
    },
    /**
     * Toggles the yellow sticks representation on and off.
     * @returns void
     */
    "toggleCrystal"() {
        this["renderCrystal"] = !this["renderCrystal"];
        this.showCrystalAsAppropriate();
    },
    /**
     * Updates the box in the 3dmol.js widget.
     * @returns void
     */
    updateBox() {
        if (this["viewer"] === undefined) {
            // Try again in a bit. Not loaded yet...
            // @ts-ignore
            setTimeout(this.updateBox, 1000);
            return;
        }
        let centerX = Store_store.state["vinaParams"]["center_x"];
        if (centerX === undefined) {
            return;
        }
        let centerY = Store_store.state["vinaParams"]["center_y"];
        if (centerY === undefined) {
            return;
        }
        let centerZ = Store_store.state["vinaParams"]["center_z"];
        if (centerZ === undefined) {
            return;
        }
        let sizeX = Store_store.state["vinaParams"]["size_x"];
        if (sizeX === undefined) {
            return;
        }
        let sizeY = Store_store.state["vinaParams"]["size_y"];
        if (sizeY === undefined) {
            return;
        }
        let sizeZ = Store_store.state["vinaParams"]["size_z"];
        if (sizeZ === undefined) {
            return;
        }
        this["viewer"].removeAllShapes();
        this["viewer"].addBox({
            "center": {
                "x": centerX,
                "y": centerY,
                "z": centerZ
            },
            "dimensions": {
                "w": sizeX,
                "h": sizeY,
                "d": sizeZ
            },
            "color": 'yellow',
            "opacity": 0.8
        });
        this["viewer"].render();
    }
};
/** An object containing the vue-component watch functions. */
let watchFunctions = {
    /**
     * Watch when the receptorContents computed property.
     * @param  {string} newReceptorContents  The new value of the property.
     * @param  {string} oldReceptorContents  The old value of the property.
     * @returns void
     */
    "receptorContents": function (newReceptorContents, oldReceptorContents) {
        // The purpose of this is to react when new receptorContents
        // are added.
        let duration = (oldReceptorContents === "") ? 0 : 500;
        this.modelAdded(duration);
        // this.updateBox();  // So when invalid pdb loaded, can recover with valid pdb.
    },
    /**
     * Watch when the ligandContents computed property.
     * @param  {string} newLigandContents  The new value of the property.
     * @param  {string} oldLigandContents  The old value of the property.
     * @returns void
     */
    "ligandContents": function (newLigandContents, oldLigandContents) {
        // The purpose of this is to react when new ligandContents are
        // added.
        let duration = (oldLigandContents === "") ? 0 : 500;
        this.modelAdded(duration);
    },
    /**
     * Watch when the dockedContents computed property.
     * @param  {string} newDockedContents  The new value of the property.
     * @param  {string} oldDockedContents  The old value of the property.
     * @returns void
     */
    "dockedContents": function (newDockedContents, oldDockedContents) {
        // The purpose of this is to react when new dockedContents are
        // added.
        let duration = (oldDockedContents === "") ? 0 : 500;
        this.modelAdded(duration);
    },
    /**
     * Watch when the crystalContents computed property.
     * @param  {string} newCrystalContents  The new value of the property.
     * @param  {string} oldCrystalContents  The old value of the property.
     * @returns void
     */
    "crystalContents": function (newCrystalContents, oldCrystalContents) {
        // The purpose of this is to react when new dockedContents are
        // added.
        let duration = (oldCrystalContents === "") ? 0 : 500;
        this.modelAdded(duration);
    },
    /**
     * Watch when the vinaParams computed property.
     * @param  {string} newVinaParams  The new value of the property.
     * @param  {string} oldVinaParams  The old value of the property.
     * @returns void
     */
    vinaParams(newVinaParams, oldVinaParams) {
        // For updating the docking box...
        if (this["type"] !== "receptor") {
            return;
        }
        // @ts-ignore
        this.updateBox();
    }
};
/**
 * The vue-component mounted function.
 * @returns void
 */
function mountedFunction() {
    // @ts-ignore
    this["renderProteinSurface"] = this["proteinSurface"];
}
/**
 * Setup the threedmol Vue commponent.
 * @returns void
 */
function setup() {
    Vue.component('threedmol', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {
                "viewer": undefined,
                "surfaceObj": undefined,
                "receptorMol": undefined,
                "crystalMol": undefined,
                "ligandMol": undefined,
                "dockedMol": undefined,
                "receptorPdbOfLoaded": "",
                "crystalPdbOfLoaded": "",
                "ligandPdbOfLoaded": "",
                "dockedPdbOfLoaded": "",
                "renderProteinSurface": undefined,
                "renderProteinSticks": true,
                "renderCrystal": true,
                "msg": "Use the file input above to select the " + this["type"] + " PDBQT file."
            };
        },
        "computed": computedFunctions,
        "template": `
            <div class="container-3dmol" style="display:grid;">
                <div
                    :id="type + '-3dmol'"
                    style="height: 400px; width: 100%; position: relative;">

                    <b-card v-if="!appropriatePdbLoaded"
                        class="text-center"
                        :title="'Missing ' + type.substring(0, 1).toUpperCase() + type.substring(1)"
                        style="width: 100%; height: 100%;"
                    >
                        <b-card-text v-if="autoLoad">
                            Loading...
                        </b-card-text>
                        <b-card-text v-else>
                            {{msg}}
                        </b-card-text>
                    </b-card>
                    <b-card v-else
                        class="text-center"
                        :title="'Missing ' + type.substring(0, 1).toUpperCase() + type.substring(1)"
                        style="width: 100%; height: 100%;"
                    >
                        Currently loading...
                    </b-card>
                </div>
                <div v-if="type!=='ligand'" style="margin-top:-34px; padding-right:9px;" class="mr-1">
                    <form-button :variant="surfBtnVariant" @click.native="toggleSurface" :small="true">Surface</form-button>
                    <form-button v-if="crystalContents!==''" @click.native="toggleCrystal" :variant="crystalBtnVariant" :small="true">Correct Pose</form-button>
                    <form-button :variant="allAtmBtnVariant" @click.native="toggleSticks" :small="true">All Atoms</form-button>
                </div>
            </div>
        `,
        "watch": watchFunctions,
        "props": {
            "type": String,
            // determine if it's been loaded yet.
            "proteinSurface": {
                "type": Boolean,
                "default": false
            },
            "autoLoad": {
                "type": Boolean,
                "default": false
            }
        },
        "methods": methodsFunctions,
        /**
         * Runs when the vue component is mounted.
         * @returns void
         */
        "mounted": mountedFunction
    });
}
/**
 * Converts a pdbqt string to pdb.
 * @param  {string}           pdbqtTxt  The pdbqt text.
 * @param  {any=undefined}    store?    A VueX store object.
 * @returns string  The pdb text.s
 */
function pdbqtToPDB(pdbqtTxt, store) {
    let lines = pdbqtTxt.split("\n");
    lines = lines.map(l => l.replace(/^HETATM/g, "ATOM  "));
    lines = lines.filter(l => {
        if (l.substring(0, 4) === "ATOM") {
            return true;
        }
        return false;
    });
    // Get the element names
    let elements = lines.map(l => l.substring(11, 17).trim().replace(/[0-9]/g, "").substr(0, 2).toUpperCase());
    elements = elements.map((e) => {
        if (["BR", "CL", "ZN", "MG", "AU", "MN", "FE"].indexOf(e) !== -1) {
            return e;
        }
        else {
            return e.substring(0, 1);
        }
    });
    lines = lines.map((l, i) => {
        return l.substring(0, 77) + elements[i];
    });
    let numAtoms = lines.length;
    // You may need to remove some atoms if there are to many atoms.
    let msg = "";
    if (lines.length > 5000) {
        // Remove hydrogen atoms
        lines = lines.filter(l => l.slice(12, 16).replace(/ /g, '').replace(/[0-9]/g, "").slice(0, 1).toUpperCase() !== "H");
        msg = "hydrogen atoms";
    }
    if (lines.length > 5000) {
        // Remove sidechains
        lines = lines.filter(l => ["CA", "O", "C", "N"].indexOf(l.slice(12, 16).replace(/ /g, '')) !== -1);
        msg = "hydrogen atoms and side chains";
    }
    if (lines.length > 5000) {
        // Remove O too.
        lines = lines.filter(l => l.slice(12, 16).replace(/ /g, '') !== "O");
        msg = "hydrogen atoms, side chains, and backbone carbonyl oxygen atoms";
    }
    if ((bigMolAlreadyModalDisplayed === false) && (msg !== "") && (store !== undefined)) {
        bigMolAlreadyModalDisplayed = true;
        store.commit("openModal", {
            title: "Large Molecule!",
            body: "<p>The PDB or PDBQT file you provided contains " + numAtoms.toString() + " atoms. A version of your file without " + msg + " will be displayed to speed visualization.</p>"
        });
    }
    pdbqtTxt = lines.join("\n");
    return pdbqtTxt;
}

;// CONCATENATED MODULE: ./src/example/1xdn.pdbqt
const _1xdn_pdbqt_namespaceObject = "ATOM      1  N   GLN    52      42.237  16.800  35.823  1.00  0.00    -0.066 N \nATOM      2  CA  GLN    52      41.667  17.015  34.477  1.00  0.00     0.275 C \nATOM      3  C   GLN    52      40.148  17.010  34.446  1.00  0.00     0.249 C \nATOM      4  O   GLN    52      39.564  17.006  33.382  1.00  0.00    -0.271 OA\nATOM      5  CB  GLN    52      42.228  15.967  33.522  1.00  0.00     0.052 C \nATOM      6  CG  GLN    52      43.746  16.016  33.446  1.00  0.00     0.105 C \nATOM      7  CD  GLN    52      44.292  17.263  32.785  1.00  0.00     0.215 C \nATOM      8  OE1 GLN    52      43.587  17.906  32.000  1.00  0.00    -0.274 OA\nATOM      9  NE2 GLN    52      45.513  17.598  33.072  1.00  0.00    -0.370 N \nATOM     10  H2  GLN    52      41.772  15.848  36.146  1.00  0.00     0.275 HD\nATOM     11  H3  GLN    52      43.141  16.691  35.848  1.00  0.00     0.275 HD\nATOM     12  H   GLN    52      41.923  17.526  36.434  1.00  0.00     0.275 HD\nATOM     13 2HE2 GLN    52      46.044  17.022  33.735  1.00  0.00     0.159 HD\nATOM     14 1HE2 GLN    52      45.958  18.423  32.653  1.00  0.00     0.159 HD\nATOM     15  N   SER    53      39.488  17.025  35.604  1.00  0.00    -0.344 N \nATOM     16  CA  SER    53      38.026  16.949  35.611  1.00  0.00     0.200 C \nATOM     17  C   SER    53      37.340  18.091  34.862  1.00  0.00     0.243 C \nATOM     18  O   SER    53      36.209  17.937  34.426  1.00  0.00    -0.271 OA\nATOM     19  CB  SER    53      37.462  16.890  37.026  1.00  0.00     0.199 C \nATOM     20  OG  SER    53      37.854  18.006  37.781  1.00  0.00    -0.398 OA\nATOM     21  H   SER    53      40.067  17.091  36.447  1.00  0.00     0.163 HD\nATOM     22  HG  SER    53      37.478  18.841  37.375  1.00  0.00     0.209 HD\nATOM     23  N   ASP    54      38.012  19.228  34.730  1.00  0.00    -0.345 N \nATOM     24  CA  ASP    54      37.455  20.341  33.968  1.00  0.00     0.186 C \nATOM     25  C   ASP    54      37.742  20.271  32.474  1.00  0.00     0.241 C \nATOM     26  O   ASP    54      37.168  21.045  31.722  1.00  0.00    -0.271 OA\nATOM     27  CB  ASP    54      37.947  21.667  34.531  1.00  0.00     0.147 C \nATOM     28  CG  ASP    54      37.464  21.907  35.937  1.00  0.00     0.175 C \nATOM     29  OD1 ASP    54      36.280  21.638  36.211  1.00  0.00    -0.648 OA\nATOM     30  OD2 ASP    54      38.207  22.360  36.811  1.00  0.00    -0.648 OA\nATOM     31  H   ASP    54      38.932  19.255  35.198  1.00  0.00     0.163 HD\nATOM     32  N   PHE    55      38.617  19.367  32.044  1.00  0.00    -0.346 N \nATOM     33  CA  PHE    55      38.972  19.219  30.642  1.00  0.00     0.180 C \nATOM     34  C   PHE    55      37.915  18.485  29.848  1.00  0.00     0.241 C \nATOM     35  O   PHE    55      37.392  17.475  30.303  1.00  0.00    -0.271 OA\nATOM     36  CB  PHE    55      40.300  18.470  30.543  1.00  0.00     0.073 C \nATOM     37  CG  PHE    55      40.730  18.127  29.138  1.00  0.00    -0.056 A \nATOM     38  CD1 PHE    55      41.050  19.110  28.229  1.00  0.00     0.007 A \nATOM     39  CD2 PHE    55      40.847  16.803  28.753  1.00  0.00     0.007 A \nATOM     40  CE1 PHE    55      41.470  18.763  26.957  1.00  0.00     0.001 A \nATOM     41  CE2 PHE    55      41.266  16.455  27.495  1.00  0.00     0.001 A \nATOM     42  CZ  PHE    55      41.584  17.426  26.589  1.00  0.00     0.000 A \nATOM     43  H   PHE    55      39.027  18.773  32.803  1.00  0.00     0.163 HD\nATOM     44  N   SER    56      37.615  18.984  28.653  1.00  0.00    -0.344 N \nATOM     45  CA  SER    56      36.702  18.341  27.727  1.00  0.00     0.200 C \nATOM     46  C   SER    56      37.409  18.135  26.390  1.00  0.00     0.245 C \nATOM     47  O   SER    56      37.676  19.116  25.681  1.00  0.00    -0.271 OA\nATOM     48  CB  SER    56      35.476  19.231  27.540  1.00  0.00     0.199 C \nATOM     49  OG  SER    56      34.454  18.554  26.839  1.00  0.00    -0.398 OA\nATOM     50  H   SER    56      38.101  19.891  28.438  1.00  0.00     0.163 HD\nATOM     51  HG  SER    56      34.028  17.876  27.438  1.00  0.00     0.209 HD\nATOM     52  N   PRO    57      37.729  16.888  26.033  1.00  0.00    -0.337 N \nATOM     53  CA  PRO    57      38.409  16.649  24.754  1.00  0.00     0.179 C \nATOM     54  C   PRO    57      37.622  17.191  23.585  1.00  0.00     0.241 C \nATOM     55  O   PRO    57      36.400  17.105  23.551  1.00  0.00    -0.271 OA\nATOM     56  CB  PRO    57      38.525  15.124  24.677  1.00  0.00     0.037 C \nATOM     57  CG  PRO    57      38.403  14.640  26.059  1.00  0.00     0.022 C \nATOM     58  CD  PRO    57      37.508  15.628  26.772  1.00  0.00     0.127 C \nATOM     59  N   TYR    58      38.339  17.747  22.619  1.00  0.00    -0.346 N \nATOM     60  CA  TYR    58      37.722  18.174  21.383  1.00  0.00     0.180 C \nATOM     61  C   TYR    58      37.720  16.916  20.539  1.00  0.00     0.241 C \nATOM     62  O   TYR    58      37.954  15.802  21.051  1.00  0.00    -0.271 OA\nATOM     63  CB  TYR    58      38.459  19.389  20.783  1.00  0.00     0.073 C \nATOM     64  CG  TYR    58      37.649  20.058  19.693  1.00  0.00    -0.056 A \nATOM     65  CD1 TYR    58      36.490  20.749  19.989  1.00  0.00     0.010 A \nATOM     66  CD2 TYR    58      38.011  19.951  18.354  1.00  0.00     0.010 A \nATOM     67  CE1 TYR    58      35.725  21.321  18.986  1.00  0.00     0.037 A \nATOM     68  CE2 TYR    58      37.237  20.520  17.348  1.00  0.00     0.037 A \nATOM     69  CZ  TYR    58      36.095  21.188  17.671  1.00  0.00     0.065 A \nATOM     70  OH  TYR    58      35.360  21.745  16.658  1.00  0.00    -0.361 OA\nATOM     71  H   TYR    58      39.351  17.844  22.825  1.00  0.00     0.163 HD\nATOM     72  HH  TYR    58      34.567  22.214  17.044  1.00  0.00     0.217 HD\nATOM     73  N   ILE    59      37.333  17.049  19.295  1.00  0.00    -0.346 N \nATOM     74  CA  ILE    59      37.115  15.901  18.448  1.00  0.00     0.180 C \nATOM     75  C   ILE    59      38.089  15.820  17.302  1.00  0.00     0.241 C \nATOM     76  O   ILE    59      38.750  16.803  16.917  1.00  0.00    -0.271 OA\nATOM     77  CB  ILE    59      35.694  15.926  17.889  1.00  0.00     0.013 C \nATOM     78  CG1 ILE    59      35.445  17.222  17.112  1.00  0.00     0.002 C \nATOM     79  CG2 ILE    59      34.704  15.759  19.016  1.00  0.00     0.012 C \nATOM     80  CD1 ILE    59      34.256  17.154  16.212  1.00  0.00     0.005 C \nATOM     81  H   ILE    59      37.199  18.032  18.976  1.00  0.00     0.163 HD\nATOM     82  N   GLU    60      38.180  14.611  16.777  1.00  0.00    -0.346 N \nATOM     83  CA  GLU    60      38.661  14.409  15.428  1.00  0.00     0.177 C \nATOM     84  C   GLU    60      37.481  14.459  14.452  1.00  0.00     0.241 C \nATOM     85  O   GLU    60      36.332  14.278  14.839  1.00  0.00    -0.271 OA\nATOM     86  CB  GLU    60      39.495  13.129  15.350  1.00  0.00     0.045 C \nATOM     87  CG  GLU    60      40.798  13.316  16.137  1.00  0.00     0.116 C \nATOM     88  CD  GLU    60      41.613  12.057  16.350  1.00  0.00     0.172 C \nATOM     89  OE1 GLU    60      41.570  11.155  15.484  1.00  0.00    -0.648 OA\nATOM     90  OE2 GLU    60      42.308  11.976  17.395  1.00  0.00    -0.648 OA\nATOM     91  H   GLU    60      37.882  13.837  17.405  1.00  0.00     0.163 HD\nATOM     92  N   ILE    61      37.793  14.733  13.206  1.00  0.00    -0.346 N \nATOM     93  CA  ILE    61      36.779  14.950  12.200  1.00  0.00     0.180 C \nATOM     94  C   ILE    61      37.084  14.056  11.030  1.00  0.00     0.241 C \nATOM     95  O   ILE    61      38.219  13.998  10.572  1.00  0.00    -0.271 OA\nATOM     96  CB  ILE    61      36.757  16.443  11.793  1.00  0.00     0.013 C \nATOM     97  CG1 ILE    61      36.419  17.333  12.993  1.00  0.00     0.002 C \nATOM     98  CG2 ILE    61      35.749  16.663  10.695  1.00  0.00     0.012 C \nATOM     99  CD1 ILE    61      36.548  18.813  12.744  1.00  0.00     0.005 C \nATOM    100  H   ILE    61      38.816  14.780  13.009  1.00  0.00     0.163 HD\nATOM    101  N   ASP    62      36.066  13.372  10.530  1.00  0.00    -0.345 N \nATOM    102  CA  ASP    62      36.254  12.425   9.448  1.00  0.00     0.186 C \nATOM    103  C   ASP    62      36.040  13.011   8.060  1.00  0.00     0.241 C \nATOM    104  O   ASP    62      35.232  13.916   7.872  1.00  0.00    -0.271 OA\nATOM    105  CB  ASP    62      35.294  11.244   9.583  1.00  0.00     0.147 C \nATOM    106  CG  ASP    62      35.411  10.521  10.881  1.00  0.00     0.175 C \nATOM    107  OD1 ASP    62      36.506  10.494  11.474  1.00  0.00    -0.648 OA\nATOM    108  OD2 ASP    62      34.418   9.952  11.370  1.00  0.00    -0.648 OA\nATOM    109  H   ASP    62      35.147  13.569  10.970  1.00  0.00     0.163 HD\nATOM    110  N   LEU    63      36.758  12.454   7.084  1.00  0.00    -0.346 N \nATOM    111  CA  LEU    63      36.396  12.571   5.682  1.00  0.00     0.177 C \nATOM    112  C   LEU    63      35.017  11.951   5.504  1.00  0.00     0.243 C \nATOM    113  O   LEU    63      34.647  11.040   6.252  1.00  0.00    -0.271 OA\nATOM    114  CB  LEU    63      37.396  11.824   4.813  1.00  0.00     0.038 C \nATOM    115  CG  LEU    63      38.828  12.357   4.856  1.00  0.00    -0.020 C \nATOM    116  CD1 LEU    63      39.771  11.385   4.148  1.00  0.00     0.009 C \nATOM    117  CD2 LEU    63      38.933  13.737   4.253  1.00  0.00     0.009 C \nATOM    118  H   LEU    63      37.599  11.930   7.418  1.00  0.00     0.163 HD\nATOM    119  N   PRO    64      34.242  12.400   4.526  1.00  0.00    -0.337 N \nATOM    120  CA  PRO    64      32.886  11.862   4.349  1.00  0.00     0.179 C \nATOM    121  C   PRO    64      32.877  10.416   3.868  1.00  0.00     0.241 C \nATOM    122  O   PRO    64      33.404  10.094   2.797  1.00  0.00    -0.271 OA\nATOM    123  CB  PRO    64      32.270  12.793   3.299  1.00  0.00     0.037 C \nATOM    124  CG  PRO    64      33.462  13.342   2.535  1.00  0.00     0.022 C \nATOM    125  CD  PRO    64      34.540  13.481   3.572  1.00  0.00     0.127 C \nATOM    126  N   SER    65      32.257   9.546   4.658  1.00  0.00    -0.344 N \nATOM    127  CA  SER    65      32.130   8.131   4.315  1.00  0.00     0.200 C \nATOM    128  C   SER    65      30.817   7.862   3.590  1.00  0.00     0.243 C \nATOM    129  O   SER    65      29.878   8.664   3.639  1.00  0.00    -0.271 OA\nATOM    130  CB  SER    65      32.191   7.250   5.568  1.00  0.00     0.199 C \nATOM    131  OG  SER    65      31.018   7.423   6.342  1.00  0.00    -0.398 OA\nATOM    132  H   SER    65      31.872   9.955   5.536  1.00  0.00     0.163 HD\nATOM    133  HG  SER    65      31.147   7.006   7.241  1.00  0.00     0.209 HD\nATOM    134  N   GLU    66      30.748   6.713   2.924  1.00  0.00    -0.346 N \nATOM    135  CA  GLU    66      29.508   6.316   2.271  1.00  0.00     0.177 C \nATOM    136  C   GLU    66      28.356   6.255   3.260  1.00  0.00     0.241 C \nATOM    137  O   GLU    66      27.277   6.760   2.981  1.00  0.00    -0.271 OA\nATOM    138  CB  GLU    66      29.642   4.957   1.552  1.00  0.00     0.045 C \nATOM    139  CG  GLU    66      28.306   4.414   1.019  1.00  0.00     0.116 C \nATOM    140  CD  GLU    66      28.433   3.123   0.242  1.00  0.00     0.172 C \nATOM    141  OE1 GLU    66      28.933   2.141   0.821  1.00  0.00    -0.648 OA\nATOM    142  OE2 GLU    66      28.019   3.089  -0.939  1.00  0.00    -0.648 OA\nATOM    143  H   GLU    66      31.612   6.155   2.913  1.00  0.00     0.163 HD\nATOM    144  N   SER    67      28.585   5.632   4.407  1.00  0.00    -0.344 N \nATOM    145  CA  SER    67      27.500   5.447   5.369  1.00  0.00     0.200 C \nATOM    146  C   SER    67      27.067   6.771   5.976  1.00  0.00     0.243 C \nATOM    147  O   SER    67      25.882   6.991   6.211  1.00  0.00    -0.271 OA\nATOM    148  CB  SER    67      27.874   4.458   6.473  1.00  0.00     0.199 C \nATOM    149  OG  SER    67      28.977   4.872   7.232  1.00  0.00    -0.398 OA\nATOM    150  H   SER    67      29.547   5.305   4.555  1.00  0.00     0.163 HD\nATOM    151  HG  SER    67      28.664   5.333   8.065  1.00  0.00     0.209 HD\nATOM    152  N   ARG    68      28.017   7.667   6.221  1.00  0.00    -0.346 N \nATOM    153  CA  ARG    68      27.693   8.974   6.785  1.00  0.00     0.176 C \nATOM    154  C   ARG    68      26.824   9.757   5.813  1.00  0.00     0.241 C \nATOM    155  O   ARG    68      25.796  10.325   6.203  1.00  0.00    -0.271 OA\nATOM    156  CB  ARG    68      28.955   9.785   7.107  1.00  0.00     0.036 C \nATOM    157  CG  ARG    68      28.649  11.128   7.782  1.00  0.00     0.023 C \nATOM    158  CD  ARG    68      28.366  10.995   9.266  1.00  0.00     0.138 C \nATOM    159  NE  ARG    68      29.617  10.789   9.969  1.00  0.00    -0.227 N \nATOM    160  CZ  ARG    68      30.474  11.757  10.265  1.00  0.00     0.665 C \nATOM    161  NH1 ARG    68      30.148  13.034  10.076  1.00  0.00    -0.235 N \nATOM    162  NH2 ARG    68      31.642  11.441  10.803  1.00  0.00    -0.235 N \nATOM    163  HE  ARG    68      29.854   9.850  10.252  1.00  0.00     0.177 HD\nATOM    164 2HH2 ARG    68      32.309  12.161  11.016  1.00  0.00     0.174 HD\nATOM    165 1HH2 ARG    68      31.865  10.486  11.001  1.00  0.00     0.174 HD\nATOM    166  H   ARG    68      28.978   7.366   5.984  1.00  0.00     0.163 HD\nATOM    167 2HH1 ARG    68      30.817  13.754  10.288  1.00  0.00     0.174 HD\nATOM    168 1HH1 ARG    68      29.246  13.275   9.728  1.00  0.00     0.174 HD\nATOM    169  N   ILE    69      27.229   9.824   4.555  1.00  0.00    -0.346 N \nATOM    170  CA  ILE    69      26.494  10.586   3.566  1.00  0.00     0.180 C \nATOM    171  C   ILE    69      25.093  10.004   3.380  1.00  0.00     0.241 C \nATOM    172  O   ILE    69      24.116  10.740   3.335  1.00  0.00    -0.271 OA\nATOM    173  CB  ILE    69      27.280  10.669   2.238  1.00  0.00     0.013 C \nATOM    174  CG1 ILE    69      28.568  11.485   2.415  1.00  0.00     0.002 C \nATOM    175  CG2 ILE    69      26.414  11.244   1.119  1.00  0.00     0.012 C \nATOM    176  CD1 ILE    69      28.371  12.938   2.863  1.00  0.00     0.005 C \nATOM    177  H   ILE    69      28.098   9.295   4.346  1.00  0.00     0.163 HD\nATOM    178  N   GLN    70      24.978   8.687   3.301  1.00  0.00    -0.346 N \nATOM    179  CA  GLN    70      23.663   8.065   3.154  1.00  0.00     0.177 C \nATOM    180  C   GLN    70      22.760   8.408   4.337  1.00  0.00     0.241 C \nATOM    181  O   GLN    70      21.590   8.713   4.159  1.00  0.00    -0.271 OA\nATOM    182  CB  GLN    70      23.802   6.548   3.000  1.00  0.00     0.044 C \nATOM    183  CG  GLN    70      24.345   6.122   1.634  1.00  0.00     0.105 C \nATOM    184  CD  GLN    70      24.586   4.613   1.506  1.00  0.00     0.215 C \nATOM    185  OE1 GLN    70      24.719   3.916   2.518  1.00  0.00    -0.274 OA\nATOM    186  NE2 GLN    70      24.612   4.106   0.272  1.00  0.00    -0.370 N \nATOM    187  H   GLN    70      25.860   8.158   3.350  1.00  0.00     0.163 HD\nATOM    188 2HE2 GLN    70      24.455   4.750  -0.505  1.00  0.00     0.159 HD\nATOM    189 1HE2 GLN    70      24.779   3.119   0.114  1.00  0.00     0.159 HD\nATOM    190  N   SER    71      23.313   8.370   5.539  1.00  0.00    -0.344 N \nATOM    191  CA  SER    71      22.538   8.672   6.737  1.00  0.00     0.200 C \nATOM    192  C   SER    71      22.139  10.142   6.811  1.00  0.00     0.243 C \nATOM    193  O   SER    71      21.038  10.469   7.249  1.00  0.00    -0.271 OA\nATOM    194  CB  SER    71      23.330   8.303   7.980  1.00  0.00     0.199 C \nATOM    195  OG  SER    71      23.470   6.912   8.117  1.00  0.00    -0.398 OA\nATOM    196  H   SER    71      24.317   8.114   5.556  1.00  0.00     0.163 HD\nATOM    197  HG  SER    71      22.570   6.491   8.242  1.00  0.00     0.209 HD\nATOM    198  N   LEU    72      23.025  11.035   6.393  1.00  0.00    -0.346 N \nATOM    199  CA  LEU    72      22.700  12.454   6.385  1.00  0.00     0.177 C \nATOM    200  C   LEU    72      21.559  12.750   5.425  1.00  0.00     0.241 C \nATOM    201  O   LEU    72      20.677  13.537   5.738  1.00  0.00    -0.271 OA\nATOM    202  CB  LEU    72      23.937  13.291   6.066  1.00  0.00     0.038 C \nATOM    203  CG  LEU    72      24.961  13.356   7.203  1.00  0.00    -0.020 C \nATOM    204  CD1 LEU    72      26.247  13.996   6.730  1.00  0.00     0.009 C \nATOM    205  CD2 LEU    72      24.421  14.102   8.419  1.00  0.00     0.009 C \nATOM    206  H   LEU    72      23.932  10.650   6.085  1.00  0.00     0.163 HD\nATOM    207  N   HIS    73      21.531  12.080   4.287  1.00  0.00    -0.346 N \nATOM    208  CA  HIS    73      20.392  12.239   3.387  1.00  0.00     0.182 C \nATOM    209  C   HIS    73      19.112  11.631   3.938  1.00  0.00     0.241 C \nATOM    210  O   HIS    73      18.081  12.290   3.955  1.00  0.00    -0.271 OA\nATOM    211  CB  HIS    73      20.711  11.686   2.016  1.00  0.00     0.093 C \nATOM    212  CG  HIS    73      21.579  12.598   1.224  1.00  0.00     0.030 A \nATOM    213  ND1 HIS    73      22.946  12.449   1.159  1.00  0.00    -0.353 N \nATOM    214  CD2 HIS    73      21.271  13.599   0.369  1.00  0.00     0.143 A \nATOM    215  CE1 HIS    73      23.451  13.373   0.362  1.00  0.00     0.207 A \nATOM    216  NE2 HIS    73      22.454  14.079  -0.136  1.00  0.00    -0.254 NA\nATOM    217  HD1 HIS    73      23.473  11.748   1.640  1.00  0.00     0.166 HD\nATOM    218  H   HIS    73      22.333  11.472   4.099  1.00  0.00     0.163 HD\nATOM    219  N   LYS    74      19.190  10.402   4.427  1.00  0.00    -0.346 N \nATOM    220  CA  LYS    74      17.993   9.689   4.878  1.00  0.00     0.176 C \nATOM    221  C   LYS    74      17.318  10.385   6.052  1.00  0.00     0.241 C \nATOM    222  O   LYS    74      16.084  10.418   6.144  1.00  0.00    -0.271 OA\nATOM    223  CB  LYS    74      18.335   8.242   5.246  1.00  0.00     0.035 C \nATOM    224  CG  LYS    74      17.127   7.395   5.620  1.00  0.00     0.004 C \nATOM    225  CD  LYS    74      16.113   7.287   4.476  1.00  0.00     0.027 C \nATOM    226  CE  LYS    74      15.121   6.149   4.706  1.00  0.00     0.229 C \nATOM    227  NZ  LYS    74      14.309   5.856   3.497  1.00  0.00    -0.079 N \nATOM    228  HZ1 LYS    74      14.378   4.883   3.277  1.00  0.00     0.274 HD\nATOM    229  HZ3 LYS    74      13.353   6.092   3.673  1.00  0.00     0.274 HD\nATOM    230  HZ2 LYS    74      14.650   6.397   2.728  1.00  0.00     0.274 HD\nATOM    231  H   LYS    74      20.142   9.999   4.463  1.00  0.00     0.163 HD\nATOM    232  N   SER    75      18.123  10.938   6.951  1.00  0.00    -0.344 N \nATOM    233  CA  SER    75      17.621  11.627   8.128  1.00  0.00     0.200 C \nATOM    234  C   SER    75      16.975  12.967   7.807  1.00  0.00     0.242 C \nATOM    235  O   SER    75      16.318  13.538   8.663  1.00  0.00    -0.271 OA\nATOM    236  CB  SER    75      18.750  11.878   9.116  1.00  0.00     0.199 C \nATOM    237  OG  SER    75      19.719  12.744   8.551  1.00  0.00    -0.398 OA\nATOM    238  H   SER    75      19.141  10.835   6.739  1.00  0.00     0.163 HD\nATOM    239  HG  SER    75      20.342  12.216   7.975  1.00  0.00     0.209 HD\nATOM    240  N   GLY    76      17.193  13.497   6.610  1.00  0.00    -0.350 N \nATOM    241  CA  GLY    76      16.750  14.833   6.275  1.00  0.00     0.225 C \nATOM    242  C   GLY    76      17.766  15.916   6.584  1.00  0.00     0.236 C \nATOM    243  O   GLY    76      17.565  17.064   6.193  1.00  0.00    -0.272 OA\nATOM    244  H   GLY    76      17.702  12.875   5.947  1.00  0.00     0.163 HD\nATOM    245  N   LEU    77      18.864  15.570   7.261  1.00  0.00    -0.346 N \nATOM    246  CA  LEU    77      19.818  16.590   7.668  1.00  0.00     0.177 C \nATOM    247  C   LEU    77      20.554  17.221   6.488  1.00  0.00     0.241 C \nATOM    248  O   LEU    77      20.877  18.401   6.541  1.00  0.00    -0.271 OA\nATOM    249  CB  LEU    77      20.815  16.020   8.660  1.00  0.00     0.038 C \nATOM    250  CG  LEU    77      20.235  15.696  10.031  1.00  0.00    -0.020 C \nATOM    251  CD1 LEU    77      21.234  14.940  10.837  1.00  0.00     0.009 C \nATOM    252  CD2 LEU    77      19.791  16.934  10.762  1.00  0.00     0.009 C \nATOM    253  H   LEU    77      18.965  14.568   7.456  1.00  0.00     0.163 HD\nATOM    254  N   ALA    78      20.808  16.462   5.424  1.00  0.00    -0.346 N \nATOM    255  CA  ALA    78      21.581  16.968   4.295  1.00  0.00     0.172 C \nATOM    256  C   ALA    78      20.884  18.141   3.614  1.00  0.00     0.240 C \nATOM    257  O   ALA    78      21.533  19.032   3.088  1.00  0.00    -0.271 OA\nATOM    258  CB  ALA    78      21.839  15.872   3.289  1.00  0.00     0.042 C \nATOM    259  H   ALA    78      20.417  15.503   5.468  1.00  0.00     0.163 HD\nATOM    260  N   ALA    79      19.550  18.145   3.630  1.00  0.00    -0.346 N \nATOM    261  CA  ALA    79      18.752  19.184   2.970  1.00  0.00     0.172 C \nATOM    262  C   ALA    79      18.653  20.471   3.783  1.00  0.00     0.240 C \nATOM    263  O   ALA    79      18.143  21.473   3.292  1.00  0.00    -0.271 OA\nATOM    264  CB  ALA    79      17.360  18.646   2.708  1.00  0.00     0.042 C \nATOM    265  H   ALA    79      19.123  17.348   4.151  1.00  0.00     0.163 HD\nATOM    266  N   GLN    80      19.116  20.441   5.033  1.00  0.00    -0.346 N \nATOM    267  CA  GLN    80      19.085  21.596   5.919  1.00  0.00     0.177 C \nATOM    268  C   GLN    80      20.326  22.465   5.664  1.00  0.00     0.241 C \nATOM    269  O   GLN    80      20.956  22.333   4.625  1.00  0.00    -0.271 OA\nATOM    270  CB  GLN    80      18.933  21.118   7.359  1.00  0.00     0.044 C \nATOM    271  CG  GLN    80      17.629  20.324   7.551  1.00  0.00     0.105 C \nATOM    272  CD  GLN    80      17.451  19.716   8.934  1.00  0.00     0.215 C \nATOM    273  H   GLN    80      19.504  19.511   5.321  1.00  0.00     0.163 HD\nATOM    274 2HE2 GLN    80      15.838  18.690   8.271  1.00  0.00     0.159 HD\nATOM    275  OE1 GLN    80      18.187  20.005   9.855  1.00  0.00    -0.274 OA\nATOM    276  NE2 GLN    80      16.436  18.870   9.074  1.00  0.00    -0.370 N \nATOM    277 1HE2 GLN    80      16.259  18.410   9.969  1.00  0.00     0.159 HD\nATOM    278  N   GLU    81      20.643  23.377   6.573  1.00  0.00    -0.346 N \nATOM    279  CA  GLU    81      21.690  24.368   6.333  1.00  0.00     0.177 C \nATOM    280  C   GLU    81      23.011  23.942   6.965  1.00  0.00     0.241 C \nATOM    281  O   GLU    81      23.063  23.575   8.143  1.00  0.00    -0.271 OA\nATOM    282  CB  GLU    81      21.292  25.723   6.915  1.00  0.00     0.045 C \nATOM    283  CG  GLU    81      20.281  26.580   6.168  1.00  0.00     0.116 C \nATOM    284  CD  GLU    81      20.492  28.042   6.545  1.00  0.00     0.172 C \nATOM    285  OE1 GLU    81      21.004  28.826   5.719  1.00  0.00    -0.648 OA\nATOM    286  OE2 GLU    81      20.210  28.388   7.713  1.00  0.00    -0.648 OA\nATOM    287  H   GLU    81      20.095  23.328   7.453  1.00  0.00     0.163 HD\nATOM    288  N   TRP    82      24.055  24.069   6.162  1.00  0.00    -0.346 N \nATOM    289  CA  TRP    82      25.428  23.727   6.498  1.00  0.00     0.181 C \nATOM    290  C   TRP    82      26.323  24.892   6.106  1.00  0.00     0.241 C \nATOM    291  O   TRP    82      25.987  25.707   5.245  1.00  0.00    -0.271 OA\nATOM    292  CB  TRP    82      25.861  22.476   5.715  1.00  0.00     0.075 C \nATOM    293  CG  TRP    82      25.084  21.243   6.054  1.00  0.00    -0.028 A \nATOM    294  CD1 TRP    82      23.780  20.996   5.757  1.00  0.00     0.096 A \nATOM    295  CD2 TRP    82      25.558  20.090   6.748  1.00  0.00    -0.002 A \nATOM    296  NE1 TRP    82      23.407  19.771   6.247  1.00  0.00    -0.365 N \nATOM    297  CE2 TRP    82      24.477  19.195   6.865  1.00  0.00     0.042 A \nATOM    298  CE3 TRP    82      26.794  19.722   7.294  1.00  0.00     0.014 A \nATOM    299  CZ2 TRP    82      24.599  17.961   7.483  1.00  0.00     0.030 A \nATOM    300  CZ3 TRP    82      26.914  18.497   7.903  1.00  0.00     0.001 A \nATOM    301  CH2 TRP    82      25.832  17.632   7.997  1.00  0.00     0.002 A \nATOM    302  HE1 TRP    82      22.495  19.365   6.164  1.00  0.00     0.165 HD\nATOM    303  H   TRP    82      23.796  24.461   5.203  1.00  0.00     0.163 HD\nATOM    304  N   VAL    83      27.495  24.938   6.725  1.00  0.00    -0.346 N \nATOM    305  CA  VAL    83      28.558  25.853   6.334  1.00  0.00     0.180 C \nATOM    306  C   VAL    83      29.852  25.080   6.127  1.00  0.00     0.241 C \nATOM    307  O   VAL    83      30.092  24.049   6.745  1.00  0.00    -0.271 OA\nATOM    308  CB  VAL    83      28.792  26.978   7.383  1.00  0.00     0.009 C \nATOM    309  CG1 VAL    83      27.590  27.932   7.390  1.00  0.00     0.012 C \nATOM    310  CG2 VAL    83      29.071  26.406   8.787  1.00  0.00     0.012 C \nATOM    311  H   VAL    83      27.590  24.261   7.518  1.00  0.00     0.163 HD\nATOM    312  N   ALA    84      30.707  25.624   5.272  1.00  0.00    -0.346 N \nATOM    313  CA  ALA    84      32.110  25.240   5.201  1.00  0.00     0.172 C \nATOM    314  C   ALA    84      32.946  26.392   5.715  1.00  0.00     0.240 C \nATOM    315  O   ALA    84      32.764  27.514   5.253  1.00  0.00    -0.271 OA\nATOM    316  CB  ALA    84      32.527  24.920   3.791  1.00  0.00     0.042 C \nATOM    317  H   ALA    84      30.286  26.356   4.650  1.00  0.00     0.163 HD\nATOM    318  N   CYS    85      33.852  26.124   6.654  1.00  0.00    -0.345 N \nATOM    319  CA  CYS    85      34.795  27.114   7.154  1.00  0.00     0.185 C \nATOM    320  C   CYS    85      36.205  26.576   6.987  1.00  0.00     0.241 C \nATOM    321  O   CYS    85      36.421  25.390   6.800  1.00  0.00    -0.271 OA\nATOM    322  CB  CYS    85      34.535  27.427   8.627  1.00  0.00     0.105 C \nATOM    323  SG  CYS    85      32.869  28.017   9.012  1.00  0.00    -0.180 SA\nATOM    324  H   CYS    85      33.826  25.135   7.002  1.00  0.00     0.163 HD\nATOM    325  HG  CYS    85      32.923  28.736   9.704  1.00  0.00     0.101 HD\nATOM    326  N   GLU    86      37.190  27.455   7.078  1.00  0.00    -0.346 N \nATOM    327  CA  GLU    86      38.571  27.044   6.878  1.00  0.00     0.177 C \nATOM    328  C   GLU    86      39.020  26.076   7.969  1.00  0.00     0.241 C \nATOM    329  O   GLU    86      38.754  26.297   9.154  1.00  0.00    -0.271 OA\nATOM    330  CB  GLU    86      39.465  28.281   6.845  1.00  0.00     0.045 C \nATOM    331  CG  GLU    86      40.931  27.959   6.607  1.00  0.00     0.112 C \nATOM    332  CD  GLU    86      41.812  29.159   6.344  1.00  0.00     0.139 C \nATOM    333  OE1 GLU    86      41.342  30.314   6.471  1.00  0.00    -0.650 OA\nATOM    334  OE2 GLU    86      43.012  28.933   6.041  1.00  0.00    -0.776 OA\nATOM    335  HE2 GLU    86      43.594  29.670   5.865  1.00  0.00     0.167 HD\nATOM    336  H   GLU    86      36.903  28.423   7.295  1.00  0.00     0.163 HD\nATOM    337  N   LYS    87      39.723  25.026   7.552  1.00  0.00    -0.346 N \nATOM    338  CA  LYS    87      40.425  24.140   8.472  1.00  0.00     0.176 C \nATOM    339  C   LYS    87      41.850  24.659   8.607  1.00  0.00     0.241 C \nATOM    340  O   LYS    87      42.583  24.714   7.619  1.00  0.00    -0.271 OA\nATOM    341  CB  LYS    87      40.406  22.700   7.983  1.00  0.00     0.035 C \nATOM    342  CG  LYS    87      40.812  21.716   9.060  1.00  0.00     0.004 C \nATOM    343  CD  LYS    87      40.599  20.285   8.636  1.00  0.00     0.030 C \nATOM    344  CE  LYS    87      40.745  19.292   9.788  1.00  0.00     0.267 C \nATOM    345  NZ  LYS    87      42.137  19.250  10.300  1.00  0.00     0.078 N \nATOM    346  HZ1 LYS    87      42.749  18.980   9.553  1.00  0.00     0.312 HD\nATOM    347  HZ2 LYS    87      42.397  20.153  10.634  1.00  0.00     0.312 HD\nATOM    348  H   LYS    87      39.727  24.894   6.517  1.00  0.00     0.163 HD\nATOM    349  N   VAL    88      42.191  25.106   9.813  1.00  0.00    -0.346 N \nATOM    350  CA  VAL    88      43.484  25.722  10.086  1.00  0.00     0.180 C \nATOM    351  C   VAL    88      44.463  24.675  10.618  1.00  0.00     0.241 C \nATOM    352  O   VAL    88      44.131  23.888  11.506  1.00  0.00    -0.271 OA\nATOM    353  CB  VAL    88      43.302  26.914  11.068  1.00  0.00     0.009 C \nATOM    354  CG1 VAL    88      44.644  27.493  11.514  1.00  0.00     0.012 C \nATOM    355  CG2 VAL    88      42.459  27.975  10.373  1.00  0.00     0.012 C \nATOM    356  H   VAL    88      41.455  24.978  10.544  1.00  0.00     0.163 HD\nATOM    357  N   HIS    89      45.670  24.687  10.054  1.00  0.00    -0.346 N \nATOM    358  CA  HIS    89      46.730  23.760  10.416  1.00  0.00     0.182 C \nATOM    359  C   HIS    89      47.626  24.352  11.490  1.00  0.00     0.241 C \nATOM    360  O   HIS    89      48.645  24.992  11.200  1.00  0.00    -0.271 OA\nATOM    361  CB  HIS    89      47.539  23.442   9.194  1.00  0.00     0.095 C \nATOM    362  CG  HIS    89      48.572  22.385   9.383  1.00  0.00     0.053 A \nATOM    363  H   HIS    89      45.788  25.430   9.321  1.00  0.00     0.163 HD\nATOM    364  CD2 HIS    89      49.912  22.427   9.275  1.00  0.00     0.116 A \nATOM    365  HE2 HIS    89      51.297  20.830   9.202  1.00  0.00     0.166 HD\nATOM    366  CE1 HIS    89      49.367  20.386   9.781  1.00  0.00     0.207 A \nATOM    367  ND1 HIS    89      48.273  21.121   9.793  1.00  0.00    -0.247 NA\nATOM    368  NE2 HIS    89      50.363  21.139   9.389  1.00  0.00    -0.359 N \nATOM    369  N   GLY    90      47.212  24.171  12.734  1.00  0.00    -0.351 N \nATOM    370  CA  GLY    90      47.977  24.569  13.905  1.00  0.00     0.225 C \nATOM    371  C   GLY    90      47.968  23.416  14.884  1.00  0.00     0.236 C \nATOM    372  O   GLY    90      48.231  22.268  14.522  1.00  0.00    -0.272 OA\nATOM    373  H   GLY    90      46.268  23.708  12.806  1.00  0.00     0.163 HD\nATOM    374  N   THR    91      47.650  23.727  16.133  1.00  0.00    -0.344 N \nATOM    375  CA  THR    91      47.488  22.698  17.144  1.00  0.00     0.205 C \nATOM    376  C   THR    91      46.227  23.006  17.947  1.00  0.00     0.243 C \nATOM    377  O   THR    91      45.848  24.161  18.123  1.00  0.00    -0.271 OA\nATOM    378  CB  THR    91      48.776  22.587  17.981  1.00  0.00     0.146 C \nATOM    379  OG1 THR    91      48.738  21.401  18.776  1.00  0.00    -0.393 OA\nATOM    380  CG2 THR    91      48.947  23.756  18.929  1.00  0.00     0.042 C \nATOM    381  H   THR    91      47.531  24.740  16.317  1.00  0.00     0.163 HD\nATOM    382  HG1 THR    91      48.003  21.460  19.461  1.00  0.00     0.210 HD\nATOM    383  N   ASN    92      45.560  21.960  18.391  1.00  0.00    -0.345 N \nATOM    384  CA  ASN    92      44.301  22.113  19.093  1.00  0.00     0.185 C \nATOM    385  C   ASN    92      44.489  22.853  20.414  1.00  0.00     0.241 C \nATOM    386  O   ASN    92      45.438  22.578  21.157  1.00  0.00    -0.271 OA\nATOM    387  CB  ASN    92      43.702  20.727  19.353  1.00  0.00     0.137 C \nATOM    388  CG  ASN    92      42.298  20.794  19.874  1.00  0.00     0.217 C \nATOM    389  H   ASN    92      46.003  21.040  18.199  1.00  0.00     0.163 HD\nATOM    390  OD1 ASN    92      42.067  20.782  21.077  1.00  0.00    -0.274 OA\nATOM    391  ND2 ASN    92      41.350  20.907  18.972  1.00  0.00    -0.370 N \nATOM    392 2HD2 ASN    92      40.379  20.963  19.251  1.00  0.00     0.159 HD\nATOM    393 1HD2 ASN    92      41.576  20.938  17.995  1.00  0.00     0.159 HD\nATOM    394  N   PHE    93      43.585  23.765  20.710  1.00  0.00    -0.346 N \nATOM    395  CA  PHE    93      43.744  24.595  21.888  1.00  0.00     0.180 C \nATOM    396  C   PHE    93      42.372  24.872  22.491  1.00  0.00     0.241 C \nATOM    397  O   PHE    93      41.336  24.938  21.797  1.00  0.00    -0.271 OA\nATOM    398  CB  PHE    93      44.514  25.854  21.484  1.00  0.00     0.073 C \nATOM    399  CG  PHE    93      45.044  26.656  22.642  1.00  0.00    -0.056 A \nATOM    400  CD1 PHE    93      46.235  26.319  23.260  1.00  0.00     0.007 A \nATOM    401  CD2 PHE    93      44.360  27.767  23.113  1.00  0.00     0.007 A \nATOM    402  CE1 PHE    93      46.720  27.067  24.325  1.00  0.00     0.001 A \nATOM    403  CE2 PHE    93      44.847  28.519  24.178  1.00  0.00     0.001 A \nATOM    404  CZ  PHE    93      46.031  28.162  24.776  1.00  0.00     0.000 A \nATOM    405  H   PHE    93      42.789  23.833  20.058  1.00  0.00     0.163 HD\nATOM    406  N   GLY    94      42.300  24.959  23.791  1.00  0.00    -0.351 N \nATOM    407  CA  GLY    94      41.063  25.306  24.447  1.00  0.00     0.225 C \nATOM    408  C   GLY    94      41.307  26.336  25.528  1.00  0.00     0.236 C \nATOM    409  O   GLY    94      42.275  26.237  26.289  1.00  0.00    -0.272 OA\nATOM    410  H   GLY    94      43.185  24.763  24.302  1.00  0.00     0.163 HD\nATOM    411  N   ILE    95      40.417  27.313  25.600  1.00  0.00    -0.346 N \nATOM    412  CA  ILE    95      40.413  28.316  26.652  1.00  0.00     0.180 C \nATOM    413  C   ILE    95      39.185  28.061  27.513  1.00  0.00     0.241 C \nATOM    414  O   ILE    95      38.057  28.034  27.030  1.00  0.00    -0.271 OA\nATOM    415  CB  ILE    95      40.343  29.725  26.042  1.00  0.00     0.013 C \nATOM    416  CG1 ILE    95      41.534  29.973  25.112  1.00  0.00     0.002 C \nATOM    417  CG2 ILE    95      40.270  30.771  27.132  1.00  0.00     0.012 C \nATOM    418  CD1 ILE    95      41.367  31.118  24.145  1.00  0.00     0.005 C \nATOM    419  H   ILE    95      39.706  27.302  24.824  1.00  0.00     0.163 HD\nATOM    420  N   TYR    96      39.433  27.859  28.798  1.00  0.00    -0.346 N \nATOM    421  CA  TYR    96      38.417  27.482  29.757  1.00  0.00     0.180 C \nATOM    422  C   TYR    96      38.202  28.577  30.791  1.00  0.00     0.241 C \nATOM    423  O   TYR    96      39.158  29.130  31.312  1.00  0.00    -0.271 OA\nATOM    424  CB  TYR    96      38.872  26.235  30.517  1.00  0.00     0.073 C \nATOM    425  CG  TYR    96      38.843  24.964  29.703  1.00  0.00    -0.056 A \nATOM    426  CD1 TYR    96      37.934  23.971  29.993  1.00  0.00     0.010 A \nATOM    427  CD2 TYR    96      39.720  24.749  28.639  1.00  0.00     0.010 A \nATOM    428  CE1 TYR    96      37.871  22.814  29.270  1.00  0.00     0.037 A \nATOM    429  CE2 TYR    96      39.659  23.587  27.890  1.00  0.00     0.037 A \nATOM    430  CZ  TYR    96      38.726  22.620  28.218  1.00  0.00     0.065 A \nATOM    431  OH  TYR    96      38.628  21.447  27.518  1.00  0.00    -0.361 OA\nATOM    432  H   TYR    96      40.443  27.998  29.063  1.00  0.00     0.163 HD\nATOM    433  HH  TYR    96      39.514  21.231  27.108  1.00  0.00     0.217 HD\nATOM    434  N   LEU    97      36.940  28.832  31.123  1.00  0.00    -0.346 N \nATOM    435  CA  LEU    97      36.602  29.617  32.301  1.00  0.00     0.177 C \nATOM    436  C   LEU    97      35.731  28.717  33.170  1.00  0.00     0.241 C \nATOM    437  O   LEU    97      34.679  28.249  32.754  1.00  0.00    -0.271 OA\nATOM    438  CB  LEU    97      35.855  30.893  31.933  1.00  0.00     0.038 C \nATOM    439  CG  LEU    97      35.619  31.870  33.083  1.00  0.00    -0.020 C \nATOM    440  CD1 LEU    97      36.893  32.376  33.661  1.00  0.00     0.009 C \nATOM    441  CD2 LEU    97      34.813  33.035  32.587  1.00  0.00     0.009 C \nATOM    442  H   LEU    97      36.231  28.429  30.479  1.00  0.00     0.163 HD\nATOM    443  N   ILE    98      36.192  28.453  34.388  1.00  0.00    -0.346 N \nATOM    444  CA  ILE    98      35.572  27.483  35.291  1.00  0.00     0.180 C \nATOM    445  C   ILE    98      35.063  28.195  36.537  1.00  0.00     0.241 C \nATOM    446  O   ILE    98      35.846  28.803  37.223  1.00  0.00    -0.271 OA\nATOM    447  CB  ILE    98      36.626  26.432  35.705  1.00  0.00     0.013 C \nATOM    448  CG1 ILE    98      37.266  25.760  34.478  1.00  0.00     0.002 C \nATOM    449  CG2 ILE    98      36.041  25.420  36.713  1.00  0.00     0.012 C \nATOM    450  CD1 ILE    98      36.407  24.977  33.692  1.00  0.00     0.005 C \nATOM    451  H   ILE    98      37.046  29.003  34.651  1.00  0.00     0.163 HD\nATOM    452  N   ASN    99      33.755  28.126  36.771  1.00  0.00    -0.346 N \nATOM    453  CA  ASN    99      33.124  28.671  37.963  1.00  0.00     0.185 C \nATOM    454  C   ASN    99      33.287  27.740  39.147  1.00  0.00     0.241 C \nATOM    455  O   ASN    99      33.064  26.526  39.060  1.00  0.00    -0.271 OA\nATOM    456  CB  ASN    99      31.634  28.888  37.739  1.00  0.00     0.137 C \nATOM    457  CG  ASN    99      30.971  29.502  38.937  1.00  0.00     0.217 C \nATOM    458  H   ASN    99      33.213  27.639  36.013  1.00  0.00     0.163 HD\nATOM    459  OD1 ASN    99      30.409  28.800  39.777  1.00  0.00    -0.274 OA\nATOM    460  ND2 ASN    99      31.073  30.813  39.052  1.00  0.00    -0.370 N \nATOM    461 2HD2 ASN    99      30.656  31.291  39.836  1.00  0.00     0.159 HD\nATOM    462 1HD2 ASN    99      31.566  31.346  38.360  1.00  0.00     0.159 HD\nATOM    463  N   GLN   100      33.694  28.340  40.249  1.00  0.00    -0.346 N \nATOM    464  CA  GLN   100      33.844  27.655  41.518  1.00  0.00     0.177 C \nATOM    465  C   GLN   100      33.106  28.467  42.579  1.00  0.00     0.240 C \nATOM    466  O   GLN   100      33.696  28.935  43.547  1.00  0.00    -0.271 OA\nATOM    467  CB  GLN   100      35.326  27.532  41.833  1.00  0.00     0.044 C \nATOM    468  CG  GLN   100      36.072  26.694  40.803  1.00  0.00     0.105 C \nATOM    469  CD  GLN   100      37.569  26.712  40.988  1.00  0.00     0.215 C \nATOM    470  H   GLN   100      33.902  29.365  40.129  1.00  0.00     0.163 HD\nATOM    471 2HE2 GLN   100      37.732  25.066  39.822  1.00  0.00     0.159 HD\nATOM    472  OE1 GLN   100      38.112  27.582  41.673  1.00  0.00    -0.274 OA\nATOM    473  NE2 GLN   100      38.248  25.753  40.365  1.00  0.00    -0.370 N \nATOM    474 1HE2 GLN   100      39.266  25.708  40.432  1.00  0.00     0.159 HD\nATOM    475  N   GLY   101      31.803  28.633  42.384  1.00  0.00    -0.351 N \nATOM    476  CA  GLY   101      30.973  29.381  43.319  1.00  0.00     0.225 C \nATOM    477  C   GLY   101      31.099  30.883  43.122  1.00  0.00     0.236 C \nATOM    478  O   GLY   101      30.743  31.399  42.061  1.00  0.00    -0.272 OA\nATOM    479  H   GLY   101      31.432  28.189  41.519  1.00  0.00     0.163 HD\nATOM    480  N   ASP   102      31.617  31.594  44.126  1.00  0.00    -0.346 N \nATOM    481  CA  ASP   102      31.788  33.054  44.029  1.00  0.00     0.186 C \nATOM    482  C   ASP   102      33.144  33.431  43.435  1.00  0.00     0.241 C \nATOM    483  O   ASP   102      33.490  34.611  43.376  1.00  0.00    -0.271 OA\nATOM    484  CB  ASP   102      31.616  33.777  45.382  1.00  0.00     0.147 C \nATOM    485  CG  ASP   102      31.047  32.897  46.460  1.00  0.00     0.175 C \nATOM    486  OD1 ASP   102      29.909  32.403  46.292  1.00  0.00    -0.648 OA\nATOM    487  OD2 ASP   102      31.670  32.656  47.515  1.00  0.00    -0.648 OA\nATOM    488  H   ASP   102      31.883  31.045  44.961  1.00  0.00     0.163 HD\nATOM    489  N   HIS   103      33.911  32.430  43.012  1.00  0.00    -0.346 N \nATOM    490  CA  HIS   103      35.153  32.661  42.291  1.00  0.00     0.182 C \nATOM    491  C   HIS   103      35.204  31.797  41.031  1.00  0.00     0.241 C \nATOM    492  O   HIS   103      34.331  30.965  40.802  1.00  0.00    -0.271 OA\nATOM    493  CB  HIS   103      36.371  32.411  43.196  1.00  0.00     0.093 C \nATOM    494  CG  HIS   103      36.353  31.089  43.900  1.00  0.00     0.030 A \nATOM    495  H   HIS   103      33.548  31.481  43.240  1.00  0.00     0.163 HD\nATOM    496  CD2 HIS   103      37.063  29.958  43.684  1.00  0.00     0.143 A \nATOM    497  HD1 HIS   103      34.910  31.486  45.400  1.00  0.00     0.166 HD\nATOM    498  CE1 HIS   103      35.757  29.598  45.410  1.00  0.00     0.207 A \nATOM    499  ND1 HIS   103      35.549  30.835  44.992  1.00  0.00    -0.353 N \nATOM    500  NE2 HIS   103      36.668  29.043  44.630  1.00  0.00    -0.254 NA\nATOM    501  N   GLU   104      36.231  32.023  40.225  1.00  0.00    -0.346 N \nATOM    502  CA  GLU   104      36.398  31.323  38.945  1.00  0.00     0.177 C \nATOM    503  C   GLU   104      37.862  31.314  38.534  1.00  0.00     0.241 C \nATOM    504  O   GLU   104      38.674  32.078  39.031  1.00  0.00    -0.271 OA\nATOM    505  CB  GLU   104      35.565  31.995  37.846  1.00  0.00     0.045 C \nATOM    506  CG  GLU   104      36.061  33.384  37.446  1.00  0.00     0.116 C \nATOM    507  CD  GLU   104      35.096  34.158  36.557  1.00  0.00     0.172 C \nATOM    508  OE1 GLU   104      33.900  33.789  36.452  1.00  0.00    -0.648 OA\nATOM    509  OE2 GLU   104      35.544  35.162  35.956  1.00  0.00    -0.648 OA\nATOM    510  H   GLU   104      36.910  32.736  40.571  1.00  0.00     0.163 HD\nATOM    511  N   VAL   105      38.184  30.479  37.558  1.00  0.00    -0.346 N \nATOM    512  CA  VAL   105      39.554  30.302  37.113  1.00  0.00     0.180 C \nATOM    513  C   VAL   105      39.618  30.150  35.600  1.00  0.00     0.241 C \nATOM    514  O   VAL   105      38.731  29.550  34.994  1.00  0.00    -0.271 OA\nATOM    515  CB  VAL   105      40.213  29.085  37.794  1.00  0.00     0.009 C \nATOM    516  CG1 VAL   105      39.512  27.779  37.517  1.00  0.00     0.012 C \nATOM    517  CG2 VAL   105      41.627  28.999  37.422  1.00  0.00     0.012 C \nATOM    518  H   VAL   105      37.376  29.966  37.142  1.00  0.00     0.163 HD\nATOM    519  N   VAL   106      40.686  30.681  35.023  1.00  0.00    -0.346 N \nATOM    520  CA  VAL   106      40.963  30.535  33.590  1.00  0.00     0.180 C \nATOM    521  C   VAL   106      42.037  29.464  33.416  1.00  0.00     0.241 C \nATOM    522  O   VAL   106      43.063  29.491  34.094  1.00  0.00    -0.271 OA\nATOM    523  CB  VAL   106      41.450  31.863  32.985  1.00  0.00     0.009 C \nATOM    524  CG1 VAL   106      41.789  31.708  31.521  1.00  0.00     0.012 C \nATOM    525  CG2 VAL   106      40.417  32.966  33.137  1.00  0.00     0.012 C \nATOM    526  H   VAL   106      41.313  31.210  35.668  1.00  0.00     0.163 HD\nATOM    527  N   ARG   107      41.799  28.513  32.520  1.00  0.00    -0.346 N \nATOM    528  CA  ARG   107      42.738  27.431  32.247  1.00  0.00     0.176 C \nATOM    529  C   ARG   107      42.893  27.256  30.746  1.00  0.00     0.241 C \nATOM    530  O   ARG   107      42.010  27.651  29.969  1.00  0.00    -0.271 OA\nATOM    531  CB  ARG   107      42.226  26.126  32.877  1.00  0.00     0.036 C \nATOM    532  CG  ARG   107      42.115  26.154  34.398  1.00  0.00     0.023 C \nATOM    533  CD  ARG   107      43.470  26.004  35.041  1.00  0.00     0.138 C \nATOM    534  NE  ARG   107      43.418  25.960  36.499  1.00  0.00    -0.227 N \nATOM    535  CZ  ARG   107      43.725  26.971  37.305  1.00  0.00     0.665 C \nATOM    536  NH1 ARG   107      44.081  28.160  36.812  1.00  0.00    -0.235 N \nATOM    537  NH2 ARG   107      43.643  26.809  38.623  1.00  0.00    -0.235 N \nATOM    538  HE  ARG   107      43.125  25.092  36.931  1.00  0.00     0.177 HD\nATOM    539 2HH2 ARG   107      43.889  27.557  39.236  1.00  0.00     0.174 HD\nATOM    540 1HH2 ARG   107      43.332  25.935  39.000  1.00  0.00     0.174 HD\nATOM    541  H   ARG   107      40.880  28.606  32.027  1.00  0.00     0.163 HD\nATOM    542 2HH1 ARG   107      44.326  28.902  37.437  1.00  0.00     0.174 HD\nATOM    543 1HH1 ARG   107      44.100  28.305  35.826  1.00  0.00     0.174 HD\nATOM    544  N   PHE   108      44.002  26.642  30.358  1.00  0.00    -0.346 N \nATOM    545  CA  PHE   108      44.342  26.451  28.953  1.00  0.00     0.180 C \nATOM    546  C   PHE   108      44.654  24.994  28.698  1.00  0.00     0.241 C \nATOM    547  O   PHE   108      45.341  24.356  29.500  1.00  0.00    -0.271 OA\nATOM    548  CB  PHE   108      45.515  27.347  28.570  1.00  0.00     0.073 C \nATOM    549  CG  PHE   108      45.228  28.792  28.811  1.00  0.00    -0.056 A \nATOM    550  CD1 PHE   108      44.420  29.487  27.931  1.00  0.00     0.007 A \nATOM    551  CD2 PHE   108      45.681  29.445  29.948  1.00  0.00     0.007 A \nATOM    552  CE1 PHE   108      44.107  30.811  28.163  1.00  0.00     0.001 A \nATOM    553  CE2 PHE   108      45.371  30.771  30.170  1.00  0.00     0.001 A \nATOM    554  CZ  PHE   108      44.577  31.449  29.293  1.00  0.00     0.000 A \nATOM    555  H   PHE   108      44.609  26.308  31.141  1.00  0.00     0.163 HD\nATOM    556  N   ALA   109      44.159  24.481  27.572  1.00  0.00    -0.346 N \nATOM    557  CA  ALA   109      44.329  23.078  27.230  1.00  0.00     0.172 C \nATOM    558  C   ALA   109      44.941  22.919  25.860  1.00  0.00     0.240 C \nATOM    559  O   ALA   109      44.664  23.676  24.928  1.00  0.00    -0.271 OA\nATOM    560  CB  ALA   109      43.026  22.353  27.254  1.00  0.00     0.042 C \nATOM    561  H   ALA   109      43.651  25.162  26.973  1.00  0.00     0.163 HD\nATOM    562  N   LYS   110      45.758  21.876  25.744  1.00  0.00    -0.346 N \nATOM    563  CA  LYS   110      46.210  21.340  24.464  1.00  0.00     0.176 C \nATOM    564  C   LYS   110      45.340  20.122  24.132  1.00  0.00     0.241 C \nATOM    565  O   LYS   110      44.358  19.851  24.815  1.00  0.00    -0.271 OA\nATOM    566  CB  LYS   110      47.707  21.005  24.526  1.00  0.00     0.035 C \nATOM    567  CG  LYS   110      48.100  20.021  25.607  1.00  0.00     0.004 C \nATOM    568  CD  LYS   110      49.601  19.769  25.628  1.00  0.00     0.027 C \nATOM    569  CE  LYS   110      49.979  18.842  26.751  1.00  0.00     0.229 C \nATOM    570  NZ  LYS   110      51.442  18.589  26.775  1.00  0.00    -0.079 N \nATOM    571  HZ1 LYS   110      51.926  19.448  26.943  1.00  0.00     0.274 HD\nATOM    572  HZ3 LYS   110      51.656  17.937  27.503  1.00  0.00     0.274 HD\nATOM    573  HZ2 LYS   110      51.729  18.211  25.895  1.00  0.00     0.274 HD\nATOM    574  H   LYS   110      46.055  21.464  26.666  1.00  0.00     0.163 HD\nATOM    575  N   ARG   111      45.694  19.367  23.103  1.00  0.00    -0.346 N \nATOM    576  CA  ARG   111      44.888  18.243  22.666  1.00  0.00     0.176 C \nATOM    577  C   ARG   111      44.595  17.264  23.785  1.00  0.00     0.241 C \nATOM    578  O   ARG   111      43.484  16.732  23.888  1.00  0.00    -0.271 OA\nATOM    579  CB  ARG   111      45.630  17.522  21.531  1.00  0.00     0.036 C \nATOM    580  CG  ARG   111      45.165  16.130  21.170  1.00  0.00     0.023 C \nATOM    581  CD  ARG   111      43.858  16.171  20.472  1.00  0.00     0.138 C \nATOM    582  NE  ARG   111      43.955  16.802  19.140  1.00  0.00    -0.227 N \nATOM    583  CZ  ARG   111      42.902  17.211  18.428  1.00  0.00     0.665 C \nATOM    584  NH1 ARG   111      41.679  17.073  18.925  1.00  0.00    -0.235 N \nATOM    585  NH2 ARG   111      43.064  17.777  17.234  1.00  0.00    -0.235 N \nATOM    586  HE  ARG   111      44.869  16.929  18.750  1.00  0.00     0.177 HD\nATOM    587 2HH2 ARG   111      42.282  18.062  16.701  1.00  0.00     0.174 HD\nATOM    588 1HH2 ARG   111      43.994  17.915  16.875  1.00  0.00     0.174 HD\nATOM    589  H   ARG   111      46.586  19.647  22.644  1.00  0.00     0.163 HD\nATOM    590 2HH1 ARG   111      40.887  17.369  18.370  1.00  0.00     0.174 HD\nATOM    591 1HH1 ARG   111      41.539  16.687  19.829  1.00  0.00     0.174 HD\nATOM    592  N   SER   112      45.608  17.005  24.597  1.00  0.00    -0.344 N \nATOM    593  CA  SER   112      45.563  15.939  25.586  1.00  0.00     0.200 C \nATOM    594  C   SER   112      45.229  16.353  27.002  1.00  0.00     0.242 C \nATOM    595  O   SER   112      45.206  15.493  27.868  1.00  0.00    -0.271 OA\nATOM    596  CB  SER   112      46.897  15.198  25.579  1.00  0.00     0.199 C \nATOM    597  OG  SER   112      47.950  16.093  25.876  1.00  0.00    -0.398 OA\nATOM    598  H   SER   112      46.438  17.628  24.468  1.00  0.00     0.163 HD\nATOM    599  HG  SER   112      48.270  16.525  25.033  1.00  0.00     0.209 HD\nATOM    600  N   GLY   113      44.960  17.629  27.263  1.00  0.00    -0.350 N \nATOM    601  CA  GLY   113      44.524  18.021  28.587  1.00  0.00     0.225 C \nATOM    602  C   GLY   113      44.823  19.451  28.915  1.00  0.00     0.236 C \nATOM    603  O   GLY   113      45.505  20.161  28.178  1.00  0.00    -0.272 OA\nATOM    604  H   GLY   113      45.085  18.277  26.474  1.00  0.00     0.163 HD\nATOM    605  N   ILE   114      44.272  19.892  30.039  1.00  0.00    -0.347 N \nATOM    606  CA  ILE   114      44.609  21.180  30.623  1.00  0.00     0.166 C \nATOM    607  C   ILE   114      46.071  21.154  31.085  1.00  0.00     0.219 C \nATOM    608  O   ILE   114      46.553  20.159  31.643  1.00  0.00    -0.287 OA\nATOM    609  CB  ILE   114      43.634  21.521  31.770  1.00  0.00     0.012 C \nATOM    610  CG1 ILE   114      42.280  21.933  31.182  1.00  0.00     0.002 C \nATOM    611  CG2 ILE   114      44.175  22.643  32.645  1.00  0.00     0.012 C \nATOM    612  CD1 ILE   114      41.160  22.050  32.203  1.00  0.00     0.005 C \nATOM    613  H   ILE   114      43.578  19.236  30.465  1.00  0.00     0.163 HD\nATOM    614  N   ASP   116      49.598  22.540  33.015  1.00  0.00    -0.326 NA\nATOM    615  CA  ASP   116      50.231  23.259  34.090  1.00  0.00     0.201 C \nATOM    616  C   ASP   116      50.637  24.634  33.566  1.00  0.00     0.245 C \nATOM    617  O   ASP   116      51.114  24.729  32.441  1.00  0.00    -0.271 OA\nATOM    618  CB  ASP   116      51.465  22.494  34.566  1.00  0.00     0.149 C \nATOM    619  CG  ASP   116      52.129  23.152  35.737  1.00  0.00     0.175 C \nATOM    620  OD1 ASP   116      51.845  22.754  36.883  1.00  0.00    -0.648 OA\nATOM    621  OD2 ASP   116      52.931  24.074  35.589  1.00  0.00    -0.648 OA\nATOM    622  H   ASP   116      49.435  22.853  32.078  1.00  0.00     0.180 HD\nATOM    623  N   PRO   117      50.465  25.691  34.358  1.00  0.00    -0.337 N \nATOM    624  CA  PRO   117      50.810  27.039  33.876  1.00  0.00     0.179 C \nATOM    625  C   PRO   117      52.275  27.245  33.468  1.00  0.00     0.241 C \nATOM    626  O   PRO   117      52.540  28.195  32.739  1.00  0.00    -0.271 OA\nATOM    627  CB  PRO   117      50.448  27.940  35.058  1.00  0.00     0.037 C \nATOM    628  CG  PRO   117      49.481  27.171  35.833  1.00  0.00     0.022 C \nATOM    629  CD  PRO   117      49.874  25.734  35.707  1.00  0.00     0.127 C \nATOM    630  N   ASN   118      53.195  26.393  33.919  1.00  0.00    -0.346 N \nATOM    631  CA  ASN   118      54.593  26.514  33.522  1.00  0.00     0.185 C \nATOM    632  C   ASN   118      55.027  25.540  32.428  1.00  0.00     0.241 C \nATOM    633  O   ASN   118      56.213  25.429  32.133  1.00  0.00    -0.271 OA\nATOM    634  CB  ASN   118      55.507  26.458  34.742  1.00  0.00     0.137 C \nATOM    635  CG  ASN   118      55.484  27.751  35.500  1.00  0.00     0.217 C \nATOM    636  H   ASN   118      52.839  25.661  34.556  1.00  0.00     0.163 HD\nATOM    637  OD1 ASN   118      55.715  28.815  34.928  1.00  0.00    -0.274 OA\nATOM    638  ND2 ASN   118      55.193  27.678  36.782  1.00  0.00    -0.370 N \nATOM    639 2HD2 ASN   118      55.155  28.509  37.350  1.00  0.00     0.159 HD\nATOM    640 1HD2 ASN   118      55.006  26.788  37.210  1.00  0.00     0.159 HD\nATOM    641  N   GLU   119      54.072  24.886  31.777  1.00  0.00    -0.346 N \nATOM    642  CA  GLU   119      54.397  24.127  30.576  1.00  0.00     0.177 C \nATOM    643  C   GLU   119      54.558  25.080  29.396  1.00  0.00     0.241 C \nATOM    644  O   GLU   119      53.618  25.777  29.030  1.00  0.00    -0.271 OA\nATOM    645  CB  GLU   119      53.327  23.082  30.240  1.00  0.00     0.045 C \nATOM    646  CG  GLU   119      53.690  22.332  28.961  1.00  0.00     0.116 C \nATOM    647  CD  GLU   119      52.706  21.276  28.511  1.00  0.00     0.172 C \nATOM    648  OE1 GLU   119      51.808  20.897  29.276  1.00  0.00    -0.648 OA\nATOM    649  OE2 GLU   119      52.853  20.804  27.364  1.00  0.00    -0.648 OA\nATOM    650  H   GLU   119      53.129  24.960  32.177  1.00  0.00     0.163 HD\nATOM    651  N   ASN   120      55.758  25.116  28.828  1.00  0.00    -0.346 N \nATOM    652  CA  ASN   120      56.008  25.849  27.595  1.00  0.00     0.185 C \nATOM    653  C   ASN   120      55.334  25.101  26.450  1.00  0.00     0.241 C \nATOM    654  O   ASN   120      55.632  23.941  26.216  1.00  0.00    -0.271 OA\nATOM    655  CB  ASN   120      57.513  25.976  27.344  1.00  0.00     0.137 C \nATOM    656  CG  ASN   120      57.836  26.798  26.106  1.00  0.00     0.217 C \nATOM    657  H   ASN   120      56.494  24.581  29.335  1.00  0.00     0.163 HD\nATOM    658  OD1 ASN   120      57.098  27.713  25.741  1.00  0.00    -0.274 OA\nATOM    659  ND2 ASN   120      58.960  26.488  25.473  1.00  0.00    -0.370 N \nATOM    660 2HD2 ASN   120      59.231  26.996  24.655  1.00  0.00     0.159 HD\nATOM    661 1HD2 ASN   120      59.538  25.745  25.813  1.00  0.00     0.159 HD\nATOM    662  N   PHE   121      54.407  25.762  25.768  1.00  0.00    -0.346 N \nATOM    663  CA  PHE   121      53.654  25.159  24.671  1.00  0.00     0.180 C \nATOM    664  C   PHE   121      53.513  26.178  23.546  1.00  0.00     0.241 C \nATOM    665  O   PHE   121      52.587  26.996  23.509  1.00  0.00    -0.271 OA\nATOM    666  CB  PHE   121      52.304  24.691  25.182  1.00  0.00     0.073 C \nATOM    667  CG  PHE   121      51.474  23.991  24.154  1.00  0.00    -0.056 A \nATOM    668  CD1 PHE   121      51.737  22.680  23.811  1.00  0.00     0.007 A \nATOM    669  CD2 PHE   121      50.403  24.632  23.549  1.00  0.00     0.007 A \nATOM    670  CE1 PHE   121      50.958  22.022  22.872  1.00  0.00     0.001 A \nATOM    671  CE2 PHE   121      49.628  23.973  22.610  1.00  0.00     0.001 A \nATOM    672  CZ  PHE   121      49.902  22.665  22.287  1.00  0.00     0.000 A \nATOM    673  H   PHE   121      54.261  26.749  26.081  1.00  0.00     0.163 HD\nATOM    674  N   PHE   122      54.482  26.143  22.648  1.00  0.00    -0.346 N \nATOM    675  CA  PHE   122      54.491  26.952  21.442  1.00  0.00     0.180 C \nATOM    676  C   PHE   122      54.350  28.445  21.728  1.00  0.00     0.241 C \nATOM    677  O   PHE   122      53.843  29.191  20.903  1.00  0.00    -0.271 OA\nATOM    678  CB  PHE   122      53.418  26.473  20.464  1.00  0.00     0.073 C \nATOM    679  CG  PHE   122      53.603  25.052  20.018  1.00  0.00    -0.056 A \nATOM    680  CD1 PHE   122      54.737  24.670  19.311  1.00  0.00     0.007 A \nATOM    681  CD2 PHE   122      52.630  24.099  20.257  1.00  0.00     0.007 A \nATOM    682  CE1 PHE   122      54.907  23.372  18.890  1.00  0.00     0.001 A \nATOM    683  CE2 PHE   122      52.785  22.808  19.810  1.00  0.00     0.001 A \nATOM    684  CZ  PHE   122      53.922  22.441  19.119  1.00  0.00     0.000 A \nATOM    685  H   PHE   122      55.258  25.469  22.884  1.00  0.00     0.163 HD\nATOM    686  N   GLY   123      54.840  28.891  22.883  1.00  0.00    -0.351 N \nATOM    687  CA  GLY   123      54.855  30.307  23.196  1.00  0.00     0.225 C \nATOM    688  C   GLY   123      53.510  30.920  23.516  1.00  0.00     0.236 C \nATOM    689  O   GLY   123      53.404  32.151  23.519  1.00  0.00    -0.272 OA\nATOM    690  H   GLY   123      55.198  28.154  23.517  1.00  0.00     0.163 HD\nATOM    691  N   TYR   124      52.490  30.105  23.815  1.00  0.00    -0.346 N \nATOM    692  CA  TYR   124      51.128  30.639  23.913  1.00  0.00     0.180 C \nATOM    693  C   TYR   124      50.976  31.628  25.049  1.00  0.00     0.241 C \nATOM    694  O   TYR   124      50.046  32.412  25.055  1.00  0.00    -0.271 OA\nATOM    695  CB  TYR   124      50.072  29.528  24.050  1.00  0.00     0.073 C \nATOM    696  CG  TYR   124      49.862  29.041  25.461  1.00  0.00    -0.056 A \nATOM    697  CD1 TYR   124      48.870  29.605  26.262  1.00  0.00     0.010 A \nATOM    698  CD2 TYR   124      50.652  28.044  26.000  1.00  0.00     0.010 A \nATOM    699  CE1 TYR   124      48.669  29.184  27.555  1.00  0.00     0.037 A \nATOM    700  CE2 TYR   124      50.466  27.618  27.301  1.00  0.00     0.037 A \nATOM    701  CZ  TYR   124      49.465  28.182  28.072  1.00  0.00     0.065 A \nATOM    702  OH  TYR   124      49.280  27.772  29.363  1.00  0.00    -0.361 OA\nATOM    703  H   TYR   124      52.737  29.122  23.962  1.00  0.00     0.163 HD\nATOM    704  HH  TYR   124      50.105  27.308  29.686  1.00  0.00     0.217 HD\nATOM    705  N   HIS   125      51.896  31.605  26.006  1.00  0.00    -0.346 N \nATOM    706  CA  HIS   125      51.852  32.570  27.082  1.00  0.00     0.182 C \nATOM    707  C   HIS   125      51.810  34.008  26.575  1.00  0.00     0.241 C \nATOM    708  O   HIS   125      51.269  34.862  27.273  1.00  0.00    -0.271 OA\nATOM    709  CB  HIS   125      53.024  32.380  28.042  1.00  0.00     0.095 C \nATOM    710  CG  HIS   125      52.969  31.081  28.758  1.00  0.00     0.053 A \nATOM    711  H   HIS   125      52.611  30.868  25.913  1.00  0.00     0.163 HD\nATOM    712  CD2 HIS   125      52.537  30.761  29.998  1.00  0.00     0.116 A \nATOM    713  HE2 HIS   125      52.439  28.866  30.941  1.00  0.00     0.166 HD\nATOM    714  CE1 HIS   125      53.158  28.910  29.000  1.00  0.00     0.207 A \nATOM    715  ND1 HIS   125      53.320  29.901  28.148  1.00  0.00    -0.247 NA\nATOM    716  NE2 HIS   125      52.671  29.400  30.127  1.00  0.00    -0.359 N \nATOM    717  N   ILE   126      52.356  34.278  25.382  1.00  0.00    -0.346 N \nATOM    718  CA  ILE   126      52.320  35.625  24.794  1.00  0.00     0.180 C \nATOM    719  C   ILE   126      50.874  36.118  24.576  1.00  0.00     0.241 C \nATOM    720  O   ILE   126      50.637  37.332  24.518  1.00  0.00    -0.271 OA\nATOM    721  CB  ILE   126      53.146  35.657  23.465  1.00  0.00     0.013 C \nATOM    722  CG1 ILE   126      53.564  37.078  23.095  1.00  0.00     0.002 C \nATOM    723  CG2 ILE   126      52.395  35.082  22.302  1.00  0.00     0.012 C \nATOM    724  CD1 ILE   126      54.772  37.552  23.802  1.00  0.00     0.005 C \nATOM    725  H   ILE   126      52.801  33.465  24.915  1.00  0.00     0.163 HD\nATOM    726  N   LEU   127      49.921  35.189  24.475  1.00  0.00    -0.346 N \nATOM    727  CA  LEU   127      48.520  35.512  24.242  1.00  0.00     0.177 C \nATOM    728  C   LEU   127      47.636  35.413  25.480  1.00  0.00     0.241 C \nATOM    729  O   LEU   127      46.453  35.712  25.390  1.00  0.00    -0.271 OA\nATOM    730  CB  LEU   127      47.952  34.592  23.156  1.00  0.00     0.038 C \nATOM    731  CG  LEU   127      48.616  34.673  21.772  1.00  0.00    -0.020 C \nATOM    732  CD1 LEU   127      48.038  33.668  20.808  1.00  0.00     0.009 C \nATOM    733  CD2 LEU   127      48.526  36.045  21.200  1.00  0.00     0.009 C \nATOM    734  H   LEU   127      50.271  34.207  24.578  1.00  0.00     0.163 HD\nATOM    735  N   ILE   128      48.170  35.035  26.636  1.00  0.00    -0.346 N \nATOM    736  CA  ILE   128      47.315  34.801  27.794  1.00  0.00     0.180 C \nATOM    737  C   ILE   128      46.564  36.036  28.244  1.00  0.00     0.241 C \nATOM    738  O   ILE   128      45.395  35.946  28.622  1.00  0.00    -0.271 OA\nATOM    739  CB  ILE   128      48.113  34.172  28.965  1.00  0.00     0.013 C \nATOM    740  CG1 ILE   128      48.359  32.704  28.654  1.00  0.00     0.002 C \nATOM    741  CG2 ILE   128      47.378  34.331  30.296  1.00  0.00     0.012 C \nATOM    742  CD1 ILE   128      49.231  31.997  29.681  1.00  0.00     0.005 C \nATOM    743  H   ILE   128      49.192  34.927  26.641  1.00  0.00     0.163 HD\nATOM    744  N   ASP   129      47.204  37.195  28.238  1.00  0.00    -0.345 N \nATOM    745  CA  ASP   129      46.471  38.393  28.669  1.00  0.00     0.186 C \nATOM    746  C   ASP   129      45.258  38.658  27.759  1.00  0.00     0.241 C \nATOM    747  O   ASP   129      44.168  38.989  28.229  1.00  0.00    -0.271 OA\nATOM    748  CB  ASP   129      47.372  39.622  28.706  1.00  0.00     0.147 C \nATOM    749  CG  ASP   129      48.340  39.610  29.856  1.00  0.00     0.175 C \nATOM    750  OD1 ASP   129      48.138  38.856  30.823  1.00  0.00    -0.648 OA\nATOM    751  OD2 ASP   129      49.323  40.366  29.856  1.00  0.00    -0.648 OA\nATOM    752  H   ASP   129      48.170  37.187  27.934  1.00  0.00     0.163 HD\nATOM    753  N   GLU   130      45.460  38.513  26.457  1.00  0.00    -0.346 N \nATOM    754  CA  GLU   130      44.391  38.671  25.493  1.00  0.00     0.177 C \nATOM    755  C   GLU   130      43.299  37.622  25.713  1.00  0.00     0.241 C \nATOM    756  O   GLU   130      42.112  37.961  25.784  1.00  0.00    -0.271 OA\nATOM    757  CB  GLU   130      44.946  38.571  24.087  1.00  0.00     0.045 C \nATOM    758  CG  GLU   130      43.852  38.614  23.055  1.00  0.00     0.116 C \nATOM    759  CD  GLU   130      44.363  38.888  21.677  1.00  0.00     0.172 C \nATOM    760  OE1 GLU   130      44.823  40.028  21.454  1.00  0.00    -0.648 OA\nATOM    761  OE2 GLU   130      44.281  37.973  20.824  1.00  0.00    -0.648 OA\nATOM    762  H   GLU   130      46.442  38.279  26.194  1.00  0.00     0.163 HD\nATOM    763  N   PHE   131      43.693  36.354  25.829  1.00  0.00    -0.346 N \nATOM    764  CA  PHE   131      42.727  35.280  26.009  1.00  0.00     0.180 C \nATOM    765  C   PHE   131      41.898  35.505  27.276  1.00  0.00     0.241 C \nATOM    766  O   PHE   131      40.712  35.194  27.325  1.00  0.00    -0.271 OA\nATOM    767  CB  PHE   131      43.431  33.935  26.173  1.00  0.00     0.073 C \nATOM    768  CG  PHE   131      44.124  33.394  24.936  1.00  0.00    -0.056 A \nATOM    769  CD1 PHE   131      43.766  33.773  23.652  1.00  0.00     0.007 A \nATOM    770  CD2 PHE   131      45.111  32.440  25.076  1.00  0.00     0.007 A \nATOM    771  CE1 PHE   131      44.392  33.211  22.560  1.00  0.00     0.001 A \nATOM    772  CE2 PHE   131      45.734  31.866  23.994  1.00  0.00     0.001 A \nATOM    773  CZ  PHE   131      45.371  32.243  22.729  1.00  0.00     0.000 A \nATOM    774  H   PHE   131      44.716  36.208  25.781  1.00  0.00     0.163 HD\nATOM    775  N   THR   132      42.555  35.965  28.331  1.00  0.00    -0.344 N \nATOM    776  CA  THR   132      41.902  36.153  29.618  1.00  0.00     0.205 C \nATOM    777  C   THR   132      40.857  37.266  29.519  1.00  0.00     0.243 C \nATOM    778  O   THR   132      39.728  37.098  29.968  1.00  0.00    -0.271 OA\nATOM    779  CB  THR   132      42.961  36.466  30.671  1.00  0.00     0.146 C \nATOM    780  OG1 THR   132      43.837  35.319  30.799  1.00  0.00    -0.393 OA\nATOM    781  CG2 THR   132      42.317  36.703  32.045  1.00  0.00     0.042 C \nATOM    782  H   THR   132      43.559  36.176  28.162  1.00  0.00     0.163 HD\nATOM    783  HG1 THR   132      44.539  35.343  30.083  1.00  0.00     0.210 HD\nATOM    784  N   ALA   133      41.215  38.379  28.891  1.00  0.00    -0.346 N \nATOM    785  CA  ALA   133      40.238  39.447  28.691  1.00  0.00     0.172 C \nATOM    786  C   ALA   133      39.079  38.962  27.828  1.00  0.00     0.240 C \nATOM    787  O   ALA   133      37.913  39.251  28.110  1.00  0.00    -0.271 OA\nATOM    788  CB  ALA   133      40.884  40.648  28.056  1.00  0.00     0.042 C \nATOM    789  H   ALA   133      42.189  38.422  28.574  1.00  0.00     0.163 HD\nATOM    790  N   GLN   134      39.407  38.205  26.784  1.00  0.00    -0.346 N \nATOM    791  CA  GLN   134      38.394  37.702  25.859  1.00  0.00     0.177 C \nATOM    792  C   GLN   134      37.407  36.738  26.509  1.00  0.00     0.241 C \nATOM    793  O   GLN   134      36.205  36.841  26.290  1.00  0.00    -0.271 OA\nATOM    794  CB  GLN   134      39.060  37.054  24.649  1.00  0.00     0.044 C \nATOM    795  CG  GLN   134      39.747  38.048  23.740  1.00  0.00     0.105 C \nATOM    796  CD  GLN   134      40.540  37.383  22.629  1.00  0.00     0.215 C \nATOM    797  H   GLN   134      40.420  38.008  26.687  1.00  0.00     0.163 HD\nATOM    798 2HE2 GLN   134      40.249  38.997  21.444  1.00  0.00     0.159 HD\nATOM    799  OE1 GLN   134      41.037  36.266  22.794  1.00  0.00    -0.274 OA\nATOM    800  NE2 GLN   134      40.687  38.079  21.495  1.00  0.00    -0.370 N \nATOM    801 1HE2 GLN   134      41.216  37.700  20.717  1.00  0.00     0.159 HD\nATOM    802  N   ILE   135      37.909  35.763  27.259  1.00  0.00    -0.346 N \nATOM    803  CA  ILE   135      37.024  34.747  27.817  1.00  0.00     0.180 C \nATOM    804  C   ILE   135      36.096  35.353  28.876  1.00  0.00     0.241 C \nATOM    805  O   ILE   135      34.943  34.951  28.996  1.00  0.00    -0.271 OA\nATOM    806  CB  ILE   135      37.833  33.529  28.330  1.00  0.00     0.013 C \nATOM    807  CG1 ILE   135      36.926  32.298  28.454  1.00  0.00     0.002 C \nATOM    808  CG2 ILE   135      38.523  33.819  29.643  1.00  0.00     0.012 C \nATOM    809  CD1 ILE   135      36.492  31.699  27.135  1.00  0.00     0.005 C \nATOM    810  H   ILE   135      38.924  35.788  27.403  1.00  0.00     0.163 HD\nATOM    811  N   ARG   136      36.579  36.351  29.603  1.00  0.00    -0.346 N \nATOM    812  CA  ARG   136      35.733  37.068  30.557  1.00  0.00     0.176 C \nATOM    813  C   ARG   136      34.602  37.809  29.868  1.00  0.00     0.241 C \nATOM    814  O   ARG   136      33.452  37.779  30.320  1.00  0.00    -0.271 OA\nATOM    815  CB  ARG   136      36.586  38.024  31.387  1.00  0.00     0.036 C \nATOM    816  CG  ARG   136      37.486  37.287  32.364  1.00  0.00     0.023 C \nATOM    817  CD  ARG   136      38.308  38.210  33.240  1.00  0.00     0.138 C \nATOM    818  NE  ARG   136      39.379  37.515  33.958  1.00  0.00    -0.227 N \nATOM    819  CZ  ARG   136      39.225  36.603  34.933  1.00  0.00     0.665 C \nATOM    820  NH1 ARG   136      38.026  36.220  35.366  1.00  0.00    -0.235 N \nATOM    821  NH2 ARG   136      40.308  36.055  35.490  1.00  0.00    -0.235 N \nATOM    822  HE  ARG   136      40.338  37.742  33.696  1.00  0.00     0.177 HD\nATOM    823 2HH2 ARG   136      40.202  35.393  36.225  1.00  0.00     0.174 HD\nATOM    824 1HH2 ARG   136      41.217  36.311  35.166  1.00  0.00     0.174 HD\nATOM    825  H   ARG   136      37.576  36.573  29.443  1.00  0.00     0.163 HD\nATOM    826 2HH1 ARG   136      37.950  35.559  36.100  1.00  0.00     0.174 HD\nATOM    827 1HH1 ARG   136      37.202  36.604  34.944  1.00  0.00     0.174 HD\nATOM    828  N   ILE   137      34.923  38.447  28.753  1.00  0.00    -0.346 N \nATOM    829  CA  ILE   137      33.910  39.150  27.977  1.00  0.00     0.180 C \nATOM    830  C   ILE   137      32.882  38.165  27.436  1.00  0.00     0.241 C \nATOM    831  O   ILE   137      31.678  38.419  27.509  1.00  0.00    -0.271 OA\nATOM    832  CB  ILE   137      34.570  39.969  26.861  1.00  0.00     0.013 C \nATOM    833  CG1 ILE   137      35.288  41.175  27.473  1.00  0.00     0.002 C \nATOM    834  CG2 ILE   137      33.541  40.430  25.819  1.00  0.00     0.012 C \nATOM    835  CD1 ILE   137      36.288  41.802  26.581  1.00  0.00     0.005 C \nATOM    836  H   ILE   137      35.922  38.404  28.490  1.00  0.00     0.163 HD\nATOM    837  N   LEU   138      33.341  37.031  26.914  1.00  0.00    -0.346 N \nATOM    838  CA  LEU   138      32.428  36.052  26.362  1.00  0.00     0.177 C \nATOM    839  C   LEU   138      31.484  35.537  27.444  1.00  0.00     0.241 C \nATOM    840  O   LEU   138      30.280  35.402  27.221  1.00  0.00    -0.271 OA\nATOM    841  CB  LEU   138      33.222  34.901  25.751  1.00  0.00     0.038 C \nATOM    842  CG  LEU   138      32.372  33.769  25.143  1.00  0.00    -0.020 C \nATOM    843  CD1 LEU   138      31.374  34.259  24.092  1.00  0.00     0.009 C \nATOM    844  CD2 LEU   138      33.283  32.694  24.548  1.00  0.00     0.009 C \nATOM    845  H   LEU   138      34.367  36.920  26.939  1.00  0.00     0.163 HD\nATOM    846  N   ASN   139      32.022  35.227  28.615  1.00  0.00    -0.346 N \nATOM    847  CA  ASN   139      31.179  34.725  29.696  1.00  0.00     0.185 C \nATOM    848  C   ASN   139      30.121  35.733  30.110  1.00  0.00     0.241 C \nATOM    849  O   ASN   139      28.970  35.381  30.359  1.00  0.00    -0.271 OA\nATOM    850  CB  ASN   139      32.006  34.325  30.910  1.00  0.00     0.137 C \nATOM    851  CG  ASN   139      31.258  33.343  31.811  1.00  0.00     0.217 C \nATOM    852  OD1 ASN   139      31.098  33.581  33.008  1.00  0.00    -0.274 OA\nATOM    853  ND2 ASN   139      30.826  32.233  31.244  1.00  0.00    -0.370 N \nATOM    854 2HD2 ASN   139      30.325  31.554  31.780  1.00  0.00     0.159 HD\nATOM    855 1HD2 ASN   139      30.999  32.064  30.270  1.00  0.00     0.159 HD\nATOM    856  H   ASN   139      33.037  35.364  28.692  1.00  0.00     0.163 HD\nATOM    857  N   ASP   140      30.510  36.993  30.192  1.00  0.00    -0.345 N \nATOM    858  CA  ASP   140      29.551  38.021  30.568  1.00  0.00     0.186 C \nATOM    859  C   ASP   140      28.439  38.145  29.539  1.00  0.00     0.241 C \nATOM    860  O   ASP   140      27.270  38.315  29.896  1.00  0.00    -0.271 OA\nATOM    861  CB  ASP   140      30.250  39.360  30.716  1.00  0.00     0.147 C \nATOM    862  CG  ASP   140      30.991  39.498  32.014  1.00  0.00     0.175 C \nATOM    863  OD1 ASP   140      30.782  38.718  32.969  1.00  0.00    -0.648 OA\nATOM    864  OD2 ASP   140      31.827  40.389  32.153  1.00  0.00    -0.648 OA\nATOM    865  H   ASP   140      31.498  37.174  29.978  1.00  0.00     0.163 HD\nATOM    866  N   LEU   141      28.796  38.069  28.259  1.00  0.00    -0.346 N \nATOM    867  CA  LEU   141      27.812  38.139  27.185  1.00  0.00     0.177 C \nATOM    868  C   LEU   141      26.823  37.001  27.301  1.00  0.00     0.241 C \nATOM    869  O   LEU   141      25.617  37.197  27.147  1.00  0.00    -0.271 OA\nATOM    870  CB  LEU   141      28.499  38.093  25.821  1.00  0.00     0.038 C \nATOM    871  CG  LEU   141      29.283  39.331  25.386  1.00  0.00    -0.020 C \nATOM    872  CD1 LEU   141      30.194  39.025  24.181  1.00  0.00     0.009 C \nATOM    873  CD2 LEU   141      28.340  40.495  25.079  1.00  0.00     0.009 C \nATOM    874  H   LEU   141      29.815  37.958  28.097  1.00  0.00     0.163 HD\nATOM    875  N   LEU   142      27.332  35.794  27.521  1.00  0.00    -0.346 N \nATOM    876  CA  LEU   142      26.488  34.618  27.594  1.00  0.00     0.177 C \nATOM    877  C   LEU   142      25.557  34.697  28.794  1.00  0.00     0.241 C \nATOM    878  O   LEU   142      24.374  34.409  28.687  1.00  0.00    -0.271 OA\nATOM    879  CB  LEU   142      27.364  33.370  27.690  1.00  0.00     0.038 C \nATOM    880  CG  LEU   142      28.029  32.967  26.382  1.00  0.00    -0.020 C \nATOM    881  CD1 LEU   142      29.111  31.926  26.614  1.00  0.00     0.009 C \nATOM    882  CD2 LEU   142      27.012  32.481  25.363  1.00  0.00     0.009 C \nATOM    883  H   LEU   142      28.365  35.771  27.633  1.00  0.00     0.163 HD\nATOM    884  N   LYS   143      26.086  35.071  29.945  1.00  0.00    -0.346 N \nATOM    885  CA  LYS   143      25.247  35.179  31.129  1.00  0.00     0.176 C \nATOM    886  C   LYS   143      24.135  36.190  30.945  1.00  0.00     0.241 C \nATOM    887  O   LYS   143      22.986  35.947  31.315  1.00  0.00    -0.271 OA\nATOM    888  CB  LYS   143      26.070  35.573  32.358  1.00  0.00     0.035 C \nATOM    889  CG  LYS   143      26.927  34.449  32.895  1.00  0.00     0.004 C \nATOM    890  CD  LYS   143      27.774  34.808  34.134  1.00  0.00     0.027 C \nATOM    891  CE  LYS   143      27.219  35.909  35.031  1.00  0.00     0.229 C \nATOM    892  NZ  LYS   143      28.290  36.404  35.958  1.00  0.00    -0.079 N \nATOM    893  HZ1 LYS   143      28.552  37.328  35.688  1.00  0.00     0.274 HD\nATOM    894  HZ3 LYS   143      27.936  36.410  36.891  1.00  0.00     0.274 HD\nATOM    895  HZ2 LYS   143      29.079  35.796  35.898  1.00  0.00     0.274 HD\nATOM    896  H   LYS   143      27.095  35.270  29.932  1.00  0.00     0.163 HD\nATOM    897  N   GLN   144      24.477  37.338  30.380  1.00  0.00    -0.346 N \nATOM    898  CA  GLN   144      23.484  38.386  30.173  1.00  0.00     0.177 C \nATOM    899  C   GLN   144      22.413  37.949  29.185  1.00  0.00     0.241 C \nATOM    900  O   GLN   144      21.219  38.112  29.441  1.00  0.00    -0.271 OA\nATOM    901  CB  GLN   144      24.165  39.648  29.681  1.00  0.00     0.044 C \nATOM    902  CG  GLN   144      23.252  40.863  29.651  1.00  0.00     0.105 C \nATOM    903  CD  GLN   144      23.946  42.124  29.165  1.00  0.00     0.215 C \nATOM    904  H   GLN   144      25.468  37.423  30.110  1.00  0.00     0.163 HD\nATOM    905 2HE2 GLN   144      22.423  43.243  29.885  1.00  0.00     0.159 HD\nATOM    906  OE1 GLN   144      25.029  42.061  28.571  1.00  0.00    -0.274 OA\nATOM    907  NE2 GLN   144      23.322  43.274  29.408  1.00  0.00    -0.370 N \nATOM    908 1HE2 GLN   144      23.733  44.162  29.124  1.00  0.00     0.159 HD\nATOM    909  N   LYS   145      22.831  37.399  28.051  1.00  0.00    -0.346 N \nATOM    910  CA  LYS   145      21.873  37.049  27.008  1.00  0.00     0.176 C \nATOM    911  C   LYS   145      20.959  35.892  27.422  1.00  0.00     0.241 C \nATOM    912  O   LYS   145      19.757  35.942  27.177  1.00  0.00    -0.271 OA\nATOM    913  CB  LYS   145      22.595  36.735  25.699  1.00  0.00     0.035 C \nATOM    914  CG  LYS   145      23.169  37.962  25.020  1.00  0.00     0.004 C \nATOM    915  CD  LYS   145      22.061  38.815  24.385  1.00  0.00     0.027 C \nATOM    916  CE  LYS   145      22.383  39.270  22.975  1.00  0.00     0.229 C \nATOM    917  NZ  LYS   145      21.226  39.984  22.373  1.00  0.00    -0.079 N \nATOM    918  HZ1 LYS   145      20.631  39.325  21.914  1.00  0.00     0.274 HD\nATOM    919  HZ3 LYS   145      20.714  40.453  23.092  1.00  0.00     0.274 HD\nATOM    920  HZ2 LYS   145      21.558  40.653  21.708  1.00  0.00     0.274 HD\nATOM    921  H   LYS   145      23.846  37.248  27.977  1.00  0.00     0.163 HD\nATOM    922  N   TYR   146      21.526  34.871  28.057  1.00  0.00    -0.346 N \nATOM    923  CA  TYR   146      20.797  33.655  28.402  1.00  0.00     0.180 C \nATOM    924  C   TYR   146      20.220  33.676  29.806  1.00  0.00     0.241 C \nATOM    925  O   TYR   146      19.592  32.711  30.224  1.00  0.00    -0.271 OA\nATOM    926  CB  TYR   146      21.712  32.449  28.204  1.00  0.00     0.073 C \nATOM    927  CG  TYR   146      21.706  32.017  26.793  1.00  0.00    -0.056 A \nATOM    928  CD1 TYR   146      20.689  31.196  26.327  1.00  0.00     0.010 A \nATOM    929  CD2 TYR   146      22.652  32.468  25.904  1.00  0.00     0.010 A \nATOM    930  CE1 TYR   146      20.622  30.791  25.045  1.00  0.00     0.037 A \nATOM    931  CE2 TYR   146      22.596  32.067  24.577  1.00  0.00     0.037 A \nATOM    932  CZ  TYR   146      21.550  31.230  24.158  1.00  0.00     0.065 A \nATOM    933  OH  TYR   146      21.427  30.773  22.869  1.00  0.00    -0.361 OA\nATOM    934  H   TYR   146      22.536  35.014  28.287  1.00  0.00     0.163 HD\nATOM    935  HH  TYR   146      21.406  31.552  22.244  1.00  0.00     0.217 HD\nATOM    936  N   GLY   147      20.382  34.783  30.533  1.00  0.00    -0.351 N \nATOM    937  CA  GLY   147      19.760  34.911  31.843  1.00  0.00     0.225 C \nATOM    938  C   GLY   147      20.317  33.930  32.860  1.00  0.00     0.236 C \nATOM    939  O   GLY   147      19.573  33.338  33.645  1.00  0.00    -0.272 OA\nATOM    940  H   GLY   147      20.967  35.512  30.096  1.00  0.00     0.163 HD\nATOM    941  N   LEU   148      21.634  33.755  32.833  1.00  0.00    -0.346 N \nATOM    942  CA  LEU   148      22.315  32.805  33.699  1.00  0.00     0.177 C \nATOM    943  C   LEU   148      23.043  33.542  34.822  1.00  0.00     0.241 C \nATOM    944  O   LEU   148      23.757  34.504  34.578  1.00  0.00    -0.271 OA\nATOM    945  CB  LEU   148      23.308  32.007  32.874  1.00  0.00     0.038 C \nATOM    946  CG  LEU   148      22.738  31.345  31.623  1.00  0.00    -0.020 C \nATOM    947  CD1 LEU   148      23.872  30.706  30.851  1.00  0.00     0.009 C \nATOM    948  CD2 LEU   148      21.679  30.327  31.985  1.00  0.00     0.009 C \nATOM    949  H   LEU   148      22.134  34.356  32.139  1.00  0.00     0.163 HD\nATOM    950  N   SER   149      22.851  33.110  36.065  1.00  0.00    -0.344 N \nATOM    951  CA  SER   149      23.582  33.722  37.180  1.00  0.00     0.200 C \nATOM    952  C   SER   149      25.016  33.220  37.239  1.00  0.00     0.243 C \nATOM    953  O   SER   149      25.906  33.933  37.695  1.00  0.00    -0.271 OA\nATOM    954  CB  SER   149      22.890  33.453  38.519  1.00  0.00     0.199 C \nATOM    955  OG  SER   149      22.665  32.072  38.720  1.00  0.00    -0.398 OA\nATOM    956  H   SER   149      22.176  32.344  36.173  1.00  0.00     0.163 HD\nATOM    957  HG  SER   149      23.150  31.548  38.020  1.00  0.00     0.209 HD\nATOM    958  N   ARG   150      25.221  31.999  36.748  1.00  0.00    -0.346 N \nATOM    959  CA  ARG   150      26.490  31.295  36.843  1.00  0.00     0.176 C \nATOM    960  C   ARG   150      26.639  30.363  35.652  1.00  0.00     0.241 C \nATOM    961  O   ARG   150      25.674  29.747  35.218  1.00  0.00    -0.271 OA\nATOM    962  CB  ARG   150      26.466  30.468  38.126  1.00  0.00     0.036 C \nATOM    963  CG  ARG   150      27.762  29.931  38.658  1.00  0.00     0.023 C \nATOM    964  CD  ARG   150      27.513  28.940  39.794  1.00  0.00     0.138 C \nATOM    965  NE  ARG   150      26.772  27.784  39.287  1.00  0.00    -0.227 N \nATOM    966  CZ  ARG   150      27.311  26.636  38.869  1.00  0.00     0.665 C \nATOM    967  NH1 ARG   150      28.625  26.420  38.917  1.00  0.00    -0.235 N \nATOM    968  NH2 ARG   150      26.515  25.677  38.414  1.00  0.00    -0.235 N \nATOM    969  HE  ARG   150      25.760  27.860  39.249  1.00  0.00     0.177 HD\nATOM    970 2HH2 ARG   150      26.908  24.819  38.080  1.00  0.00     0.174 HD\nATOM    971 1HH2 ARG   150      25.524  25.808  38.404  1.00  0.00     0.174 HD\nATOM    972  H   ARG   150      24.374  31.584  36.280  1.00  0.00     0.163 HD\nATOM    973 2HH1 ARG   150      29.000  25.561  38.581  1.00  0.00     0.174 HD\nATOM    974 1HH1 ARG   150      29.230  27.122  39.292  1.00  0.00     0.174 HD\nATOM    975  N   VAL   151      27.867  30.218  35.170  1.00  0.00    -0.346 N \nATOM    976  CA  VAL   151      28.190  29.245  34.131  1.00  0.00     0.180 C \nATOM    977  C   VAL   151      29.282  28.382  34.721  1.00  0.00     0.241 C \nATOM    978  O   VAL   151      30.386  28.861  34.915  1.00  0.00    -0.271 OA\nATOM    979  CB  VAL   151      28.658  29.931  32.811  1.00  0.00     0.009 C \nATOM    980  CG1 VAL   151      29.171  28.898  31.808  1.00  0.00     0.012 C \nATOM    981  CG2 VAL   151      27.533  30.745  32.208  1.00  0.00     0.012 C \nATOM    982  H   VAL   151      28.577  30.854  35.594  1.00  0.00     0.163 HD\nATOM    983  N   GLY   152      28.970  27.123  35.014  1.00  0.00    -0.351 N \nATOM    984  CA  GLY   152      29.930  26.217  35.624  1.00  0.00     0.225 C \nATOM    985  C   GLY   152      31.217  26.079  34.810  1.00  0.00     0.236 C \nATOM    986  O   GLY   152      32.314  26.148  35.350  1.00  0.00    -0.272 OA\nATOM    987  H   GLY   152      27.996  26.850  34.772  1.00  0.00     0.163 HD\nATOM    988  N   ARG   153      31.089  25.903  33.500  1.00  0.00    -0.346 N \nATOM    989  CA  ARG   153      32.245  25.756  32.624  1.00  0.00     0.176 C \nATOM    990  C   ARG   153      31.927  26.335  31.268  1.00  0.00     0.241 C \nATOM    991  O   ARG   153      30.934  25.977  30.666  1.00  0.00    -0.271 OA\nATOM    992  CB  ARG   153      32.551  24.291  32.430  1.00  0.00     0.036 C \nATOM    993  CG  ARG   153      33.448  23.672  33.433  1.00  0.00     0.023 C \nATOM    994  CD  ARG   153      34.202  22.494  32.854  1.00  0.00     0.138 C \nATOM    995  NE  ARG   153      33.289  21.370  32.815  1.00  0.00    -0.227 N \nATOM    996  CZ  ARG   153      33.487  20.223  32.189  1.00  0.00     0.665 C \nATOM    997  NH1 ARG   153      34.570  20.005  31.461  1.00  0.00    -0.235 N \nATOM    998  NH2 ARG   153      32.560  19.289  32.289  1.00  0.00    -0.235 N \nATOM    999  HE  ARG   153      32.404  21.471  33.320  1.00  0.00     0.177 HD\nATOM   1000 2HH2 ARG   153      32.679  18.408  31.803  1.00  0.00     0.174 HD\nATOM   1001 1HH2 ARG   153      31.741  19.439  32.839  1.00  0.00     0.174 HD\nATOM   1002  H   ARG   153      30.106  25.879  33.158  1.00  0.00     0.163 HD\nATOM   1003 2HH1 ARG   153      34.690  19.134  30.980  1.00  0.00     0.174 HD\nATOM   1004 1HH1 ARG   153      35.278  20.711  31.388  1.00  0.00     0.174 HD\nATOM   1005  N   LEU   154      32.793  27.225  30.811  1.00  0.00    -0.346 N \nATOM   1006  CA  LEU   154      32.731  27.797  29.465  1.00  0.00     0.177 C \nATOM   1007  C   LEU   154      33.976  27.334  28.740  1.00  0.00     0.241 C \nATOM   1008  O   LEU   154      35.084  27.477  29.252  1.00  0.00    -0.271 OA\nATOM   1009  CB  LEU   154      32.725  29.319  29.560  1.00  0.00     0.038 C \nATOM   1010  CG  LEU   154      32.873  30.090  28.246  1.00  0.00    -0.020 C \nATOM   1011  CD1 LEU   154      31.716  29.780  27.296  1.00  0.00     0.009 C \nATOM   1012  CD2 LEU   154      32.968  31.599  28.534  1.00  0.00     0.009 C \nATOM   1013  H   LEU   154      33.540  27.493  31.501  1.00  0.00     0.163 HD\nATOM   1014  N   VAL   155      33.809  26.791  27.538  1.00  0.00    -0.346 N \nATOM   1015  CA  VAL   155      34.926  26.255  26.773  1.00  0.00     0.180 C \nATOM   1016  C   VAL   155      34.917  26.873  25.374  1.00  0.00     0.241 C \nATOM   1017  O   VAL   155      33.995  26.650  24.604  1.00  0.00    -0.271 OA\nATOM   1018  CB  VAL   155      34.909  24.716  26.680  1.00  0.00     0.009 C \nATOM   1019  CG1 VAL   155      36.202  24.222  26.039  1.00  0.00     0.012 C \nATOM   1020  CG2 VAL   155      34.719  24.094  28.047  1.00  0.00     0.012 C \nATOM   1021  H   VAL   155      32.825  26.783  27.198  1.00  0.00     0.163 HD\nATOM   1022  N   LEU   156      35.971  27.620  25.072  1.00  0.00    -0.346 N \nATOM   1023  CA  LEU   156      36.210  28.228  23.773  1.00  0.00     0.177 C \nATOM   1024  C   LEU   156      37.316  27.429  23.090  1.00  0.00     0.241 C \nATOM   1025  O   LEU   156      38.484  27.506  23.490  1.00  0.00    -0.271 OA\nATOM   1026  CB  LEU   156      36.607  29.690  23.974  1.00  0.00     0.038 C \nATOM   1027  CG  LEU   156      37.126  30.467  22.762  1.00  0.00    -0.020 C \nATOM   1028  CD1 LEU   156      36.117  30.508  21.646  1.00  0.00     0.009 C \nATOM   1029  CD2 LEU   156      37.515  31.885  23.179  1.00  0.00     0.009 C \nATOM   1030  H   LEU   156      36.645  27.740  25.883  1.00  0.00     0.163 HD\nATOM   1031  N   ASN   157      36.939  26.585  22.137  1.00  0.00    -0.346 N \nATOM   1032  CA  ASN   157      37.900  25.754  21.439  1.00  0.00     0.185 C \nATOM   1033  C   ASN   157      38.314  26.397  20.134  1.00  0.00     0.241 C \nATOM   1034  O   ASN   157      37.515  27.024  19.426  1.00  0.00    -0.271 OA\nATOM   1035  CB  ASN   157      37.338  24.354  21.156  1.00  0.00     0.137 C \nATOM   1036  CG  ASN   157      37.386  23.438  22.362  1.00  0.00     0.217 C \nATOM   1037  H   ASN   157      35.919  26.575  21.943  1.00  0.00     0.163 HD\nATOM   1038  OD1 ASN   157      36.355  23.029  22.888  1.00  0.00    -0.274 OA\nATOM   1039  ND2 ASN   157      38.584  23.089  22.788  1.00  0.00    -0.370 N \nATOM   1040 2HD2 ASN   157      38.685  22.480  23.579  1.00  0.00     0.159 HD\nATOM   1041 1HD2 ASN   157      39.405  23.431  22.324  1.00  0.00     0.159 HD\nATOM   1042  N   GLY   158      39.575  26.223  19.792  1.00  0.00    -0.351 N \nATOM   1043  CA  GLY   158      40.106  26.724  18.551  1.00  0.00     0.225 C \nATOM   1044  C   GLY   158      41.468  26.157  18.254  1.00  0.00     0.236 C \nATOM   1045  O   GLY   158      41.892  25.186  18.866  1.00  0.00    -0.272 OA\nATOM   1046  H   GLY   158      40.146  25.696  20.493  1.00  0.00     0.163 HD\nATOM   1047  N   GLU   159      42.113  26.744  17.262  1.00  0.00    -0.346 N \nATOM   1048  CA  GLU   159      43.398  26.297  16.776  1.00  0.00     0.177 C \nATOM   1049  C   GLU   159      44.436  27.375  17.118  1.00  0.00     0.241 C \nATOM   1050  O   GLU   159      44.274  28.539  16.738  1.00  0.00    -0.271 OA\nATOM   1051  CB  GLU   159      43.357  26.097  15.255  1.00  0.00     0.045 C \nATOM   1052  CG  GLU   159      44.491  25.209  14.746  1.00  0.00     0.116 C \nATOM   1053  CD  GLU   159      44.255  23.724  14.943  1.00  0.00     0.172 C \nATOM   1054  OE1 GLU   159      43.231  23.336  15.565  1.00  0.00    -0.648 OA\nATOM   1055  OE2 GLU   159      45.100  22.944  14.442  1.00  0.00    -0.648 OA\nATOM   1056  H   GLU   159      41.605  27.572  16.854  1.00  0.00     0.163 HD\nATOM   1057  N   LEU   160      45.512  26.994  17.809  1.00  0.00    -0.346 N \nATOM   1058  CA  LEU   160      46.659  27.846  18.004  1.00  0.00     0.177 C \nATOM   1059  C   LEU   160      47.510  27.688  16.759  1.00  0.00     0.241 C \nATOM   1060  O   LEU   160      47.818  26.562  16.386  1.00  0.00    -0.271 OA\nATOM   1061  CB  LEU   160      47.418  27.418  19.261  1.00  0.00     0.038 C \nATOM   1062  CG  LEU   160      48.573  28.325  19.641  1.00  0.00    -0.020 C \nATOM   1063  CD1 LEU   160      48.077  29.633  20.255  1.00  0.00     0.009 C \nATOM   1064  CD2 LEU   160      49.487  27.609  20.622  1.00  0.00     0.009 C \nATOM   1065  H   LEU   160      45.443  26.021  18.194  1.00  0.00     0.163 HD\nATOM   1066  N   PHE   161      47.880  28.783  16.109  1.00  0.00    -0.346 N \nATOM   1067  CA  PHE   161      48.520  28.686  14.803  1.00  0.00     0.180 C \nATOM   1068  C   PHE   161      49.470  29.848  14.572  1.00  0.00     0.241 C \nATOM   1069  O   PHE   161      49.467  30.843  15.289  1.00  0.00    -0.271 OA\nATOM   1070  CB  PHE   161      47.470  28.598  13.676  1.00  0.00     0.073 C \nATOM   1071  CG  PHE   161      46.759  29.892  13.374  1.00  0.00    -0.056 A \nATOM   1072  CD1 PHE   161      47.172  30.694  12.326  1.00  0.00     0.007 A \nATOM   1073  CD2 PHE   161      45.676  30.319  14.130  1.00  0.00     0.007 A \nATOM   1074  CE1 PHE   161      46.505  31.868  12.005  1.00  0.00     0.001 A \nATOM   1075  CE2 PHE   161      45.016  31.493  13.827  1.00  0.00     0.001 A \nATOM   1076  CZ  PHE   161      45.428  32.269  12.761  1.00  0.00     0.000 A \nATOM   1077  H   PHE   161      47.683  29.673  16.589  1.00  0.00     0.163 HD\nATOM   1078  N   GLY   162      50.253  29.706  13.517  1.00  0.00    -0.351 N \nATOM   1079  CA  GLY   162      51.142  30.763  13.090  1.00  0.00     0.225 C \nATOM   1080  C   GLY   162      52.583  30.559  13.483  1.00  0.00     0.236 C \nATOM   1081  O   GLY   162      53.076  29.439  13.562  1.00  0.00    -0.272 OA\nATOM   1082  H   GLY   162      50.174  28.788  13.034  1.00  0.00     0.163 HD\nATOM   1083  N   ALA   163      53.268  31.674  13.690  1.00  0.00    -0.347 N \nATOM   1084  CA  ALA   163      54.698  31.727  13.990  1.00  0.00     0.172 C \nATOM   1085  C   ALA   163      55.544  31.086  12.892  1.00  0.00     0.240 C \nATOM   1086  O   ALA   163      56.596  30.512  13.144  1.00  0.00    -0.271 OA\nATOM   1087  CB  ALA   163      54.994  31.162  15.378  1.00  0.00     0.042 C \nATOM   1088  H   ALA   163      52.679  32.551  13.619  1.00  0.00     0.163 HD\nATOM   1089  N   LYS   164      55.104  31.241  11.644  1.00  0.00    -0.346 N \nATOM   1090  CA  LYS   164      55.882  30.826  10.477  1.00  0.00     0.176 C \nATOM   1091  C   LYS   164      55.351  31.544   9.254  1.00  0.00     0.241 C \nATOM   1092  O   LYS   164      54.186  31.405   8.917  1.00  0.00    -0.271 OA\nATOM   1093  CB  LYS   164      55.801  29.314  10.266  1.00  0.00     0.035 C \nATOM   1094  CG  LYS   164      56.576  28.818   9.031  1.00  0.00     0.004 C \nATOM   1095  CD  LYS   164      56.468  27.308   8.790  1.00  0.00     0.027 C \nATOM   1096  CE  LYS   164      57.221  26.868   7.551  1.00  0.00     0.229 C \nATOM   1097  NZ  LYS   164      57.214  25.386   7.381  1.00  0.00    -0.079 N \nATOM   1098  HZ1 LYS   164      58.137  25.075   7.160  1.00  0.00     0.274 HD\nATOM   1099  HZ3 LYS   164      56.910  24.958   8.231  1.00  0.00     0.274 HD\nATOM   1100  HZ2 LYS   164      56.590  25.142   6.640  1.00  0.00     0.274 HD\nATOM   1101  H   LYS   164      54.161  31.682  11.571  1.00  0.00     0.163 HD\nATOM   1102  N   TYR   165      56.218  32.278   8.563  1.00  0.00    -0.346 N \nATOM   1103  CA  TYR   165      55.830  32.906   7.305  1.00  0.00     0.180 C \nATOM   1104  C   TYR   165      57.102  33.250   6.543  1.00  0.00     0.241 C \nATOM   1105  O   TYR   165      57.720  34.292   6.779  1.00  0.00    -0.271 OA\nATOM   1106  CB  TYR   165      54.962  34.144   7.528  1.00  0.00     0.073 C \nATOM   1107  CG  TYR   165      54.187  34.508   6.293  1.00  0.00    -0.056 A \nATOM   1108  CD1 TYR   165      52.976  33.902   6.023  1.00  0.00     0.010 A \nATOM   1109  CD2 TYR   165      54.674  35.425   5.367  1.00  0.00     0.010 A \nATOM   1110  CE1 TYR   165      52.254  34.211   4.892  1.00  0.00     0.037 A \nATOM   1111  CE2 TYR   165      53.964  35.734   4.239  1.00  0.00     0.037 A \nATOM   1112  CZ  TYR   165      52.745  35.134   4.002  1.00  0.00     0.065 A \nATOM   1113  OH  TYR   165      52.013  35.422   2.871  1.00  0.00    -0.361 OA\nATOM   1114  H   TYR   165      57.158  32.361   8.982  1.00  0.00     0.163 HD\nATOM   1115  HH  TYR   165      52.529  36.058   2.301  1.00  0.00     0.217 HD\nATOM   1116  N   LYS   166      57.500  32.377   5.633  1.00  0.00    -0.346 N \nATOM   1117  CA  LYS   166      58.833  32.445   5.045  1.00  0.00     0.176 C \nATOM   1118  C   LYS   166      58.873  33.338   3.812  1.00  0.00     0.241 C \nATOM   1119  O   LYS   166      59.074  32.889   2.688  1.00  0.00    -0.271 OA\nATOM   1120  CB  LYS   166      59.318  31.032   4.731  1.00  0.00     0.035 C \nATOM   1121  CG  LYS   166      59.532  30.172   5.967  1.00  0.00     0.004 C \nATOM   1122  CD  LYS   166      59.994  28.757   5.625  1.00  0.00     0.027 C \nATOM   1123  CE  LYS   166      61.454  28.711   5.216  1.00  0.00     0.229 C \nATOM   1124  NZ  LYS   166      61.883  27.319   4.891  1.00  0.00    -0.079 N \nATOM   1125  HZ1 LYS   166      61.368  26.992   4.100  1.00  0.00     0.274 HD\nATOM   1126  HZ3 LYS   166      62.860  27.316   4.681  1.00  0.00     0.274 HD\nATOM   1127  HZ2 LYS   166      61.706  26.728   5.676  1.00  0.00     0.274 HD\nATOM   1128  H   LYS   166      56.799  31.655   5.378  1.00  0.00     0.163 HD\nATOM   1129  N   HIS   167      58.687  34.626   4.037  1.00  0.00    -0.346 N \nATOM   1130  CA  HIS   167      58.818  35.647   2.997  1.00  0.00     0.182 C \nATOM   1131  C   HIS   167      59.863  36.638   3.462  1.00  0.00     0.243 C \nATOM   1132  O   HIS   167      59.816  37.080   4.607  1.00  0.00    -0.271 OA\nATOM   1133  CB  HIS   167      57.490  36.361   2.794  1.00  0.00     0.095 C \nATOM   1134  CG  HIS   167      57.449  37.225   1.580  1.00  0.00     0.053 A \nATOM   1135  H   HIS   167      58.436  34.861   5.028  1.00  0.00     0.163 HD\nATOM   1136  CD2 HIS   167      56.758  37.086   0.425  1.00  0.00     0.116 A \nATOM   1137  HE2 HIS   167      56.704  38.348  -1.273  1.00  0.00     0.166 HD\nATOM   1138  CE1 HIS   167      57.937  38.921   0.287  1.00  0.00     0.207 A \nATOM   1139  ND1 HIS   167      58.188  38.380   1.463  1.00  0.00    -0.247 NA\nATOM   1140  NE2 HIS   167      57.070  38.164  -0.360  1.00  0.00    -0.359 N \nATOM   1141  N   PRO   168      60.808  37.014   2.593  1.00  0.00    -0.337 N \nATOM   1142  CA  PRO   168      61.913  37.873   3.023  1.00  0.00     0.179 C \nATOM   1143  C   PRO   168      61.504  39.276   3.476  1.00  0.00     0.241 C \nATOM   1144  O   PRO   168      62.281  39.949   4.142  1.00  0.00    -0.271 OA\nATOM   1145  CB  PRO   168      62.822  37.933   1.786  1.00  0.00     0.037 C \nATOM   1146  CG  PRO   168      61.959  37.576   0.672  1.00  0.00     0.022 C \nATOM   1147  CD  PRO   168      60.958  36.589   1.193  1.00  0.00     0.127 C \nATOM   1148  N   LEU   169      60.311  39.734   3.120  1.00  0.00    -0.346 N \nATOM   1149  CA  LEU   169      59.836  41.040   3.570  1.00  0.00     0.177 C \nATOM   1150  C   LEU   169      59.017  40.970   4.856  1.00  0.00     0.241 C \nATOM   1151  O   LEU   169      58.486  41.987   5.300  1.00  0.00    -0.271 OA\nATOM   1152  CB  LEU   169      59.023  41.723   2.467  1.00  0.00     0.038 C \nATOM   1153  CG  LEU   169      59.792  41.953   1.178  1.00  0.00    -0.020 C \nATOM   1154  CD1 LEU   169      58.910  42.692   0.185  1.00  0.00     0.009 C \nATOM   1155  CD2 LEU   169      61.095  42.704   1.371  1.00  0.00     0.009 C \nATOM   1156  H   LEU   169      59.760  39.103   2.512  1.00  0.00     0.163 HD\nATOM   1157  N   VAL   170      58.907  39.776   5.443  1.00  0.00    -0.346 N \nATOM   1158  CA  VAL   170      58.132  39.565   6.643  1.00  0.00     0.180 C \nATOM   1159  C   VAL   170      59.086  39.053   7.713  1.00  0.00     0.243 C \nATOM   1160  O   VAL   170      59.393  37.872   7.771  1.00  0.00    -0.271 OA\nATOM   1161  CB  VAL   170      57.001  38.572   6.386  1.00  0.00     0.009 C \nATOM   1162  CG1 VAL   170      56.176  38.354   7.649  1.00  0.00     0.012 C \nATOM   1163  CG2 VAL   170      56.118  39.071   5.248  1.00  0.00     0.012 C \nATOM   1164  H   VAL   170      59.433  39.014   4.953  1.00  0.00     0.163 HD\nATOM   1165  N   PRO   171      59.616  39.942   8.543  1.00  0.00    -0.337 N \nATOM   1166  CA  PRO   171      60.525  39.500   9.599  1.00  0.00     0.179 C \nATOM   1167  C   PRO   171      59.898  38.469  10.522  1.00  0.00     0.241 C \nATOM   1168  O   PRO   171      58.702  38.505  10.796  1.00  0.00    -0.271 OA\nATOM   1169  CB  PRO   171      60.825  40.794  10.357  1.00  0.00     0.037 C \nATOM   1170  CG  PRO   171      60.617  41.873   9.351  1.00  0.00     0.022 C \nATOM   1171  CD  PRO   171      59.460  41.410   8.533  1.00  0.00     0.127 C \nATOM   1172  N   LYS   172      60.722  37.567  11.011  1.00  0.00    -0.346 N \nATOM   1173  CA  LYS   172      60.276  36.701  12.083  1.00  0.00     0.176 C \nATOM   1174  C   LYS   172      59.886  37.539  13.303  1.00  0.00     0.241 C \nATOM   1175  O   LYS   172      60.333  38.681  13.476  1.00  0.00    -0.271 OA\nATOM   1176  CB  LYS   172      61.338  35.656  12.436  1.00  0.00     0.035 C \nATOM   1177  CG  LYS   172      61.605  34.672  11.313  1.00  0.00     0.004 C \nATOM   1178  CD  LYS   172      62.384  33.454  11.751  1.00  0.00     0.027 C \nATOM   1179  CE  LYS   172      61.490  32.415  12.416  1.00  0.00     0.229 C \nATOM   1180  NZ  LYS   172      62.228  31.163  12.739  1.00  0.00    -0.079 N \nATOM   1181  HZ1 LYS   172      63.020  31.383  13.308  1.00  0.00     0.274 HD\nATOM   1182  HZ3 LYS   172      61.623  30.540  13.233  1.00  0.00     0.274 HD\nATOM   1183  HZ2 LYS   172      62.535  30.731  11.891  1.00  0.00     0.274 HD\nATOM   1184  H   LYS   172      61.657  37.533  10.589  1.00  0.00     0.163 HD\nATOM   1185  N   SER   173      59.056  36.964  14.160  1.00  0.00    -0.344 N \nATOM   1186  CA  SER   173      58.606  37.657  15.345  1.00  0.00     0.200 C \nATOM   1187  C   SER   173      59.796  38.051  16.215  1.00  0.00     0.243 C \nATOM   1188  O   SER   173      60.725  37.274  16.402  1.00  0.00    -0.271 OA\nATOM   1189  CB  SER   173      57.679  36.765  16.168  1.00  0.00     0.199 C \nATOM   1190  OG  SER   173      57.270  37.437  17.349  1.00  0.00    -0.398 OA\nATOM   1191  H   SER   173      58.768  35.999  13.909  1.00  0.00     0.163 HD\nATOM   1192  HG  SER   173      56.301  37.668  17.281  1.00  0.00     0.209 HD\nATOM   1193  N   GLU   174      59.717  39.252  16.769  1.00  0.00    -0.346 N \nATOM   1194  CA  GLU   174      60.665  39.738  17.763  1.00  0.00     0.177 C \nATOM   1195  C   GLU   174      60.154  39.528  19.185  1.00  0.00     0.241 C \nATOM   1196  O   GLU   174      60.818  39.925  20.144  1.00  0.00    -0.271 OA\nATOM   1197  CB  GLU   174      60.946  41.223  17.529  1.00  0.00     0.045 C \nATOM   1198  CG  GLU   174      61.622  41.529  16.198  1.00  0.00     0.116 C \nATOM   1199  CD  GLU   174      61.910  43.012  16.009  1.00  0.00     0.172 C \nATOM   1200  OE1 GLU   174      61.347  43.838  16.756  1.00  0.00    -0.648 OA\nATOM   1201  OE2 GLU   174      62.695  43.358  15.107  1.00  0.00    -0.648 OA\nATOM   1202  H   GLU   174      58.907  39.829  16.429  1.00  0.00     0.163 HD\nATOM   1203  N   LYS   175      58.978  38.921  19.336  1.00  0.00    -0.346 N \nATOM   1204  CA  LYS   175      58.359  38.796  20.649  1.00  0.00     0.176 C \nATOM   1205  C   LYS   175      58.905  37.613  21.426  1.00  0.00     0.241 C \nATOM   1206  O   LYS   175      59.348  36.621  20.854  1.00  0.00    -0.271 OA\nATOM   1207  CB  LYS   175      56.859  38.630  20.501  1.00  0.00     0.035 C \nATOM   1208  CG  LYS   175      56.179  39.782  19.789  1.00  0.00     0.004 C \nATOM   1209  CD  LYS   175      54.665  39.649  19.821  1.00  0.00     0.027 C \nATOM   1210  CE  LYS   175      54.007  40.621  18.865  1.00  0.00     0.229 C \nATOM   1211  NZ  LYS   175      52.540  40.684  19.055  1.00  0.00    -0.079 N \nATOM   1212  HZ1 LYS   175      52.201  39.789  19.348  1.00  0.00     0.274 HD\nATOM   1213  HZ3 LYS   175      52.321  41.367  19.753  1.00  0.00     0.274 HD\nATOM   1214  HZ2 LYS   175      52.101  40.939  18.193  1.00  0.00     0.274 HD\nATOM   1215  H   LYS   175      58.557  38.558  18.464  1.00  0.00     0.163 HD\nATOM   1216  N   TRP   176      58.847  37.730  22.746  1.00  0.00    -0.346 N \nATOM   1217  CA  TRP   176      59.259  36.679  23.672  1.00  0.00     0.181 C \nATOM   1218  C   TRP   176      58.151  36.516  24.683  1.00  0.00     0.241 C \nATOM   1219  O   TRP   176      57.694  37.516  25.237  1.00  0.00    -0.271 OA\nATOM   1220  CB  TRP   176      60.541  37.066  24.438  1.00  0.00     0.075 C \nATOM   1221  CG  TRP   176      61.766  37.066  23.591  1.00  0.00    -0.028 A \nATOM   1222  CD1 TRP   176      62.057  37.928  22.581  1.00  0.00     0.096 A \nATOM   1223  CD2 TRP   176      62.882  36.163  23.670  1.00  0.00    -0.002 A \nATOM   1224  NE1 TRP   176      63.266  37.607  22.013  1.00  0.00    -0.365 N \nATOM   1225  CE2 TRP   176      63.796  36.533  22.664  1.00  0.00     0.042 A \nATOM   1226  CE3 TRP   176      63.206  35.080  24.494  1.00  0.00     0.014 A \nATOM   1227  CZ2 TRP   176      65.006  35.866  22.458  1.00  0.00     0.030 A \nATOM   1228  CZ3 TRP   176      64.418  34.420  24.289  1.00  0.00     0.001 A \nATOM   1229  CH2 TRP   176      65.288  34.808  23.271  1.00  0.00     0.002 A \nATOM   1230  HE1 TRP   176      63.690  38.088  21.242  1.00  0.00     0.165 HD\nATOM   1231  H   TRP   176      58.474  38.658  23.076  1.00  0.00     0.163 HD\nATOM   1232  N   CYS   177      57.725  35.287  24.942  1.00  0.00    -0.345 N \nATOM   1233  CA  CYS   177      56.742  35.045  25.977  1.00  0.00     0.185 C \nATOM   1234  C   CYS   177      57.442  34.914  27.313  1.00  0.00     0.242 C \nATOM   1235  O   CYS   177      58.643  34.669  27.369  1.00  0.00    -0.271 OA\nATOM   1236  CB  CYS   177      55.923  33.792  25.691  1.00  0.00     0.105 C \nATOM   1237  SG  CYS   177      56.801  32.236  25.857  1.00  0.00    -0.180 SA\nATOM   1238  H   CYS   177      58.145  34.544  24.357  1.00  0.00     0.163 HD\nATOM   1239  HG  CYS   177      57.687  32.295  25.393  1.00  0.00     0.101 HD\nATOM   1240  N   THR   178      56.672  35.069  28.383  1.00  0.00    -0.344 N \nATOM   1241  CA  THR   178      57.155  34.888  29.741  1.00  0.00     0.205 C \nATOM   1242  C   THR   178      56.216  33.958  30.490  1.00  0.00     0.243 C \nATOM   1243  O   THR   178      55.011  34.197  30.549  1.00  0.00    -0.271 OA\nATOM   1244  CB  THR   178      57.227  36.230  30.487  1.00  0.00     0.146 C \nATOM   1245  OG1 THR   178      58.014  37.179  29.745  1.00  0.00    -0.393 OA\nATOM   1246  CG2 THR   178      57.939  36.057  31.839  1.00  0.00     0.042 C \nATOM   1247  H   THR   178      55.681  35.335  28.161  1.00  0.00     0.163 HD\nATOM   1248  HG1 THR   178      58.296  37.937  30.341  1.00  0.00     0.210 HD\nATOM   1249  N   LEU   179      56.772  32.922  31.084  1.00  0.00    -0.346 N \nATOM   1250  CA  LEU   179      55.991  31.987  31.881  1.00  0.00     0.177 C \nATOM   1251  C   LEU   179      55.845  32.517  33.308  1.00  0.00     0.243 C \nATOM   1252  O   LEU   179      56.611  33.385  33.730  1.00  0.00    -0.271 OA\nATOM   1253  CB  LEU   179      56.675  30.630  31.928  1.00  0.00     0.038 C \nATOM   1254  CG  LEU   179      56.414  29.728  30.721  1.00  0.00    -0.020 C \nATOM   1255  CD1 LEU   179      56.749  30.366  29.381  1.00  0.00     0.009 C \nATOM   1256  CD2 LEU   179      57.190  28.440  30.918  1.00  0.00     0.009 C \nATOM   1257  H   LEU   179      57.798  32.829  30.939  1.00  0.00     0.163 HD\nATOM   1258  N   PRO   180      54.898  31.992  34.086  1.00  0.00    -0.337 N \nATOM   1259  CA  PRO   180      54.786  32.402  35.494  1.00  0.00     0.179 C \nATOM   1260  C   PRO   180      56.083  32.269  36.295  1.00  0.00     0.241 C \nATOM   1261  O   PRO   180      56.319  33.083  37.190  1.00  0.00    -0.271 OA\nATOM   1262  CB  PRO   180      53.667  31.500  36.028  1.00  0.00     0.037 C \nATOM   1263  CG  PRO   180      52.839  31.206  34.832  1.00  0.00     0.022 C \nATOM   1264  CD  PRO   180      53.804  31.074  33.705  1.00  0.00     0.127 C \nATOM   1265  N   ASN   181      56.930  31.302  35.960  1.00  0.00    -0.346 N \nATOM   1266  CA  ASN   181      58.205  31.123  36.646  1.00  0.00     0.185 C \nATOM   1267  C   ASN   181      59.325  32.040  36.119  1.00  0.00     0.241 C \nATOM   1268  O   ASN   181      60.452  31.953  36.582  1.00  0.00    -0.271 OA\nATOM   1269  CB  ASN   181      58.634  29.655  36.612  1.00  0.00     0.137 C \nATOM   1270  CG  ASN   181      58.904  29.142  35.203  1.00  0.00     0.217 C \nATOM   1271  H   ASN   181      56.611  30.694  35.179  1.00  0.00     0.163 HD\nATOM   1272  OD1 ASN   181      59.071  29.921  34.272  1.00  0.00    -0.274 OA\nATOM   1273  ND2 ASN   181      58.969  27.823  35.058  1.00  0.00    -0.370 N \nATOM   1274 2HD2 ASN   181      59.149  27.426  34.160  1.00  0.00     0.159 HD\nATOM   1275 1HD2 ASN   181      58.837  27.226  35.851  1.00  0.00     0.159 HD\nATOM   1276  N   GLY   182      59.030  32.911  35.162  1.00  0.00    -0.351 N \nATOM   1277  CA  GLY   182      59.985  33.905  34.694  1.00  0.00     0.225 C \nATOM   1278  C   GLY   182      60.754  33.509  33.451  1.00  0.00     0.236 C \nATOM   1279  O   GLY   182      61.374  34.354  32.791  1.00  0.00    -0.272 OA\nATOM   1280  H   GLY   182      58.064  32.822  34.778  1.00  0.00     0.163 HD\nATOM   1281  N   LYS   183      60.711  32.230  33.112  1.00  0.00    -0.346 N \nATOM   1282  CA  LYS   183      61.376  31.783  31.902  1.00  0.00     0.176 C \nATOM   1283  C   LYS   183      60.736  32.417  30.680  1.00  0.00     0.241 C \nATOM   1284  O   LYS   183      59.523  32.581  30.626  1.00  0.00    -0.271 OA\nATOM   1285  CB  LYS   183      61.303  30.273  31.785  1.00  0.00     0.035 C \nATOM   1286  CG  LYS   183      62.144  29.538  32.810  1.00  0.00     0.004 C \nATOM   1287  CD  LYS   183      62.013  28.037  32.637  1.00  0.00     0.027 C \nATOM   1288  CE  LYS   183      62.956  27.266  33.540  1.00  0.00     0.229 C \nATOM   1289  NZ  LYS   183      64.337  27.208  32.978  1.00  0.00    -0.079 N \nATOM   1290  HZ1 LYS   183      64.372  26.514  32.260  1.00  0.00     0.274 HD\nATOM   1291  HZ3 LYS   183      64.575  28.100  32.596  1.00  0.00     0.274 HD\nATOM   1292  HZ2 LYS   183      64.979  26.972  33.706  1.00  0.00     0.274 HD\nATOM   1293  H   LYS   183      60.191  31.615  33.750  1.00  0.00     0.163 HD\nATOM   1294  N   LYS   184      61.571  32.749  29.709  1.00  0.00    -0.346 N \nATOM   1295  CA  LYS   184      61.136  33.377  28.473  1.00  0.00     0.176 C \nATOM   1296  C   LYS   184      61.575  32.560  27.281  1.00  0.00     0.241 C \nATOM   1297  O   LYS   184      62.631  31.926  27.296  1.00  0.00    -0.271 OA\nATOM   1298  CB  LYS   184      61.710  34.789  28.341  1.00  0.00     0.035 C \nATOM   1299  CG  LYS   184      61.308  35.698  29.483  1.00  0.00     0.004 C \nATOM   1300  CD  LYS   184      61.877  37.106  29.313  1.00  0.00     0.027 C \nATOM   1301  CE  LYS   184      61.080  37.915  28.293  1.00  0.00     0.229 C \nATOM   1302  NZ  LYS   184      61.607  39.295  28.096  1.00  0.00    -0.079 N \nATOM   1303  HZ1 LYS   184      62.574  39.247  27.850  1.00  0.00     0.274 HD\nATOM   1304  HZ3 LYS   184      61.096  39.743  27.363  1.00  0.00     0.274 HD\nATOM   1305  HZ2 LYS   184      61.502  39.813  28.944  1.00  0.00     0.274 HD\nATOM   1306  H   LYS   184      62.575  32.520  29.908  1.00  0.00     0.163 HD\nATOM   1307  N   PHE   185      60.745  32.571  26.244  1.00  0.00    -0.346 N \nATOM   1308  CA  PHE   185      61.039  31.869  25.000  1.00  0.00     0.181 C \nATOM   1309  C   PHE   185      60.693  32.752  23.829  1.00  0.00     0.243 C \nATOM   1310  O   PHE   185      59.695  33.465  23.851  1.00  0.00    -0.271 OA\nATOM   1311  CB  PHE   185      60.245  30.564  24.923  1.00  0.00     0.073 C \nATOM   1312  CG  PHE   185      60.611  29.603  25.989  1.00  0.00    -0.056 A \nATOM   1313  CD1 PHE   185      61.731  28.800  25.850  1.00  0.00     0.007 A \nATOM   1314  CD2 PHE   185      59.883  29.542  27.163  1.00  0.00     0.007 A \nATOM   1315  CE1 PHE   185      62.118  27.957  26.868  1.00  0.00     0.001 A \nATOM   1316  CE2 PHE   185      60.264  28.693  28.170  1.00  0.00     0.001 A \nATOM   1317  CZ  PHE   185      61.374  27.891  28.012  1.00  0.00     0.000 A \nATOM   1318  H   PHE   185      59.871  33.121  26.395  1.00  0.00     0.163 HD\nATOM   1319  N   PRO   186      61.501  32.693  22.782  1.00  0.00    -0.337 N \nATOM   1320  CA  PRO   186      61.248  33.531  21.613  1.00  0.00     0.179 C \nATOM   1321  C   PRO   186      60.178  32.945  20.712  1.00  0.00     0.241 C \nATOM   1322  O   PRO   186      60.206  31.761  20.386  1.00  0.00    -0.271 OA\nATOM   1323  CB  PRO   186      62.593  33.522  20.894  1.00  0.00     0.037 C \nATOM   1324  CG  PRO   186      63.220  32.206  21.259  1.00  0.00     0.022 C \nATOM   1325  CD  PRO   186      62.744  31.906  22.644  1.00  0.00     0.127 C \nATOM   1326  N   ILE   187      59.264  33.792  20.266  1.00  0.00    -0.346 N \nATOM   1327  CA  ILE   187      58.280  33.354  19.295  1.00  0.00     0.180 C \nATOM   1328  C   ILE   187      58.974  32.954  17.982  1.00  0.00     0.241 C \nATOM   1329  O   ILE   187      58.506  32.054  17.290  1.00  0.00    -0.271 OA\nATOM   1330  CB  ILE   187      57.169  34.405  19.097  1.00  0.00     0.013 C \nATOM   1331  CG1 ILE   187      56.434  34.667  20.428  1.00  0.00     0.002 C \nATOM   1332  CG2 ILE   187      56.193  33.962  18.009  1.00  0.00     0.012 C \nATOM   1333  CD1 ILE   187      55.840  33.452  21.069  1.00  0.00     0.005 C \nATOM   1334  H   ILE   187      59.313  34.745  20.653  1.00  0.00     0.163 HD\nATOM   1335  N   ALA   188      60.127  33.556  17.691  1.00  0.00    -0.346 N \nATOM   1336  CA  ALA   188      60.921  33.179  16.522  1.00  0.00     0.172 C \nATOM   1337  C   ALA   188      61.402  31.735  16.570  1.00  0.00     0.240 C \nATOM   1338  O   ALA   188      61.772  31.197  15.532  1.00  0.00    -0.271 OA\nATOM   1339  CB  ALA   188      62.115  34.128  16.355  1.00  0.00     0.042 C \nATOM   1340  H   ALA   188      60.407  34.303  18.355  1.00  0.00     0.163 HD\nATOM   1341  N   GLY   189      61.413  31.108  17.746  1.00  0.00    -0.351 N \nATOM   1342  CA  GLY   189      61.808  29.720  17.888  1.00  0.00     0.225 C \nATOM   1343  C   GLY   189      60.657  28.726  17.836  1.00  0.00     0.236 C \nATOM   1344  O   GLY   189      60.901  27.524  17.876  1.00  0.00    -0.272 OA\nATOM   1345  H   GLY   189      61.113  31.705  18.551  1.00  0.00     0.163 HD\nATOM   1346  N   VAL   190      59.416  29.208  17.734  1.00  0.00    -0.346 N \nATOM   1347  CA  VAL   190      58.238  28.347  17.741  1.00  0.00     0.180 C \nATOM   1348  C   VAL   190      57.976  27.745  16.364  1.00  0.00     0.241 C \nATOM   1349  O   VAL   190      57.885  28.473  15.381  1.00  0.00    -0.271 OA\nATOM   1350  CB  VAL   190      57.010  29.141  18.207  1.00  0.00     0.009 C \nATOM   1351  CG1 VAL   190      55.741  28.341  18.012  1.00  0.00     0.012 C \nATOM   1352  CG2 VAL   190      57.199  29.557  19.653  1.00  0.00     0.012 C \nATOM   1353  H   VAL   190      59.364  30.246  17.650  1.00  0.00     0.163 HD\nATOM   1354  N   GLN   191      57.850  26.421  16.301  1.00  0.00    -0.346 N \nATOM   1355  CA  GLN   191      57.515  25.714  15.066  1.00  0.00     0.177 C \nATOM   1356  C   GLN   191      56.373  24.749  15.330  1.00  0.00     0.241 C \nATOM   1357  O   GLN   191      56.584  23.603  15.702  1.00  0.00    -0.271 OA\nATOM   1358  CB  GLN   191      58.726  24.959  14.498  1.00  0.00     0.044 C \nATOM   1359  CG  GLN   191      58.470  24.328  13.147  1.00  0.00     0.105 C \nATOM   1360  CD  GLN   191      59.644  23.508  12.631  1.00  0.00     0.215 C \nATOM   1361  H   GLN   191      58.011  25.930  17.210  1.00  0.00     0.163 HD\nATOM   1362 2HE2 GLN   191      58.677  21.803  13.127  1.00  0.00     0.159 HD\nATOM   1363  OE1 GLN   191      60.633  24.062  12.157  1.00  0.00    -0.274 OA\nATOM   1364  NE2 GLN   191      59.527  22.185  12.715  1.00  0.00    -0.370 N \nATOM   1365 1HE2 GLN   191      60.266  21.572  12.377  1.00  0.00     0.159 HD\nATOM   1366  N   ILE   192      55.157  25.220  15.121  1.00  0.00    -0.346 N \nATOM   1367  CA  ILE   192      53.983  24.394  15.377  1.00  0.00     0.180 C \nATOM   1368  C   ILE   192      53.882  23.270  14.339  1.00  0.00     0.241 C \nATOM   1369  O   ILE   192      53.562  22.133  14.671  1.00  0.00    -0.271 OA\nATOM   1370  CB  ILE   192      52.688  25.238  15.411  1.00  0.00     0.013 C \nATOM   1371  CG1 ILE   192      52.782  26.330  16.483  1.00  0.00     0.002 C \nATOM   1372  CG2 ILE   192      51.467  24.354  15.695  1.00  0.00     0.012 C \nATOM   1373  CD1 ILE   192      51.634  27.319  16.449  1.00  0.00     0.005 C \nATOM   1374  H   ILE   192      55.109  26.192  14.772  1.00  0.00     0.163 HD\nATOM   1375  N   GLN   193      54.155  23.613  13.088  1.00  0.00    -0.346 N \nATOM   1376  CA  GLN   193      54.092  22.689  11.962  1.00  0.00     0.177 C \nATOM   1377  C   GLN   193      55.272  22.871  11.018  1.00  0.00     0.241 C \nATOM   1378  O   GLN   193      55.763  23.979  10.814  1.00  0.00    -0.271 OA\nATOM   1379  CB  GLN   193      52.793  22.896  11.171  1.00  0.00     0.044 C \nATOM   1380  CG  GLN   193      51.536  22.656  11.979  1.00  0.00     0.105 C \nATOM   1381  CD  GLN   193      51.367  21.212  12.385  1.00  0.00     0.215 C \nATOM   1382  OE1 GLN   193      50.512  20.887  13.205  1.00  0.00    -0.274 OA\nATOM   1383  NE2 GLN   193      52.193  20.342  11.836  1.00  0.00    -0.370 N \nATOM   1384  H   GLN   193      54.426  24.625  12.973  1.00  0.00     0.163 HD\nATOM   1385 2HE2 GLN   193      52.883  20.681  11.164  1.00  0.00     0.159 HD\nATOM   1386 1HE2 GLN   193      52.148  19.349  12.073  1.00  0.00     0.159 HD\nATOM   1387  N   ARG   194      55.689  21.765  10.397  1.00  0.00    -0.346 N \nATOM   1388  CA  ARG   194      56.844  21.758   9.498  1.00  0.00     0.176 C \nATOM   1389  C   ARG   194      56.466  21.932   8.031  1.00  0.00     0.241 C \nATOM   1390  O   ARG   194      57.320  22.208   7.199  1.00  0.00    -0.271 OA\nATOM   1391  CB  ARG   194      57.678  20.472   9.673  1.00  0.00     0.036 C \nATOM   1392  CG  ARG   194      57.071  19.206   9.083  1.00  0.00     0.023 C \nATOM   1393  CD  ARG   194      57.966  17.967   9.177  1.00  0.00     0.138 C \nATOM   1394  NE  ARG   194      57.202  16.731   9.392  1.00  0.00    -0.227 N \nATOM   1395  CZ  ARG   194      57.309  15.588   8.694  1.00  0.00     0.665 C \nATOM   1396  NH1 ARG   194      58.161  15.453   7.678  1.00  0.00    -0.235 N \nATOM   1397  NH2 ARG   194      56.545  14.550   9.026  1.00  0.00    -0.235 N \nATOM   1398  HE  ARG   194      56.517  16.737  10.150  1.00  0.00     0.177 HD\nATOM   1399 2HH2 ARG   194      56.605  13.704   8.502  1.00  0.00     0.174 HD\nATOM   1400 1HH2 ARG   194      55.915  14.619   9.799  1.00  0.00     0.174 HD\nATOM   1401  H   ARG   194      55.125  20.914  10.607  1.00  0.00     0.163 HD\nATOM   1402 2HH1 ARG   194      58.200  14.602   7.173  1.00  0.00     0.174 HD\nATOM   1403 1HH1 ARG   194      58.760  16.216   7.431  1.00  0.00     0.174 HD\nATOM   1404  N   GLU   195      55.187  21.791   7.705  1.00  0.00    -0.346 N \nATOM   1405  CA  GLU   195      54.752  21.763   6.308  1.00  0.00     0.177 C \nATOM   1406  C   GLU   195      54.992  23.114   5.627  1.00  0.00     0.243 C \nATOM   1407  O   GLU   195      54.856  24.154   6.269  1.00  0.00    -0.271 OA\nATOM   1408  CB  GLU   195      53.264  21.376   6.230  1.00  0.00     0.045 C \nATOM   1409  CG  GLU   195      52.976  19.888   6.413  1.00  0.00     0.116 C \nATOM   1410  CD  GLU   195      53.127  19.383   7.843  1.00  0.00     0.172 C \nATOM   1411  OE1 GLU   195      52.953  20.162   8.801  1.00  0.00    -0.648 OA\nATOM   1412  OE2 GLU   195      53.432  18.181   8.019  1.00  0.00    -0.648 OA\nATOM   1413  H   GLU   195      54.536  21.704   8.507  1.00  0.00     0.163 HD\nATOM   1414  N   PRO   196      55.345  23.106   4.341  1.00  0.00    -0.337 N \nATOM   1415  CA  PRO   196      55.574  24.356   3.609  1.00  0.00     0.179 C \nATOM   1416  C   PRO   196      54.308  25.168   3.340  1.00  0.00     0.241 C \nATOM   1417  O   PRO   196      54.395  26.354   3.020  1.00  0.00    -0.271 OA\nATOM   1418  CB  PRO   196      56.231  23.887   2.306  1.00  0.00     0.037 C \nATOM   1419  CG  PRO   196      55.740  22.533   2.143  1.00  0.00     0.022 C \nATOM   1420  CD  PRO   196      55.660  21.930   3.510  1.00  0.00     0.127 C \nATOM   1421  N   PHE   197      53.147  24.531   3.435  1.00  0.00    -0.346 N \nATOM   1422  CA  PHE   197      51.881  25.253   3.394  1.00  0.00     0.181 C \nATOM   1423  C   PHE   197      50.873  24.447   4.181  1.00  0.00     0.243 C \nATOM   1424  O   PHE   197      51.018  23.235   4.296  1.00  0.00    -0.271 OA\nATOM   1425  CB  PHE   197      51.379  25.511   1.964  1.00  0.00     0.073 C \nATOM   1426  CG  PHE   197      51.202  24.272   1.149  1.00  0.00    -0.056 A \nATOM   1427  CD1 PHE   197      52.269  23.754   0.420  1.00  0.00     0.007 A \nATOM   1428  CD2 PHE   197      49.981  23.609   1.102  1.00  0.00     0.007 A \nATOM   1429  CE1 PHE   197      52.124  22.598  -0.331  1.00  0.00     0.001 A \nATOM   1430  CE2 PHE   197      49.833  22.430   0.354  1.00  0.00     0.001 A \nATOM   1431  CZ  PHE   197      50.907  21.937  -0.355  1.00  0.00     0.000 A \nATOM   1432  H   PHE   197      53.218  23.502   3.538  1.00  0.00     0.163 HD\nATOM   1433  N   PRO   198      49.845  25.095   4.718  1.00  0.00    -0.337 N \nATOM   1434  CA  PRO   198      49.670  26.554   4.747  1.00  0.00     0.179 C \nATOM   1435  C   PRO   198      50.622  27.252   5.713  1.00  0.00     0.241 C \nATOM   1436  O   PRO   198      50.997  26.681   6.721  1.00  0.00    -0.271 OA\nATOM   1437  CB  PRO   198      48.226  26.708   5.243  1.00  0.00     0.037 C \nATOM   1438  CG  PRO   198      47.954  25.465   6.021  1.00  0.00     0.022 C \nATOM   1439  CD  PRO   198      48.739  24.384   5.377  1.00  0.00     0.127 C \nATOM   1440  N   GLN   199      50.972  28.488   5.391  1.00  0.00    -0.346 N \nATOM   1441  CA  GLN   199      51.658  29.403   6.300  1.00  0.00     0.177 C \nATOM   1442  C   GLN   199      50.791  30.633   6.469  1.00  0.00     0.241 C \nATOM   1443  O   GLN   199      50.200  31.127   5.517  1.00  0.00    -0.271 OA\nATOM   1444  CB  GLN   199      53.018  29.827   5.745  1.00  0.00     0.044 C \nATOM   1445  CG  GLN   199      54.002  28.675   5.642  1.00  0.00     0.105 C \nATOM   1446  CD  GLN   199      55.349  29.134   5.155  1.00  0.00     0.215 C \nATOM   1447  H   GLN   199      50.711  28.763   4.407  1.00  0.00     0.163 HD\nATOM   1448 2HE2 GLN   199      55.396  27.625   3.818  1.00  0.00     0.159 HD\nATOM   1449  OE1 GLN   199      55.901  30.088   5.675  1.00  0.00    -0.274 OA\nATOM   1450  NE2 GLN   199      55.899  28.437   4.178  1.00  0.00    -0.370 N \nATOM   1451 1HE2 GLN   199      56.806  28.698   3.788  1.00  0.00     0.159 HD\nATOM   1452  N   TYR   200      50.723  31.116   7.706  1.00  0.00    -0.346 N \nATOM   1453  CA  TYR   200      49.723  32.110   8.070  1.00  0.00     0.180 C \nATOM   1454  C   TYR   200      50.260  33.483   8.471  1.00  0.00     0.241 C \nATOM   1455  O   TYR   200      49.697  34.490   8.068  1.00  0.00    -0.271 OA\nATOM   1456  CB  TYR   200      48.867  31.566   9.201  1.00  0.00     0.073 C \nATOM   1457  CG  TYR   200      48.158  30.263   8.874  1.00  0.00    -0.056 A \nATOM   1458  CD1 TYR   200      47.099  30.234   7.982  1.00  0.00     0.010 A \nATOM   1459  CD2 TYR   200      48.538  29.067   9.467  1.00  0.00     0.010 A \nATOM   1460  CE1 TYR   200      46.418  29.067   7.719  1.00  0.00     0.037 A \nATOM   1461  CE2 TYR   200      47.871  27.884   9.190  1.00  0.00     0.037 A \nATOM   1462  CZ  TYR   200      46.804  27.898   8.329  1.00  0.00     0.065 A \nATOM   1463  OH  TYR   200      46.142  26.725   8.111  1.00  0.00    -0.361 OA\nATOM   1464  H   TYR   200      51.422  30.734   8.365  1.00  0.00     0.163 HD\nATOM   1465  HH  TYR   200      46.623  26.196   7.412  1.00  0.00     0.217 HD\nATOM   1466  N   SER   201      51.298  33.515   9.306  1.00  0.00    -0.344 N \nATOM   1467  CA  SER   201      51.721  34.757   9.955  1.00  0.00     0.200 C \nATOM   1468  C   SER   201      53.006  34.492  10.711  1.00  0.00     0.245 C \nATOM   1469  O   SER   201      53.189  33.385  11.219  1.00  0.00    -0.271 OA\nATOM   1470  CB  SER   201      50.667  35.177  10.985  1.00  0.00     0.199 C \nATOM   1471  OG  SER   201      51.086  36.309  11.740  1.00  0.00    -0.398 OA\nATOM   1472  H   SER   201      51.769  32.604   9.453  1.00  0.00     0.163 HD\nATOM   1473  HG  SER   201      51.153  37.101  11.137  1.00  0.00     0.209 HD\nATOM   1474  N   PRO   202      53.862  35.498  10.862  1.00  0.00    -0.337 N \nATOM   1475  CA  PRO   202      55.037  35.345  11.730  1.00  0.00     0.179 C \nATOM   1476  C   PRO   202      54.701  35.376  13.218  1.00  0.00     0.241 C \nATOM   1477  O   PRO   202      55.540  35.009  14.025  1.00  0.00    -0.271 OA\nATOM   1478  CB  PRO   202      55.898  36.566  11.370  1.00  0.00     0.037 C \nATOM   1479  CG  PRO   202      54.889  37.605  10.975  1.00  0.00     0.022 C \nATOM   1480  CD  PRO   202      53.841  36.826  10.220  1.00  0.00     0.127 C \nATOM   1481  N   GLU   203      53.502  35.841  13.570  1.00  0.00    -0.346 N \nATOM   1482  CA  GLU   203      53.075  35.906  14.956  1.00  0.00     0.177 C \nATOM   1483  C   GLU   203      52.170  34.727  15.276  1.00  0.00     0.241 C \nATOM   1484  O   GLU   203      51.694  34.022  14.379  1.00  0.00    -0.271 OA\nATOM   1485  CB  GLU   203      52.371  37.224  15.280  1.00  0.00     0.045 C \nATOM   1486  CG  GLU   203      53.195  38.455  14.941  1.00  0.00     0.116 C \nATOM   1487  CD  GLU   203      54.517  38.574  15.686  1.00  0.00     0.172 C \nATOM   1488  OE1 GLU   203      54.694  37.962  16.768  1.00  0.00    -0.648 OA\nATOM   1489  OE2 GLU   203      55.377  39.339  15.190  1.00  0.00    -0.648 OA\nATOM   1490  H   GLU   203      52.909  36.149  12.770  1.00  0.00     0.163 HD\nATOM   1491  N   LEU   204      51.972  34.504  16.566  1.00  0.00    -0.346 N \nATOM   1492  CA  LEU   204      51.072  33.479  17.067  1.00  0.00     0.177 C \nATOM   1493  C   LEU   204      49.646  34.014  17.117  1.00  0.00     0.241 C \nATOM   1494  O   LEU   204      49.429  35.159  17.501  1.00  0.00    -0.271 OA\nATOM   1495  CB  LEU   204      51.513  33.090  18.467  1.00  0.00     0.038 C \nATOM   1496  CG  LEU   204      51.116  31.737  19.020  1.00  0.00    -0.020 C \nATOM   1497  CD1 LEU   204      51.774  30.615  18.238  1.00  0.00     0.009 C \nATOM   1498  CD2 LEU   204      51.459  31.643  20.510  1.00  0.00     0.009 C \nATOM   1499  H   LEU   204      52.524  35.135  17.200  1.00  0.00     0.163 HD\nATOM   1500  N   HIS   205      48.695  33.158  16.793  1.00  0.00    -0.346 N \nATOM   1501  CA  HIS   205      47.291  33.522  16.787  1.00  0.00     0.182 C \nATOM   1502  C   HIS   205      46.425  32.369  17.241  1.00  0.00     0.241 C \nATOM   1503  O   HIS   205      46.871  31.225  17.327  1.00  0.00    -0.271 OA\nATOM   1504  CB  HIS   205      46.887  33.921  15.380  1.00  0.00     0.095 C \nATOM   1505  CG  HIS   205      47.627  35.099  14.856  1.00  0.00     0.053 A \nATOM   1506  ND1 HIS   205      47.394  36.390  15.277  1.00  0.00    -0.247 NA\nATOM   1507  CD2 HIS   205      48.550  35.193  13.876  1.00  0.00     0.116 A \nATOM   1508  CE1 HIS   205      48.207  37.215  14.641  1.00  0.00     0.207 A \nATOM   1509  NE2 HIS   205      48.920  36.514  13.786  1.00  0.00    -0.359 N \nATOM   1510  HE2 HIS   205      49.619  36.880  13.168  1.00  0.00     0.166 HD\nATOM   1511  H   HIS   205      49.038  32.202  16.543  1.00  0.00     0.163 HD\nATOM   1512  N   PHE   206      45.160  32.676  17.484  1.00  0.00    -0.346 N \nATOM   1513  CA  PHE   206      44.154  31.697  17.883  1.00  0.00     0.180 C \nATOM   1514  C   PHE   206      42.938  31.843  16.978  1.00  0.00     0.241 C \nATOM   1515  O   PHE   206      42.390  32.925  16.839  1.00  0.00    -0.271 OA\nATOM   1516  CB  PHE   206      43.759  31.933  19.333  1.00  0.00     0.073 C \nATOM   1517  CG  PHE   206      42.633  31.062  19.820  1.00  0.00    -0.056 A \nATOM   1518  CD1 PHE   206      42.840  29.719  20.106  1.00  0.00     0.007 A \nATOM   1519  CD2 PHE   206      41.372  31.589  20.036  1.00  0.00     0.007 A \nATOM   1520  CE1 PHE   206      41.810  28.920  20.558  1.00  0.00     0.001 A \nATOM   1521  CE2 PHE   206      40.348  30.783  20.509  1.00  0.00     0.001 A \nATOM   1522  CZ  PHE   206      40.565  29.466  20.778  1.00  0.00     0.000 A \nATOM   1523  H   PHE   206      44.937  33.698  17.364  1.00  0.00     0.163 HD\nATOM   1524  N   PHE   207      42.541  30.735  16.374  1.00  0.00    -0.346 N \nATOM   1525  CA  PHE   207      41.389  30.696  15.463  1.00  0.00     0.180 C \nATOM   1526  C   PHE   207      40.259  29.956  16.165  1.00  0.00     0.241 C \nATOM   1527  O   PHE   207      40.292  28.732  16.295  1.00  0.00    -0.271 OA\nATOM   1528  CB  PHE   207      41.810  29.967  14.194  1.00  0.00     0.073 C \nATOM   1529  CG  PHE   207      40.757  29.813  13.145  1.00  0.00    -0.056 A \nATOM   1530  CD1 PHE   207      40.491  30.805  12.229  1.00  0.00     0.007 A \nATOM   1531  CD2 PHE   207      40.125  28.596  12.994  1.00  0.00     0.007 A \nATOM   1532  CE1 PHE   207      39.559  30.566  11.189  1.00  0.00     0.001 A \nATOM   1533  CE2 PHE   207      39.228  28.365  11.985  1.00  0.00     0.001 A \nATOM   1534  CZ  PHE   207      38.957  29.326  11.076  1.00  0.00     0.000 A \nATOM   1535  H   PHE   207      43.111  29.888  16.596  1.00  0.00     0.163 HD\nATOM   1536  N   ALA   208      39.259  30.682  16.646  1.00  0.00    -0.346 N \nATOM   1537  CA  ALA   208      38.159  30.053  17.365  1.00  0.00     0.172 C \nATOM   1538  C   ALA   208      37.280  29.262  16.420  1.00  0.00     0.240 C \nATOM   1539  O   ALA   208      36.950  29.759  15.341  1.00  0.00    -0.271 OA\nATOM   1540  CB  ALA   208      37.314  31.116  18.066  1.00  0.00     0.042 C \nATOM   1541  H   ALA   208      39.326  31.698  16.472  1.00  0.00     0.163 HD\nATOM   1542  N   PHE   209      36.832  28.086  16.847  1.00  0.00    -0.346 N \nATOM   1543  CA  PHE   209      35.917  27.299  16.032  1.00  0.00     0.180 C \nATOM   1544  C   PHE   209      34.767  26.643  16.799  1.00  0.00     0.241 C \nATOM   1545  O   PHE   209      33.910  26.054  16.175  1.00  0.00    -0.271 OA\nATOM   1546  CB  PHE   209      36.650  26.307  15.114  1.00  0.00     0.073 C \nATOM   1547  CG  PHE   209      37.642  25.401  15.804  1.00  0.00    -0.056 A \nATOM   1548  CD1 PHE   209      38.946  25.329  15.351  1.00  0.00     0.007 A \nATOM   1549  CD2 PHE   209      37.277  24.589  16.871  1.00  0.00     0.007 A \nATOM   1550  CE1 PHE   209      39.860  24.487  15.961  1.00  0.00     0.001 A \nATOM   1551  CE2 PHE   209      38.197  23.770  17.490  1.00  0.00     0.001 A \nATOM   1552  CZ  PHE   209      39.485  23.718  17.036  1.00  0.00     0.000 A \nATOM   1553  H   PHE   209      37.178  27.792  17.774  1.00  0.00     0.163 HD\nATOM   1554  N   ASP   210      34.671  26.790  18.117  1.00  0.00    -0.345 N \nATOM   1555  CA  ASP   210      33.506  26.278  18.829  1.00  0.00     0.186 C \nATOM   1556  C   ASP   210      33.416  26.939  20.186  1.00  0.00     0.241 C \nATOM   1557  O   ASP   210      34.434  27.243  20.807  1.00  0.00    -0.271 OA\nATOM   1558  CB  ASP   210      33.563  24.747  18.986  1.00  0.00     0.147 C \nATOM   1559  CG  ASP   210      32.703  24.004  17.990  1.00  0.00     0.175 C \nATOM   1560  OD1 ASP   210      31.539  24.400  17.804  1.00  0.00    -0.648 OA\nATOM   1561  OD2 ASP   210      33.146  22.998  17.399  1.00  0.00    -0.648 OA\nATOM   1562  H   ASP   210      35.457  27.275  18.568  1.00  0.00     0.163 HD\nATOM   1563  N   ILE   211      32.185  27.142  20.640  1.00  0.00    -0.346 N \nATOM   1564  CA  ILE   211      31.895  27.621  21.985  1.00  0.00     0.180 C \nATOM   1565  C   ILE   211      30.826  26.724  22.591  1.00  0.00     0.241 C \nATOM   1566  O   ILE   211      29.774  26.520  21.974  1.00  0.00    -0.271 OA\nATOM   1567  CB  ILE   211      31.389  29.070  21.984  1.00  0.00     0.013 C \nATOM   1568  CG1 ILE   211      32.478  30.027  21.508  1.00  0.00     0.002 C \nATOM   1569  CG2 ILE   211      30.879  29.474  23.380  1.00  0.00     0.012 C \nATOM   1570  CD1 ILE   211      31.979  31.393  21.132  1.00  0.00     0.005 C \nATOM   1571  H   ILE   211      31.431  26.926  19.940  1.00  0.00     0.163 HD\nATOM   1572  N   LYS   212      31.084  26.194  23.778  1.00  0.00    -0.346 N \nATOM   1573  CA  LYS   212      30.056  25.499  24.530  1.00  0.00     0.176 C \nATOM   1574  C   LYS   212      30.102  25.925  25.984  1.00  0.00     0.241 C \nATOM   1575  O   LYS   212      31.136  26.343  26.501  1.00  0.00    -0.271 OA\nATOM   1576  CB  LYS   212      30.178  23.980  24.388  1.00  0.00     0.035 C \nATOM   1577  CG  LYS   212      31.438  23.374  24.971  1.00  0.00     0.004 C \nATOM   1578  CD  LYS   212      31.516  21.876  24.687  1.00  0.00     0.027 C \nATOM   1579  CE  LYS   212      32.681  21.200  25.387  1.00  0.00     0.229 C \nATOM   1580  NZ  LYS   212      32.762  19.757  25.023  1.00  0.00    -0.079 N \nATOM   1581  HZ1 LYS   212      33.651  19.571  24.605  1.00  0.00     0.274 HD\nATOM   1582  HZ3 LYS   212      32.655  19.202  25.847  1.00  0.00     0.274 HD\nATOM   1583  HZ2 LYS   212      32.034  19.538  24.374  1.00  0.00     0.274 HD\nATOM   1584  H   LYS   212      32.058  26.317  24.111  1.00  0.00     0.163 HD\nATOM   1585  N   TYR   213      28.964  25.807  26.652  1.00  0.00    -0.346 N \nATOM   1586  CA  TYR   213      28.863  26.173  28.048  1.00  0.00     0.180 C \nATOM   1587  C   TYR   213      28.010  25.152  28.799  1.00  0.00     0.241 C \nATOM   1588  O   TYR   213      27.052  24.616  28.258  1.00  0.00    -0.271 OA\nATOM   1589  CB  TYR   213      28.288  27.585  28.209  1.00  0.00     0.073 C \nATOM   1590  CG  TYR   213      26.865  27.751  27.724  1.00  0.00    -0.056 A \nATOM   1591  CD1 TYR   213      25.784  27.595  28.598  1.00  0.00     0.010 A \nATOM   1592  CD2 TYR   213      26.593  28.052  26.397  1.00  0.00     0.010 A \nATOM   1593  CE1 TYR   213      24.475  27.742  28.155  1.00  0.00     0.037 A \nATOM   1594  CE2 TYR   213      25.287  28.190  25.946  1.00  0.00     0.037 A \nATOM   1595  CZ  TYR   213      24.232  28.035  26.833  1.00  0.00     0.065 A \nATOM   1596  OH  TYR   213      22.926  28.175  26.413  1.00  0.00    -0.361 OA\nATOM   1597  H   TYR   213      28.168  25.436  26.094  1.00  0.00     0.163 HD\nATOM   1598  HH  TYR   213      22.329  28.217  27.212  1.00  0.00     0.217 HD\nATOM   1599  N   SER   214      28.401  24.861  30.028  1.00  0.00    -0.344 N \nATOM   1600  CA  SER   214      27.632  23.989  30.905  1.00  0.00     0.200 C \nATOM   1601  C   SER   214      27.269  24.780  32.140  1.00  0.00     0.243 C \nATOM   1602  O   SER   214      28.138  25.188  32.900  1.00  0.00    -0.271 OA\nATOM   1603  CB  SER   214      28.446  22.771  31.309  1.00  0.00     0.199 C \nATOM   1604  OG  SER   214      27.737  22.044  32.291  1.00  0.00    -0.398 OA\nATOM   1605  H   SER   214      29.302  25.306  30.315  1.00  0.00     0.163 HD\nATOM   1606  HG  SER   214      27.914  21.066  32.178  1.00  0.00     0.209 HD\nATOM   1607  N   VAL   215      25.977  25.012  32.330  1.00  0.00    -0.346 N \nATOM   1608  CA  VAL   215      25.506  25.806  33.460  1.00  0.00     0.180 C \nATOM   1609  C   VAL   215      25.888  25.132  34.784  1.00  0.00     0.241 C \nATOM   1610  O   VAL   215      26.523  25.743  35.618  1.00  0.00    -0.271 OA\nATOM   1611  CB  VAL   215      23.993  26.079  33.344  1.00  0.00     0.009 C \nATOM   1612  CG1 VAL   215      23.483  26.864  34.552  1.00  0.00     0.012 C \nATOM   1613  CG2 VAL   215      23.682  26.820  32.027  1.00  0.00     0.012 C \nATOM   1614  H   VAL   215      25.346  24.591  31.624  1.00  0.00     0.163 HD\nATOM   1615  N   SER   216      25.588  23.846  34.916  1.00  0.00    -0.344 N \nATOM   1616  CA  SER   216      25.933  23.085  36.117  1.00  0.00     0.200 C \nATOM   1617  C   SER   216      27.445  22.859  36.224  1.00  0.00     0.242 C \nATOM   1618  O   SER   216      27.991  22.721  37.320  1.00  0.00    -0.271 OA\nATOM   1619  CB  SER   216      25.210  21.737  36.095  1.00  0.00     0.199 C \nATOM   1620  OG  SER   216      25.802  20.883  35.133  1.00  0.00    -0.398 OA\nATOM   1621  H   SER   216      25.092  23.428  34.102  1.00  0.00     0.163 HD\nATOM   1622  HG  SER   216      25.099  20.303  34.723  1.00  0.00     0.209 HD\nATOM   1623  N   GLY   217      28.118  22.834  35.072  1.00  0.00    -0.350 N \nATOM   1624  CA  GLY   217      29.517  22.458  34.985  1.00  0.00     0.225 C \nATOM   1625  C   GLY   217      29.713  21.020  34.546  1.00  0.00     0.236 C \nATOM   1626  O   GLY   217      30.794  20.661  34.108  1.00  0.00    -0.272 OA\nATOM   1627  H   GLY   217      27.545  23.110  34.239  1.00  0.00     0.163 HD\nATOM   1628  N   ALA   218      28.673  20.197  34.662  1.00  0.00    -0.347 N \nATOM   1629  CA  ALA   218      28.756  18.795  34.282  1.00  0.00     0.172 C \nATOM   1630  C   ALA   218      28.910  18.623  32.775  1.00  0.00     0.240 C \nATOM   1631  O   ALA   218      28.307  19.363  31.989  1.00  0.00    -0.271 OA\nATOM   1632  CB  ALA   218      27.532  18.046  34.772  1.00  0.00     0.042 C \nATOM   1633  H   ALA   218      27.811  20.639  35.042  1.00  0.00     0.163 HD\nATOM   1634  N   GLU   219      29.705  17.632  32.382  1.00  0.00    -0.346 N \nATOM   1635  CA  GLU   219      29.967  17.343  30.976  1.00  0.00     0.177 C \nATOM   1636  C   GLU   219      28.684  17.103  30.180  1.00  0.00     0.241 C \nATOM   1637  O   GLU   219      28.535  17.568  29.050  1.00  0.00    -0.271 OA\nATOM   1638  CB  GLU   219      30.864  16.105  30.858  1.00  0.00     0.045 C \nATOM   1639  CG  GLU   219      31.492  15.913  29.484  1.00  0.00     0.116 C \nATOM   1640  CD  GLU   219      32.713  16.793  29.232  1.00  0.00     0.172 C \nATOM   1641  OE1 GLU   219      33.159  17.537  30.130  1.00  0.00    -0.648 OA\nATOM   1642  OE2 GLU   219      33.250  16.717  28.122  1.00  0.00    -0.648 OA\nATOM   1643  H   GLU   219      30.124  17.080  33.164  1.00  0.00     0.163 HD\nATOM   1644  N   GLU   220      27.748  16.376  30.781  1.00  0.00    -0.346 N \nATOM   1645  CA  GLU   220      26.516  16.008  30.093  1.00  0.00     0.177 C \nATOM   1646  C   GLU   220      25.578  17.197  29.861  1.00  0.00     0.241 C \nATOM   1647  O   GLU   220      24.645  17.093  29.075  1.00  0.00    -0.271 OA\nATOM   1648  CB  GLU   220      25.789  14.888  30.836  1.00  0.00     0.045 C \nATOM   1649  CG  GLU   220      25.267  15.282  32.208  1.00  0.00     0.116 C \nATOM   1650  CD  GLU   220      26.232  14.956  33.338  1.00  0.00     0.172 C \nATOM   1651  OE1 GLU   220      27.466  14.945  33.101  1.00  0.00    -0.648 OA\nATOM   1652  OE2 GLU   220      25.751  14.718  34.478  1.00  0.00    -0.648 OA\nATOM   1653  H   GLU   220      27.965  16.101  31.756  1.00  0.00     0.163 HD\nATOM   1654  N   ASP   221      25.822  18.311  30.545  1.00  0.00    -0.346 N \nATOM   1655  CA  ASP   221      24.996  19.506  30.399  1.00  0.00     0.186 C \nATOM   1656  C   ASP   221      25.567  20.556  29.458  1.00  0.00     0.241 C \nATOM   1657  O   ASP   221      25.019  21.653  29.374  1.00  0.00    -0.271 OA\nATOM   1658  CB  ASP   221      24.778  20.149  31.765  1.00  0.00     0.147 C \nATOM   1659  CG  ASP   221      23.989  19.274  32.694  1.00  0.00     0.175 C \nATOM   1660  OD1 ASP   221      23.201  18.448  32.193  1.00  0.00    -0.648 OA\nATOM   1661  OD2 ASP   221      24.108  19.355  33.929  1.00  0.00    -0.648 OA\nATOM   1662  H   ASP   221      26.641  18.258  31.184  1.00  0.00     0.163 HD\nATOM   1663  N   PHE   222      26.648  20.252  28.748  1.00  0.00    -0.346 N \nATOM   1664  CA  PHE   222      27.171  21.223  27.800  1.00  0.00     0.180 C \nATOM   1665  C   PHE   222      26.120  21.547  26.740  1.00  0.00     0.241 C \nATOM   1666  O   PHE   222      25.434  20.654  26.228  1.00  0.00    -0.271 OA\nATOM   1667  CB  PHE   222      28.449  20.714  27.121  1.00  0.00     0.073 C \nATOM   1668  CG  PHE   222      29.716  21.066  27.861  1.00  0.00    -0.056 A \nATOM   1669  CD1 PHE   222      30.053  22.388  28.100  1.00  0.00     0.007 A \nATOM   1670  CD2 PHE   222      30.572  20.075  28.318  1.00  0.00     0.007 A \nATOM   1671  CE1 PHE   222      31.214  22.716  28.773  1.00  0.00     0.001 A \nATOM   1672  CE2 PHE   222      31.740  20.408  28.987  1.00  0.00     0.001 A \nATOM   1673  CZ  PHE   222      32.055  21.727  29.212  1.00  0.00     0.000 A \nATOM   1674  H   PHE   222      27.053  19.329  28.920  1.00  0.00     0.163 HD\nATOM   1675  N   VAL   223      26.035  22.828  26.411  1.00  0.00    -0.346 N \nATOM   1676  CA  VAL   223      25.230  23.347  25.315  1.00  0.00     0.180 C \nATOM   1677  C   VAL   223      26.205  23.972  24.318  1.00  0.00     0.241 C \nATOM   1678  O   VAL   223      26.967  24.855  24.669  1.00  0.00    -0.271 OA\nATOM   1679  CB  VAL   223      24.244  24.414  25.819  1.00  0.00     0.009 C \nATOM   1680  CG1 VAL   223      23.513  25.057  24.660  1.00  0.00     0.012 C \nATOM   1681  CG2 VAL   223      23.257  23.799  26.816  1.00  0.00     0.012 C \nATOM   1682  H   VAL   223      26.618  23.461  27.029  1.00  0.00     0.163 HD\nATOM   1683  N   LEU   224      26.168  23.493  23.088  1.00  0.00    -0.346 N \nATOM   1684  CA  LEU   224      27.019  23.989  22.026  1.00  0.00     0.177 C \nATOM   1685  C   LEU   224      26.317  25.098  21.264  1.00  0.00     0.241 C \nATOM   1686  O   LEU   224      25.157  24.945  20.894  1.00  0.00    -0.271 OA\nATOM   1687  CB  LEU   224      27.327  22.825  21.093  1.00  0.00     0.038 C \nATOM   1688  CG  LEU   224      28.348  23.056  19.987  1.00  0.00    -0.020 C \nATOM   1689  CD1 LEU   224      29.725  23.376  20.537  1.00  0.00     0.009 C \nATOM   1690  CD2 LEU   224      28.410  21.834  19.078  1.00  0.00     0.009 C \nATOM   1691  H   LEU   224      25.469  22.723  22.946  1.00  0.00     0.163 HD\nATOM   1692  N   LEU   225      26.994  26.218  21.040  1.00  0.00    -0.346 N \nATOM   1693  CA  LEU   225      26.421  27.253  20.188  1.00  0.00     0.177 C \nATOM   1694  C   LEU   225      26.317  26.770  18.758  1.00  0.00     0.240 C \nATOM   1695  O   LEU   225      27.252  26.178  18.231  1.00  0.00    -0.271 OA\nATOM   1696  CB  LEU   225      27.243  28.549  20.247  1.00  0.00     0.038 C \nATOM   1697  CG  LEU   225      27.296  29.274  21.595  1.00  0.00    -0.020 C \nATOM   1698  CD1 LEU   225      27.938  30.630  21.427  1.00  0.00     0.009 C \nATOM   1699  CD2 LEU   225      25.946  29.449  22.241  1.00  0.00     0.009 C \nATOM   1700  H   LEU   225      27.910  26.286  21.497  1.00  0.00     0.163 HD\nATOM   1701  N   GLY   226      25.175  27.033  18.133  1.00  0.00    -0.351 N \nATOM   1702  CA  GLY   226      25.039  26.869  16.704  1.00  0.00     0.225 C \nATOM   1703  C   GLY   226      25.896  27.870  15.955  1.00  0.00     0.236 C \nATOM   1704  O   GLY   226      26.406  28.821  16.539  1.00  0.00    -0.272 OA\nATOM   1705  H   GLY   226      24.407  27.360  18.754  1.00  0.00     0.163 HD\nATOM   1706  N   TYR   227      26.044  27.687  14.646  1.00  0.00    -0.346 N \nATOM   1707  CA  TYR   227      26.919  28.543  13.853  1.00  0.00     0.180 C \nATOM   1708  C   TYR   227      26.574  30.023  13.980  1.00  0.00     0.241 C \nATOM   1709  O   TYR   227      27.445  30.851  14.203  1.00  0.00    -0.271 OA\nATOM   1710  CB  TYR   227      26.930  28.122  12.352  1.00  0.00     0.073 C \nATOM   1711  CG  TYR   227      27.696  29.136  11.473  1.00  0.00    -0.056 A \nATOM   1712  CD1 TYR   227      29.083  29.141  11.432  1.00  0.00     0.010 A \nATOM   1713  CD2 TYR   227      27.011  30.140  10.784  1.00  0.00     0.010 A \nATOM   1714  CE1 TYR   227      29.782  30.112  10.719  1.00  0.00     0.037 A \nATOM   1715  CE2 TYR   227      27.690  31.107  10.066  1.00  0.00     0.037 A \nATOM   1716  CZ  TYR   227      29.078  31.065  10.038  1.00  0.00     0.065 A \nATOM   1717  OH  TYR   227      29.796  32.020   9.359  1.00  0.00    -0.361 OA\nATOM   1718  H   TYR   227      25.496  26.902  14.249  1.00  0.00     0.163 HD\nATOM   1719  HH  TYR   227      30.173  32.674  10.013  1.00  0.00     0.217 HD\nATOM   1720  N   ASP   228      25.310  30.366  13.791  1.00  0.00    -0.345 N \nATOM   1721  CA  ASP   228      24.946  31.778  13.815  1.00  0.00     0.186 C \nATOM   1722  C   ASP   228      25.205  32.398  15.177  1.00  0.00     0.241 C \nATOM   1723  O   ASP   228      25.679  33.525  15.246  1.00  0.00    -0.271 OA\nATOM   1724  CB  ASP   228      23.484  31.992  13.407  1.00  0.00     0.147 C \nATOM   1725  CG  ASP   228      23.252  31.843  11.931  1.00  0.00     0.175 C \nATOM   1726  OD1 ASP   228      24.163  32.145  11.128  1.00  0.00    -0.648 OA\nATOM   1727  OD2 ASP   228      22.162  31.439  11.489  1.00  0.00    -0.648 OA\nATOM   1728  H   ASP   228      24.651  29.601  13.636  1.00  0.00     0.163 HD\nATOM   1729  N   GLU   229      24.890  31.673  16.250  1.00  0.00    -0.346 N \nATOM   1730  CA  GLU   229      25.155  32.179  17.590  1.00  0.00     0.177 C \nATOM   1731  C   GLU   229      26.655  32.275  17.870  1.00  0.00     0.241 C \nATOM   1732  O   GLU   229      27.114  33.219  18.502  1.00  0.00    -0.271 OA\nATOM   1733  CB  GLU   229      24.560  31.264  18.656  1.00  0.00     0.045 C \nATOM   1734  CG  GLU   229      23.087  30.921  18.670  1.00  0.00     0.116 C \nATOM   1735  CD  GLU   229      22.817  29.847  19.722  1.00  0.00     0.172 C \nATOM   1736  OE1 GLU   229      23.134  28.620  19.554  1.00  0.00    -0.648 OA\nATOM   1737  OE2 GLU   229      22.359  30.263  20.782  1.00  0.00    -0.648 OA\nATOM   1738  H   GLU   229      24.459  30.758  16.052  1.00  0.00     0.163 HD\nATOM   1739  N   PHE   230      27.411  31.281  17.400  1.00  0.00    -0.346 N \nATOM   1740  CA  PHE   230      28.858  31.280  17.530  1.00  0.00     0.180 C \nATOM   1741  C   PHE   230      29.440  32.551  16.899  1.00  0.00     0.241 C \nATOM   1742  O   PHE   230      30.287  33.219  17.494  1.00  0.00    -0.271 OA\nATOM   1743  CB  PHE   230      29.439  30.020  16.878  1.00  0.00     0.073 C \nATOM   1744  CG  PHE   230      30.927  30.071  16.714  1.00  0.00    -0.056 A \nATOM   1745  CD1 PHE   230      31.768  29.788  17.779  1.00  0.00     0.007 A \nATOM   1746  CD2 PHE   230      31.489  30.414  15.503  1.00  0.00     0.007 A \nATOM   1747  CE1 PHE   230      33.141  29.846  17.624  1.00  0.00     0.001 A \nATOM   1748  CE2 PHE   230      32.870  30.471  15.352  1.00  0.00     0.001 A \nATOM   1749  CZ  PHE   230      33.691  30.207  16.413  1.00  0.00     0.000 A \nATOM   1750  H   PHE   230      26.875  30.516  16.937  1.00  0.00     0.163 HD\nATOM   1751  N   VAL   231      29.005  32.874  15.692  1.00  0.00    -0.346 N \nATOM   1752  CA  VAL   231      29.494  34.075  15.026  1.00  0.00     0.180 C \nATOM   1753  C   VAL   231      29.042  35.345  15.750  1.00  0.00     0.241 C \nATOM   1754  O   VAL   231      29.809  36.292  15.914  1.00  0.00    -0.271 OA\nATOM   1755  CB  VAL   231      29.039  34.095  13.559  1.00  0.00     0.009 C \nATOM   1756  CG1 VAL   231      29.184  35.478  12.942  1.00  0.00     0.012 C \nATOM   1757  CG2 VAL   231      29.770  33.030  12.771  1.00  0.00     0.012 C \nATOM   1758  H   VAL   231      28.316  32.227  15.279  1.00  0.00     0.163 HD\nATOM   1759  N   GLU   232      27.795  35.382  16.192  1.00  0.00    -0.346 N \nATOM   1760  CA  GLU   232      27.276  36.556  16.891  1.00  0.00     0.177 C \nATOM   1761  C   GLU   232      28.099  36.848  18.136  1.00  0.00     0.241 C \nATOM   1762  O   GLU   232      28.558  37.970  18.328  1.00  0.00    -0.271 OA\nATOM   1763  CB  GLU   232      25.816  36.329  17.257  1.00  0.00     0.045 C \nATOM   1764  CG  GLU   232      25.122  37.393  18.094  1.00  0.00     0.116 C \nATOM   1765  CD  GLU   232      23.752  36.913  18.571  1.00  0.00     0.172 C \nATOM   1766  OE1 GLU   232      23.463  36.970  19.792  1.00  0.00    -0.648 OA\nATOM   1767  OE2 GLU   232      22.958  36.454  17.717  1.00  0.00    -0.648 OA\nATOM   1768  H   GLU   232      27.233  34.533  16.006  1.00  0.00     0.163 HD\nATOM   1769  N   PHE   233      28.283  35.851  18.984  1.00  0.00    -0.346 N \nATOM   1770  CA  PHE   233      29.073  36.053  20.182  1.00  0.00     0.180 C \nATOM   1771  C   PHE   233      30.542  36.335  19.861  1.00  0.00     0.241 C \nATOM   1772  O   PHE   233      31.124  37.248  20.425  1.00  0.00    -0.271 OA\nATOM   1773  CB  PHE   233      28.918  34.851  21.126  1.00  0.00     0.073 C \nATOM   1774  CG  PHE   233      27.628  34.870  21.910  1.00  0.00    -0.056 A \nATOM   1775  CD1 PHE   233      27.508  35.630  23.064  1.00  0.00     0.007 A \nATOM   1776  CD2 PHE   233      26.518  34.163  21.494  1.00  0.00     0.007 A \nATOM   1777  CE1 PHE   233      26.307  35.669  23.781  1.00  0.00     0.001 A \nATOM   1778  CE2 PHE   233      25.323  34.204  22.217  1.00  0.00     0.001 A \nATOM   1779  CZ  PHE   233      25.219  34.953  23.352  1.00  0.00     0.000 A \nATOM   1780  H   PHE   233      27.835  34.959  18.728  1.00  0.00     0.163 HD\nATOM   1781  N   SER   234      31.141  35.562  18.961  1.00  0.00    -0.344 N \nATOM   1782  CA  SER   234      32.563  35.737  18.674  1.00  0.00     0.200 C \nATOM   1783  C   SER   234      32.854  37.127  18.121  1.00  0.00     0.243 C \nATOM   1784  O   SER   234      33.880  37.712  18.422  1.00  0.00    -0.271 OA\nATOM   1785  CB  SER   234      33.056  34.677  17.690  1.00  0.00     0.199 C \nATOM   1786  OG  SER   234      33.032  33.383  18.253  1.00  0.00    -0.398 OA\nATOM   1787  H   SER   234      30.543  34.862  18.506  1.00  0.00     0.163 HD\nATOM   1788  HG  SER   234      33.709  32.805  17.797  1.00  0.00     0.209 HD\nATOM   1789  N   SER   235      31.927  37.648  17.327  1.00  0.00    -0.344 N \nATOM   1790  CA  SER   235      32.088  38.960  16.730  1.00  0.00     0.200 C \nATOM   1791  C   SER   235      32.074  40.074  17.772  1.00  0.00     0.243 C \nATOM   1792  O   SER   235      32.512  41.179  17.487  1.00  0.00    -0.271 OA\nATOM   1793  CB  SER   235      30.990  39.214  15.689  1.00  0.00     0.199 C \nATOM   1794  OG  SER   235      29.741  39.475  16.288  1.00  0.00    -0.398 OA\nATOM   1795  H   SER   235      31.094  37.044  17.175  1.00  0.00     0.163 HD\nATOM   1796  HG  SER   235      29.566  38.804  17.009  1.00  0.00     0.209 HD\nATOM   1797  N   LYS   236      31.562  39.791  18.961  1.00  0.00    -0.346 N \nATOM   1798  CA  LYS   236      31.507  40.755  20.050  1.00  0.00     0.176 C \nATOM   1799  C   LYS   236      32.664  40.610  21.030  1.00  0.00     0.241 C \nATOM   1800  O   LYS   236      32.768  41.369  21.982  1.00  0.00    -0.271 OA\nATOM   1801  CB  LYS   236      30.182  40.620  20.791  1.00  0.00     0.035 C \nATOM   1802  CG  LYS   236      28.984  40.959  19.941  1.00  0.00     0.004 C \nATOM   1803  CD  LYS   236      27.680  40.728  20.698  1.00  0.00     0.027 C \nATOM   1804  CE  LYS   236      26.461  40.951  19.825  1.00  0.00     0.229 C \nATOM   1805  NZ  LYS   236      25.221  40.474  20.501  1.00  0.00    -0.079 N \nATOM   1806  HZ1 LYS   236      24.823  41.224  21.029  1.00  0.00     0.274 HD\nATOM   1807  HZ3 LYS   236      24.567  40.164  19.812  1.00  0.00     0.274 HD\nATOM   1808  HZ2 LYS   236      25.448  39.717  21.112  1.00  0.00     0.274 HD\nATOM   1809  H   LYS   236      31.199  38.811  19.051  1.00  0.00     0.163 HD\nATOM   1810  N   VAL   237      33.530  39.630  20.824  1.00  0.00    -0.346 N \nATOM   1811  CA  VAL   237      34.682  39.423  21.688  1.00  0.00     0.180 C \nATOM   1812  C   VAL   237      35.854  40.128  21.004  1.00  0.00     0.243 C \nATOM   1813  O   VAL   237      36.223  39.774  19.891  1.00  0.00    -0.271 OA\nATOM   1814  CB  VAL   237      34.966  37.932  21.869  1.00  0.00     0.009 C \nATOM   1815  CG1 VAL   237      36.233  37.736  22.678  1.00  0.00     0.012 C \nATOM   1816  CG2 VAL   237      33.807  37.235  22.539  1.00  0.00     0.012 C \nATOM   1817  H   VAL   237      33.318  39.027  20.000  1.00  0.00     0.163 HD\nATOM   1818  N   PRO   238      36.429  41.156  21.629  1.00  0.00    -0.337 N \nATOM   1819  CA  PRO   238      37.351  42.034  20.903  1.00  0.00     0.179 C \nATOM   1820  C   PRO   238      38.607  41.300  20.442  1.00  0.00     0.241 C \nATOM   1821  O   PRO   238      39.302  40.676  21.236  1.00  0.00    -0.271 OA\nATOM   1822  CB  PRO   238      37.703  43.117  21.945  1.00  0.00     0.037 C \nATOM   1823  CG  PRO   238      37.468  42.480  23.263  1.00  0.00     0.022 C \nATOM   1824  CD  PRO   238      36.278  41.586  23.033  1.00  0.00     0.127 C \nATOM   1825  N   ASN   239      38.887  41.433  19.157  1.00  0.00    -0.346 N \nATOM   1826  CA  ASN   239      40.049  40.850  18.509  1.00  0.00     0.185 C \nATOM   1827  C   ASN   239      40.062  39.329  18.476  1.00  0.00     0.241 C \nATOM   1828  O   ASN   239      41.108  38.726  18.303  1.00  0.00    -0.271 OA\nATOM   1829  CB  ASN   239      41.345  41.421  19.100  1.00  0.00     0.137 C \nATOM   1830  CG  ASN   239      41.437  42.911  18.908  1.00  0.00     0.217 C \nATOM   1831  OD1 ASN   239      41.389  43.427  17.775  1.00  0.00    -0.274 OA\nATOM   1832  ND2 ASN   239      41.634  43.618  20.000  1.00  0.00    -0.370 N \nATOM   1833 2HD2 ASN   239      41.701  44.627  19.949  1.00  0.00     0.159 HD\nATOM   1834 1HD2 ASN   239      41.720  43.169  20.891  1.00  0.00     0.159 HD\nATOM   1835  H   ASN   239      38.178  42.013  18.627  1.00  0.00     0.163 HD\nATOM   1836  N   LEU   240      38.906  38.699  18.628  1.00  0.00    -0.346 N \nATOM   1837  CA  LEU   240      38.835  37.260  18.480  1.00  0.00     0.177 C \nATOM   1838  C   LEU   240      38.710  36.909  17.002  1.00  0.00     0.241 C \nATOM   1839  O   LEU   240      37.755  37.330  16.346  1.00  0.00    -0.271 OA\nATOM   1840  CB  LEU   240      37.652  36.692  19.242  1.00  0.00     0.038 C \nATOM   1841  CG  LEU   240      37.560  35.165  19.238  1.00  0.00    -0.020 C \nATOM   1842  CD1 LEU   240      38.779  34.527  19.900  1.00  0.00     0.009 C \nATOM   1843  CD2 LEU   240      36.280  34.719  19.917  1.00  0.00     0.009 C \nATOM   1844  H   LEU   240      38.099  39.301  18.851  1.00  0.00     0.163 HD\nATOM   1845  N   LEU   241      39.662  36.148  16.486  1.00  0.00    -0.346 N \nATOM   1846  CA  LEU   241      39.554  35.557  15.170  1.00  0.00     0.177 C \nATOM   1847  C   LEU   241      38.723  34.293  15.250  1.00  0.00     0.241 C \nATOM   1848  O   LEU   241      38.920  33.501  16.165  1.00  0.00    -0.271 OA\nATOM   1849  CB  LEU   241      40.940  35.203  14.693  1.00  0.00     0.038 C \nATOM   1850  CG  LEU   241      41.057  34.675  13.300  1.00  0.00    -0.020 C \nATOM   1851  CD1 LEU   241      40.632  35.696  12.263  1.00  0.00     0.009 C \nATOM   1852  CD2 LEU   241      42.495  34.257  13.101  1.00  0.00     0.009 C \nATOM   1853  H   LEU   241      40.492  36.013  17.109  1.00  0.00     0.163 HD\nATOM   1854  N   TYR   242      37.825  34.094  14.294  1.00  0.00    -0.346 N \nATOM   1855  CA  TYR   242      36.907  32.968  14.366  1.00  0.00     0.180 C \nATOM   1856  C   TYR   242      36.560  32.453  12.987  1.00  0.00     0.241 C \nATOM   1857  O   TYR   242      36.647  33.158  11.996  1.00  0.00    -0.271 OA\nATOM   1858  CB  TYR   242      35.637  33.338  15.167  1.00  0.00     0.073 C \nATOM   1859  CG  TYR   242      34.825  34.445  14.570  1.00  0.00    -0.056 A \nATOM   1860  CD1 TYR   242      33.820  34.167  13.660  1.00  0.00     0.010 A \nATOM   1861  CD2 TYR   242      35.068  35.766  14.893  1.00  0.00     0.010 A \nATOM   1862  CE1 TYR   242      33.080  35.177  13.089  1.00  0.00     0.037 A \nATOM   1863  CE2 TYR   242      34.326  36.800  14.306  1.00  0.00     0.037 A \nATOM   1864  CZ  TYR   242      33.327  36.485  13.412  1.00  0.00     0.065 A \nATOM   1865  OH  TYR   242      32.567  37.453  12.822  1.00  0.00    -0.361 OA\nATOM   1866  H   TYR   242      37.836  34.782  13.526  1.00  0.00     0.163 HD\nATOM   1867  HH  TYR   242      32.966  38.351  13.010  1.00  0.00     0.217 HD\nATOM   1868  N   ALA   243      36.145  31.196  12.961  1.00  0.00    -0.346 N \nATOM   1869  CA  ALA   243      35.753  30.512  11.743  1.00  0.00     0.172 C \nATOM   1870  C   ALA   243      34.511  31.147  11.153  1.00  0.00     0.240 C \nATOM   1871  O   ALA   243      33.491  31.279  11.815  1.00  0.00    -0.271 OA\nATOM   1872  CB  ALA   243      35.491  29.061  12.046  1.00  0.00     0.042 C \nATOM   1873  H   ALA   243      36.124  30.733  13.905  1.00  0.00     0.163 HD\nATOM   1874  N   ARG   244      34.626  31.574   9.908  1.00  0.00    -0.346 N \nATOM   1875  CA  ARG   244      33.524  32.200   9.191  1.00  0.00     0.176 C \nATOM   1876  C   ARG   244      33.220  31.423   7.931  1.00  0.00     0.241 C \nATOM   1877  O   ARG   244      34.126  30.957   7.237  1.00  0.00    -0.271 OA\nATOM   1878  CB  ARG   244      33.879  33.637   8.815  1.00  0.00     0.036 C \nATOM   1879  CG  ARG   244      33.823  34.612   9.968  1.00  0.00     0.023 C \nATOM   1880  CD  ARG   244      33.913  36.059   9.546  1.00  0.00     0.138 C \nATOM   1881  NE  ARG   244      32.599  36.600   9.181  1.00  0.00    -0.227 N \nATOM   1882  CZ  ARG   244      32.152  36.823   7.941  1.00  0.00     0.665 C \nATOM   1883  NH1 ARG   244      32.899  36.555   6.871  1.00  0.00    -0.235 N \nATOM   1884  NH2 ARG   244      30.929  37.325   7.771  1.00  0.00    -0.235 N \nATOM   1885  HE  ARG   244      31.965  36.829   9.945  1.00  0.00     0.177 HD\nATOM   1886 2HH2 ARG   244      30.594  37.512   6.850  1.00  0.00     0.174 HD\nATOM   1887 1HH2 ARG   244      30.351  37.511   8.564  1.00  0.00     0.174 HD\nATOM   1888  H   ARG   244      35.570  31.426   9.483  1.00  0.00     0.163 HD\nATOM   1889 2HH1 ARG   244      32.547  36.749   5.959  1.00  0.00     0.174 HD\nATOM   1890 1HH1 ARG   244      33.809  36.159   6.986  1.00  0.00     0.174 HD\nATOM   1891  N   ALA   245      31.945  31.334   7.605  1.00  0.00    -0.346 N \nATOM   1892  CA  ALA   245      31.513  30.532   6.477  1.00  0.00     0.172 C \nATOM   1893  C   ALA   245      32.079  31.037   5.154  1.00  0.00     0.240 C \nATOM   1894  O   ALA   245      31.967  32.224   4.830  1.00  0.00    -0.271 OA\nATOM   1895  CB  ALA   245      30.004  30.502   6.410  1.00  0.00     0.042 C \nATOM   1896  H   ALA   245      31.296  31.873   8.210  1.00  0.00     0.163 HD\nATOM   1897  N   LEU   246      32.673  30.116   4.412  1.00  0.00    -0.346 N \nATOM   1898  CA  LEU   246      33.148  30.319   3.054  1.00  0.00     0.177 C \nATOM   1899  C   LEU   246      32.042  30.063   2.046  1.00  0.00     0.241 C \nATOM   1900  O   LEU   246      32.049  30.613   0.943  1.00  0.00    -0.271 OA\nATOM   1901  CB  LEU   246      34.289  29.351   2.786  1.00  0.00     0.038 C \nATOM   1902  CG  LEU   246      35.485  29.487   3.723  1.00  0.00    -0.020 C \nATOM   1903  CD1 LEU   246      36.319  28.224   3.681  1.00  0.00     0.009 C \nATOM   1904  CD2 LEU   246      36.327  30.698   3.371  1.00  0.00     0.009 C \nATOM   1905  H   LEU   246      32.778  29.182   4.910  1.00  0.00     0.163 HD\nATOM   1906  N   VAL   247      31.129  29.180   2.418  1.00  0.00    -0.346 N \nATOM   1907  CA  VAL   247      29.928  28.863   1.674  1.00  0.00     0.180 C \nATOM   1908  C   VAL   247      28.893  28.400   2.690  1.00  0.00     0.241 C \nATOM   1909  O   VAL   247      29.244  27.873   3.760  1.00  0.00    -0.271 OA\nATOM   1910  CB  VAL   247      30.189  27.794   0.559  1.00  0.00     0.009 C \nATOM   1911  CG1 VAL   247      30.693  26.520   1.131  1.00  0.00     0.012 C \nATOM   1912  CG2 VAL   247      28.960  27.559  -0.292  1.00  0.00     0.012 C \nATOM   1913  H   VAL   247      31.361  28.706   3.343  1.00  0.00     0.163 HD\nATOM   1914  N   ARG   248      27.626  28.610   2.372  1.00  0.00    -0.346 N \nATOM   1915  CA  ARG   248      26.515  28.215   3.215  1.00  0.00     0.176 C \nATOM   1916  C   ARG   248      25.436  27.690   2.296  1.00  0.00     0.240 C \nATOM   1917  O   ARG   248      25.138  28.306   1.266  1.00  0.00    -0.271 OA\nATOM   1918  CB  ARG   248      26.011  29.411   4.010  1.00  0.00     0.036 C \nATOM   1919  CG  ARG   248      24.874  29.107   4.946  1.00  0.00     0.023 C \nATOM   1920  CD  ARG   248      24.629  30.221   5.889  1.00  0.00     0.138 C \nATOM   1921  NE  ARG   248      23.535  29.925   6.797  1.00  0.00    -0.227 N \nATOM   1922  CZ  ARG   248      23.450  30.417   8.019  1.00  0.00     0.665 C \nATOM   1923  NH1 ARG   248      24.393  31.211   8.491  1.00  0.00    -0.235 N \nATOM   1924  NH2 ARG   248      22.412  30.111   8.783  1.00  0.00    -0.235 N \nATOM   1925  HE  ARG   248      22.806  29.314   6.477  1.00  0.00     0.177 HD\nATOM   1926 2HH2 ARG   248      22.347  30.464   9.717  1.00  0.00     0.174 HD\nATOM   1927 1HH2 ARG   248      21.682  29.522   8.426  1.00  0.00     0.174 HD\nATOM   1928  H   ARG   248      27.493  29.093   1.445  1.00  0.00     0.163 HD\nATOM   1929 2HH1 ARG   248      24.326  31.567   9.436  1.00  0.00     0.174 HD\nATOM   1930 1HH1 ARG   248      25.174  31.467   7.924  1.00  0.00     0.174 HD\nATOM   1931  N   GLY   249      24.828  26.579   2.659  1.00  0.00    -0.351 N \nATOM   1932  CA  GLY   249      23.780  25.988   1.840  1.00  0.00     0.225 C \nATOM   1933  C   GLY   249      23.474  24.582   2.289  1.00  0.00     0.236 C \nATOM   1934  O   GLY   249      23.702  24.219   3.439  1.00  0.00    -0.272 OA\nATOM   1935  H   GLY   249      25.151  26.170   3.557  1.00  0.00     0.163 HD\nATOM   1936  N   THR   250      22.967  23.762   1.382  1.00  0.00    -0.344 N \nATOM   1937  CA  THR   250      22.789  22.362   1.694  1.00  0.00     0.205 C \nATOM   1938  C   THR   250      24.148  21.692   1.883  1.00  0.00     0.243 C \nATOM   1939  O   THR   250      25.204  22.225   1.534  1.00  0.00    -0.271 OA\nATOM   1940  CB  THR   250      22.056  21.631   0.575  1.00  0.00     0.146 C \nATOM   1941  OG1 THR   250      22.873  21.700  -0.596  1.00  0.00    -0.393 OA\nATOM   1942  CG2 THR   250      20.701  22.271   0.249  1.00  0.00     0.042 C \nATOM   1943  H   THR   250      22.724  24.193   0.479  1.00  0.00     0.163 HD\nATOM   1944  HG1 THR   250      22.795  22.606  -1.026  1.00  0.00     0.210 HD\nATOM   1945  N   LEU   251      24.112  20.488   2.417  1.00  0.00    -0.346 N \nATOM   1946  CA  LEU   251      25.330  19.708   2.550  1.00  0.00     0.177 C \nATOM   1947  C   LEU   251      26.045  19.600   1.197  1.00  0.00     0.241 C \nATOM   1948  O   LEU   251      27.254  19.795   1.101  1.00  0.00    -0.271 OA\nATOM   1949  CB  LEU   251      25.009  18.337   3.126  1.00  0.00     0.038 C \nATOM   1950  CG  LEU   251      26.156  17.332   3.149  1.00  0.00    -0.020 C \nATOM   1951  CD1 LEU   251      27.254  17.823   4.081  1.00  0.00     0.009 C \nATOM   1952  CD2 LEU   251      25.619  15.984   3.574  1.00  0.00     0.009 C \nATOM   1953  H   LEU   251      23.182  20.160   2.720  1.00  0.00     0.163 HD\nATOM   1954  N   ASP   252      25.303  19.276   0.140  1.00  0.00    -0.346 N \nATOM   1955  CA  ASP   252      25.914  19.128  -1.173  1.00  0.00     0.186 C \nATOM   1956  C   ASP   252      26.521  20.425  -1.697  1.00  0.00     0.241 C \nATOM   1957  O   ASP   252      27.577  20.395  -2.307  1.00  0.00    -0.271 OA\nATOM   1958  CB  ASP   252      24.906  18.548  -2.167  1.00  0.00     0.147 C \nATOM   1959  CG  ASP   252      24.785  17.048  -2.057  1.00  0.00     0.175 C \nATOM   1960  OD1 ASP   252      25.827  16.360  -1.967  1.00  0.00    -0.648 OA\nATOM   1961  OD2 ASP   252      23.678  16.478  -2.067  1.00  0.00    -0.648 OA\nATOM   1962  H   ASP   252      24.299  19.145   0.329  1.00  0.00     0.163 HD\nATOM   1963  N   GLU   253      25.881  21.559  -1.434  1.00  0.00    -0.346 N \nATOM   1964  CA  GLU   253      26.433  22.836  -1.854  1.00  0.00     0.177 C \nATOM   1965  C   GLU   253      27.767  23.097  -1.147  1.00  0.00     0.241 C \nATOM   1966  O   GLU   253      28.715  23.593  -1.758  1.00  0.00    -0.271 OA\nATOM   1967  CB  GLU   253      25.425  23.960  -1.627  1.00  0.00     0.045 C \nATOM   1968  CG  GLU   253      24.331  23.948  -2.685  1.00  0.00     0.116 C \nATOM   1969  CD  GLU   253      23.134  24.814  -2.371  1.00  0.00     0.172 C \nATOM   1970  OE1 GLU   253      22.884  25.175  -1.210  1.00  0.00    -0.648 OA\nATOM   1971  OE2 GLU   253      22.407  25.124  -3.328  1.00  0.00    -0.648 OA\nATOM   1972  H   GLU   253      24.990  21.454  -0.924  1.00  0.00     0.163 HD\nATOM   1973  N   CYS   254      27.852  22.762   0.136  1.00  0.00    -0.345 N \nATOM   1974  CA  CYS   254      29.111  22.939   0.864  1.00  0.00     0.185 C \nATOM   1975  C   CYS   254      30.188  21.962   0.385  1.00  0.00     0.241 C \nATOM   1976  O   CYS   254      31.354  22.322   0.265  1.00  0.00    -0.271 OA\nATOM   1977  CB  CYS   254      28.871  22.790   2.351  1.00  0.00     0.105 C \nATOM   1978  SG  CYS   254      27.923  24.157   3.070  1.00  0.00    -0.180 SA\nATOM   1979  H   CYS   254      26.994  22.384   0.556  1.00  0.00     0.163 HD\nATOM   1980  HG  CYS   254      28.508  24.964   3.141  1.00  0.00     0.101 HD\nATOM   1981  N   LEU   255      29.793  20.722   0.112  1.00  0.00    -0.346 N \nATOM   1982  CA  LEU   255      30.706  19.693  -0.386  1.00  0.00     0.177 C \nATOM   1983  C   LEU   255      31.281  20.029  -1.745  1.00  0.00     0.241 C \nATOM   1984  O   LEU   255      32.314  19.480  -2.101  1.00  0.00    -0.271 OA\nATOM   1985  CB  LEU   255      30.007  18.335  -0.438  1.00  0.00     0.038 C \nATOM   1986  CG  LEU   255      29.841  17.656   0.910  1.00  0.00    -0.020 C \nATOM   1987  CD1 LEU   255      28.872  16.499   0.750  1.00  0.00     0.009 C \nATOM   1988  CD2 LEU   255      31.168  17.175   1.465  1.00  0.00     0.009 C \nATOM   1989  H   LEU   255      28.778  20.545   0.283  1.00  0.00     0.163 HD\nATOM   1990  N   ALA   256      30.640  20.922  -2.490  1.00  0.00    -0.346 N \nATOM   1991  CA  ALA   256      31.129  21.362  -3.791  1.00  0.00     0.172 C \nATOM   1992  C   ALA   256      32.193  22.439  -3.700  1.00  0.00     0.240 C \nATOM   1993  O   ALA   256      32.742  22.840  -4.719  1.00  0.00    -0.271 OA\nATOM   1994  CB  ALA   256      29.980  21.859  -4.637  1.00  0.00     0.042 C \nATOM   1995  H   ALA   256      29.755  21.282  -2.064  1.00  0.00     0.163 HD\nATOM   1996  N   PHE   257      32.524  22.896  -2.499  1.00  0.00    -0.346 N \nATOM   1997  CA  PHE   257      33.544  23.909  -2.344  1.00  0.00     0.180 C \nATOM   1998  C   PHE   257      34.861  23.436  -2.951  1.00  0.00     0.241 C \nATOM   1999  O   PHE   257      35.276  22.305  -2.742  1.00  0.00    -0.271 OA\nATOM   2000  CB  PHE   257      33.740  24.227  -0.868  1.00  0.00     0.073 C \nATOM   2001  CG  PHE   257      34.707  25.338  -0.625  1.00  0.00    -0.056 A \nATOM   2002  CD1 PHE   257      34.322  26.652  -0.808  1.00  0.00     0.007 A \nATOM   2003  CD2 PHE   257      36.007  25.075  -0.245  1.00  0.00     0.007 A \nATOM   2004  CE1 PHE   257      35.213  27.684  -0.604  1.00  0.00     0.001 A \nATOM   2005  CE2 PHE   257      36.908  26.105  -0.047  1.00  0.00     0.001 A \nATOM   2006  CZ  PHE   257      36.514  27.402  -0.225  1.00  0.00     0.000 A \nATOM   2007  H   PHE   257      32.001  22.473  -1.711  1.00  0.00     0.163 HD\nATOM   2008  N   ASP   258      35.528  24.336  -3.658  1.00  0.00    -0.345 N \nATOM   2009  CA  ASP   258      36.758  24.032  -4.383  1.00  0.00     0.186 C \nATOM   2010  C   ASP   258      37.981  24.047  -3.453  1.00  0.00     0.241 C \nATOM   2011  O   ASP   258      38.750  25.011  -3.450  1.00  0.00    -0.271 OA\nATOM   2012  CB  ASP   258      36.924  25.048  -5.532  1.00  0.00     0.147 C \nATOM   2013  CG  ASP   258      38.161  24.804  -6.379  1.00  0.00     0.175 C \nATOM   2014  OD1 ASP   258      38.827  23.768  -6.182  1.00  0.00    -0.648 OA\nATOM   2015  OD2 ASP   258      38.524  25.603  -7.274  1.00  0.00    -0.648 OA\nATOM   2016  H   ASP   258      35.096  25.293  -3.654  1.00  0.00     0.163 HD\nATOM   2017  N   VAL   259      38.204  22.962  -2.717  1.00  0.00    -0.346 N \nATOM   2018  CA  VAL   259      39.350  22.899  -1.796  1.00  0.00     0.180 C \nATOM   2019  C   VAL   259      40.679  22.812  -2.502  1.00  0.00     0.241 C \nATOM   2020  O   VAL   259      41.689  23.263  -1.967  1.00  0.00    -0.271 OA\nATOM   2021  CB  VAL   259      39.329  21.707  -0.794  1.00  0.00     0.009 C \nATOM   2022  CG1 VAL   259      38.391  21.969   0.354  1.00  0.00     0.012 C \nATOM   2023  CG2 VAL   259      39.043  20.365  -1.501  1.00  0.00     0.012 C \nATOM   2024  H   VAL   259      37.530  22.194  -2.841  1.00  0.00     0.163 HD\nATOM   2025  N   GLU   260      40.696  22.234  -3.701  1.00  0.00    -0.346 N \nATOM   2026  CA  GLU   260      41.948  22.057  -4.407  1.00  0.00     0.177 C \nATOM   2027  C   GLU   260      42.641  23.359  -4.725  1.00  0.00     0.241 C \nATOM   2028  O   GLU   260      43.868  23.377  -4.798  1.00  0.00    -0.271 OA\nATOM   2029  CB  GLU   260      41.725  21.268  -5.692  1.00  0.00     0.045 C \nATOM   2030  CG  GLU   260      41.405  19.815  -5.443  1.00  0.00     0.116 C \nATOM   2031  CD  GLU   260      42.546  19.114  -4.750  1.00  0.00     0.172 C \nATOM   2032  OE1 GLU   260      43.674  19.108  -5.296  1.00  0.00    -0.648 OA\nATOM   2033  OE2 GLU   260      42.319  18.578  -3.667  1.00  0.00    -0.648 OA\nATOM   2034  H   GLU   260      39.777  21.939  -4.061  1.00  0.00     0.163 HD\nATOM   2035  N   ASN   261      41.874  24.429  -4.914  1.00  0.00    -0.346 N \nATOM   2036  CA  ASN   261      42.413  25.739  -5.259  1.00  0.00     0.185 C \nATOM   2037  C   ASN   261      42.213  26.799  -4.187  1.00  0.00     0.241 C \nATOM   2038  O   ASN   261      42.382  27.980  -4.433  1.00  0.00    -0.271 OA\nATOM   2039  CB  ASN   261      41.770  26.235  -6.547  1.00  0.00     0.137 C \nATOM   2040  CG  ASN   261      42.117  25.381  -7.712  1.00  0.00     0.217 C \nATOM   2041  H   ASN   261      40.849  24.249  -4.794  1.00  0.00     0.163 HD\nATOM   2042  OD1 ASN   261      43.287  25.262  -8.065  1.00  0.00    -0.274 OA\nATOM   2043  ND2 ASN   261      41.118  24.742  -8.291  1.00  0.00    -0.370 N \nATOM   2044 2HD2 ASN   261      41.281  24.139  -9.085  1.00  0.00     0.159 HD\nATOM   2045 1HD2 ASN   261      40.181  24.849  -7.947  1.00  0.00     0.159 HD\nATOM   2046  N   PHE   262      41.856  26.378  -2.986  1.00  0.00    -0.347 N \nATOM   2047  CA  PHE   262      41.526  27.295  -1.909  1.00  0.00     0.166 C \nATOM   2048  C   PHE   262      42.820  27.756  -1.244  1.00  0.00     0.219 C \nATOM   2049  O   PHE   262      43.475  27.009  -0.504  1.00  0.00    -0.287 OA\nATOM   2050  CB  PHE   262      40.623  26.577  -0.912  1.00  0.00     0.072 C \nATOM   2051  CG  PHE   262      40.302  27.344   0.350  1.00  0.00    -0.056 A \nATOM   2052  CD1 PHE   262      40.049  28.702   0.346  1.00  0.00     0.007 A \nATOM   2053  CD2 PHE   262      40.215  26.663   1.545  1.00  0.00     0.007 A \nATOM   2054  CE1 PHE   262      39.750  29.365   1.521  1.00  0.00     0.001 A \nATOM   2055  CE2 PHE   262      39.907  27.317   2.718  1.00  0.00     0.001 A \nATOM   2056  CZ  PHE   262      39.678  28.680   2.701  1.00  0.00     0.000 A \nATOM   2057  H   PHE   262      41.832  25.339  -2.879  1.00  0.00     0.163 HD\nATOM   2058  N   THR   264      44.754  29.951   1.483  1.00  0.00    -0.323 NA\nATOM   2059  CA  THR   264      44.310  30.426   2.790  1.00  0.00     0.219 C \nATOM   2060  C   THR   264      44.162  31.945   2.755  1.00  0.00     0.247 C \nATOM   2061  O   THR   264      45.069  32.661   2.305  1.00  0.00    -0.271 OA\nATOM   2062  CB  THR   264      45.199  30.004   3.962  1.00  0.00     0.147 C \nATOM   2063  OG1 THR   264      44.766  30.725   5.125  1.00  0.00    -0.393 OA\nATOM   2064  CG2 THR   264      46.672  30.316   3.748  1.00  0.00     0.042 C \nATOM   2065  H   THR   264      44.936  30.524   0.682  1.00  0.00     0.180 HD\nATOM   2066  HG1 THR   264      45.521  30.810   5.783  1.00  0.00     0.210 HD\nATOM   2067  N   PRO   265      43.010  32.460   3.210  1.00  0.00    -0.337 N \nATOM   2068  CA  PRO   265      42.792  33.905   3.288  1.00  0.00     0.179 C \nATOM   2069  C   PRO   265      43.399  34.540   4.522  1.00  0.00     0.241 C \nATOM   2070  O   PRO   265      43.348  35.776   4.644  1.00  0.00    -0.271 OA\nATOM   2071  CB  PRO   265      41.271  34.014   3.362  1.00  0.00     0.037 C \nATOM   2072  CG  PRO   265      40.877  32.807   4.102  1.00  0.00     0.022 C \nATOM   2073  CD  PRO   265      41.797  31.718   3.608  1.00  0.00     0.127 C \nATOM   2074  N   LEU   266      43.947  33.752   5.439  1.00  0.00    -0.346 N \nATOM   2075  CA  LEU   266      44.418  34.304   6.694  1.00  0.00     0.177 C \nATOM   2076  C   LEU   266      45.612  35.245   6.553  1.00  0.00     0.243 C \nATOM   2077  O   LEU   266      45.612  36.270   7.213  1.00  0.00    -0.271 OA\nATOM   2078  CB  LEU   266      44.657  33.201   7.723  1.00  0.00     0.038 C \nATOM   2079  CG  LEU   266      43.361  32.643   8.324  1.00  0.00    -0.020 C \nATOM   2080  CD1 LEU   266      43.595  31.367   9.083  1.00  0.00     0.009 C \nATOM   2081  CD2 LEU   266      42.802  33.658   9.297  1.00  0.00     0.009 C \nATOM   2082  H   LEU   266      44.004  32.754   5.186  1.00  0.00     0.163 HD\nATOM   2083  N   PRO   267      46.626  34.954   5.736  1.00  0.00    -0.337 N \nATOM   2084  CA  PRO   267      47.726  35.925   5.597  1.00  0.00     0.179 C \nATOM   2085  C   PRO   267      47.230  37.330   5.280  1.00  0.00     0.241 C \nATOM   2086  O   PRO   267      47.655  38.291   5.911  1.00  0.00    -0.271 OA\nATOM   2087  CB  PRO   267      48.579  35.342   4.465  1.00  0.00     0.037 C \nATOM   2088  CG  PRO   267      48.381  33.868   4.607  1.00  0.00     0.022 C \nATOM   2089  CD  PRO   267      46.923  33.707   5.008  1.00  0.00     0.127 C \nATOM   2090  N   ALA   268      46.313  37.467   4.336  1.00  0.00    -0.346 N \nATOM   2091  CA  ALA   268      45.830  38.794   3.975  1.00  0.00     0.172 C \nATOM   2092  C   ALA   268      45.059  39.426   5.135  1.00  0.00     0.240 C \nATOM   2093  O   ALA   268      45.175  40.622   5.400  1.00  0.00    -0.271 OA\nATOM   2094  CB  ALA   268      44.990  38.739   2.733  1.00  0.00     0.042 C \nATOM   2095  H   ALA   268      45.986  36.596   3.899  1.00  0.00     0.163 HD\nATOM   2096  N   LEU   269      44.290  38.632   5.858  1.00  0.00    -0.346 N \nATOM   2097  CA  LEU   269      43.571  39.131   7.021  1.00  0.00     0.177 C \nATOM   2098  C   LEU   269      44.513  39.592   8.129  1.00  0.00     0.241 C \nATOM   2099  O   LEU   269      44.162  40.465   8.927  1.00  0.00    -0.271 OA\nATOM   2100  CB  LEU   269      42.623  38.051   7.538  1.00  0.00     0.038 C \nATOM   2101  CG  LEU   269      41.425  37.770   6.620  1.00  0.00    -0.020 C \nATOM   2102  CD1 LEU   269      40.796  36.430   6.947  1.00  0.00     0.009 C \nATOM   2103  CD2 LEU   269      40.384  38.891   6.696  1.00  0.00     0.009 C \nATOM   2104  H   LEU   269      44.243  37.648   5.535  1.00  0.00     0.163 HD\nATOM   2105  N   LEU   270      45.702  39.009   8.182  1.00  0.00    -0.346 N \nATOM   2106  CA  LEU   270      46.694  39.279   9.211  1.00  0.00     0.177 C \nATOM   2107  C   LEU   270      47.805  40.198   8.699  1.00  0.00     0.240 C \nATOM   2108  O   LEU   270      48.890  40.216   9.257  1.00  0.00    -0.271 OA\nATOM   2109  CB  LEU   270      47.243  37.949   9.719  1.00  0.00     0.038 C \nATOM   2110  CG  LEU   270      46.165  37.027  10.311  1.00  0.00    -0.020 C \nATOM   2111  CD1 LEU   270      46.769  35.669  10.658  1.00  0.00     0.009 C \nATOM   2112  CD2 LEU   270      45.498  37.651  11.532  1.00  0.00     0.009 C \nATOM   2113  H   LEU   270      45.872  38.320   7.400  1.00  0.00     0.163 HD\nATOM   2114  N   GLY   271      47.510  40.991   7.669  1.00  0.00    -0.351 N \nATOM   2115  CA  GLY   271      48.389  42.078   7.271  1.00  0.00     0.225 C \nATOM   2116  C   GLY   271      49.392  41.770   6.183  1.00  0.00     0.236 C \nATOM   2117  O   GLY   271      50.221  42.624   5.871  1.00  0.00    -0.272 OA\nATOM   2118  H   GLY   271      46.617  40.766   7.190  1.00  0.00     0.163 HD\nATOM   2119  N   LEU   272      49.310  40.586   5.585  1.00  0.00    -0.346 N \nATOM   2120  CA  LEU   272      50.345  40.113   4.687  1.00  0.00     0.177 C \nATOM   2121  C   LEU   272      49.899  40.009   3.248  1.00  0.00     0.240 C \nATOM   2122  O   LEU   272      50.517  39.307   2.463  1.00  0.00    -0.271 OA\nATOM   2123  CB  LEU   272      50.892  38.781   5.181  1.00  0.00     0.038 C \nATOM   2124  CG  LEU   272      51.331  38.756   6.636  1.00  0.00    -0.020 C \nATOM   2125  CD1 LEU   272      51.709  37.345   7.022  1.00  0.00     0.009 C \nATOM   2126  CD2 LEU   272      52.459  39.716   6.927  1.00  0.00     0.009 C \nATOM   2127  H   LEU   272      48.454  40.042   5.816  1.00  0.00     0.163 HD\nATOM   2128  N   GLY   273      48.874  40.756   2.872  1.00  0.00    -0.351 N \nATOM   2129  CA  GLY   273      48.369  40.714   1.508  1.00  0.00     0.225 C \nATOM   2130  C   GLY   273      49.389  41.082   0.439  1.00  0.00     0.236 C \nATOM   2131  O   GLY   273      49.311  40.593  -0.678  1.00  0.00    -0.272 OA\nATOM   2132  H   GLY   273      48.472  41.359   3.614  1.00  0.00     0.163 HD\nATOM   2133  N   ASN   274      50.370  41.913   0.763  1.00  0.00    -0.346 N \nATOM   2134  CA  ASN   274      51.383  42.282  -0.214  1.00  0.00     0.185 C \nATOM   2135  C   ASN   274      52.530  41.290  -0.329  1.00  0.00     0.241 C \nATOM   2136  O   ASN   274      53.406  41.491  -1.159  1.00  0.00    -0.271 OA\nATOM   2137  CB  ASN   274      51.951  43.678   0.087  1.00  0.00     0.137 C \nATOM   2138  CG  ASN   274      51.003  44.792  -0.247  1.00  0.00     0.217 C \nATOM   2139  H   ASN   274      50.352  42.262   1.735  1.00  0.00     0.163 HD\nATOM   2140  OD1 ASN   274      50.859  45.761   0.518  1.00  0.00    -0.274 OA\nATOM   2141  ND2 ASN   274      50.366  44.679  -1.370  1.00  0.00    -0.370 N \nATOM   2142 2HD2 ASN   274      49.707  45.398  -1.671  1.00  0.00     0.159 HD\nATOM   2143 1HD2 ASN   274      50.504  43.883  -1.970  1.00  0.00     0.159 HD\nATOM   2144  N   TYR   275      52.517  40.230   0.484  1.00  0.00    -0.346 N \nATOM   2145  CA  TYR   275      53.658  39.312   0.603  1.00  0.00     0.181 C \nATOM   2146  C   TYR   275      53.219  37.871   0.374  1.00  0.00     0.243 C \nATOM   2147  O   TYR   275      53.327  37.019   1.241  1.00  0.00    -0.271 OA\nATOM   2148  CB  TYR   275      54.326  39.476   1.969  1.00  0.00     0.073 C \nATOM   2149  CG  TYR   275      54.532  40.920   2.333  1.00  0.00    -0.056 A \nATOM   2150  CD1 TYR   275      55.316  41.748   1.547  1.00  0.00     0.010 A \nATOM   2151  CD2 TYR   275      53.901  41.481   3.431  1.00  0.00     0.010 A \nATOM   2152  CE1 TYR   275      55.484  43.092   1.850  1.00  0.00     0.037 A \nATOM   2153  CE2 TYR   275      54.064  42.814   3.748  1.00  0.00     0.037 A \nATOM   2154  CZ  TYR   275      54.847  43.629   2.946  1.00  0.00     0.065 A \nATOM   2155  OH  TYR   275      54.991  44.950   3.266  1.00  0.00    -0.361 OA\nATOM   2156  H   TYR   275      51.634  40.110   1.023  1.00  0.00     0.163 HD\nATOM   2157  HH  TYR   275      55.847  45.294   2.880  1.00  0.00     0.217 HD\nATOM   2158  N   PRO   276      52.701  37.587  -0.810  1.00  0.00    -0.337 N \nATOM   2159  CA  PRO   276      52.164  36.251  -1.076  1.00  0.00     0.179 C \nATOM   2160  C   PRO   276      53.257  35.193  -1.120  1.00  0.00     0.241 C \nATOM   2161  O   PRO   276      54.396  35.470  -1.514  1.00  0.00    -0.271 OA\nATOM   2162  CB  PRO   276      51.504  36.421  -2.443  1.00  0.00     0.037 C \nATOM   2163  CG  PRO   276      52.224  37.542  -3.065  1.00  0.00     0.022 C \nATOM   2164  CD  PRO   276      52.552  38.479  -1.975  1.00  0.00     0.127 C \nATOM   2165  N   LEU   277      52.884  33.977  -0.732  1.00  0.00    -0.346 N \nATOM   2166  CA  LEU   277      53.727  32.800  -0.875  1.00  0.00     0.177 C \nATOM   2167  C   LEU   277      53.105  31.902  -1.932  1.00  0.00     0.241 C \nATOM   2168  O   LEU   277      51.918  31.569  -1.880  1.00  0.00    -0.271 OA\nATOM   2169  CB  LEU   277      53.835  32.055   0.448  1.00  0.00     0.038 C \nATOM   2170  CG  LEU   277      54.541  32.810   1.576  1.00  0.00    -0.020 C \nATOM   2171  CD1 LEU   277      54.434  32.070   2.892  1.00  0.00     0.009 C \nATOM   2172  CD2 LEU   277      55.994  33.045   1.225  1.00  0.00     0.009 C \nATOM   2173  H   LEU   277      51.922  33.940  -0.311  1.00  0.00     0.163 HD\nATOM   2174  N   GLU   278      53.900  31.515  -2.919  1.00  0.00    -0.346 N \nATOM   2175  CA  GLU   278      53.408  30.657  -3.991  1.00  0.00     0.177 C \nATOM   2176  C   GLU   278      52.920  29.330  -3.423  1.00  0.00     0.240 C \nATOM   2177  O   GLU   278      53.570  28.743  -2.584  1.00  0.00    -0.271 OA\nATOM   2178  CB  GLU   278      54.493  30.364  -5.029  1.00  0.00     0.045 C \nATOM   2179  CG  GLU   278      54.884  31.546  -5.895  1.00  0.00     0.116 C \nATOM   2180  CD  GLU   278      56.106  32.291  -5.398  1.00  0.00     0.172 C \nATOM   2181  OE1 GLU   278      56.755  31.833  -4.429  1.00  0.00    -0.648 OA\nATOM   2182  OE2 GLU   278      56.425  33.341  -5.991  1.00  0.00    -0.648 OA\nATOM   2183  H   GLU   278      54.873  31.864  -2.865  1.00  0.00     0.163 HD\nATOM   2184  N   GLY   279      51.776  28.881  -3.905  1.00  0.00    -0.351 N \nATOM   2185  CA  GLY   279      51.238  27.597  -3.527  1.00  0.00     0.225 C \nATOM   2186  C   GLY   279      50.755  27.516  -2.090  1.00  0.00     0.236 C \nATOM   2187  O   GLY   279      50.645  26.419  -1.557  1.00  0.00    -0.272 OA\nATOM   2188  H   GLY   279      51.303  29.529  -4.574  1.00  0.00     0.163 HD\nATOM   2189  N   ASN   280      50.441  28.653  -1.468  1.00  0.00    -0.346 N \nATOM   2190  CA  ASN   280      50.025  28.690  -0.077  1.00  0.00     0.185 C \nATOM   2191  C   ASN   280      48.545  28.329   0.098  1.00  0.00     0.241 C \nATOM   2192  O   ASN   280      47.701  29.134   0.514  1.00  0.00    -0.271 OA\nATOM   2193  CB  ASN   280      50.338  30.049   0.517  1.00  0.00     0.137 C \nATOM   2194  CG  ASN   280      50.291  30.041   2.034  1.00  0.00     0.217 C \nATOM   2195  H   ASN   280      50.521  29.505  -2.067  1.00  0.00     0.163 HD\nATOM   2196  OD1 ASN   280      50.340  28.986   2.656  1.00  0.00    -0.274 OA\nATOM   2197  ND2 ASN   280      50.208  31.212   2.632  1.00  0.00    -0.370 N \nATOM   2198 2HD2 ASN   280      50.179  31.274   3.631  1.00  0.00     0.159 HD\nATOM   2199 1HD2 ASN   280      50.173  32.056   2.087  1.00  0.00     0.159 HD\nATOM   2200  N   LEU   281      48.253  27.077  -0.217  1.00  0.00    -0.346 N \nATOM   2201  CA  LEU   281      46.922  26.508  -0.091  1.00  0.00     0.177 C \nATOM   2202  C   LEU   281      46.557  26.279   1.364  1.00  0.00     0.241 C \nATOM   2203  O   LEU   281      47.396  25.904   2.183  1.00  0.00    -0.271 OA\nATOM   2204  CB  LEU   281      46.860  25.180  -0.831  1.00  0.00     0.038 C \nATOM   2205  CG  LEU   281      46.948  25.287  -2.354  1.00  0.00    -0.020 C \nATOM   2206  CD1 LEU   281      47.295  23.940  -2.941  1.00  0.00     0.009 C \nATOM   2207  CD2 LEU   281      45.634  25.787  -2.931  1.00  0.00     0.009 C \nATOM   2208  H   LEU   281      49.076  26.523  -0.570  1.00  0.00     0.163 HD\nATOM   2209  N   ALA   282      45.292  26.530   1.675  1.00  0.00    -0.346 N \nATOM   2210  CA  ALA   282      44.723  26.126   2.941  1.00  0.00     0.172 C \nATOM   2211  C   ALA   282      44.790  24.620   3.094  1.00  0.00     0.240 C \nATOM   2212  O   ALA   282      44.795  23.870   2.119  1.00  0.00    -0.271 OA\nATOM   2213  CB  ALA   282      43.296  26.593   3.022  1.00  0.00     0.042 C \nATOM   2214  H   ALA   282      44.757  27.035   0.937  1.00  0.00     0.163 HD\nATOM   2215  N   GLU   283      44.789  24.160   4.337  1.00  0.00    -0.346 N \nATOM   2216  CA  GLU   283      44.709  22.726   4.588  1.00  0.00     0.177 C \nATOM   2217  C   GLU   283      43.454  22.121   3.961  1.00  0.00     0.240 C \nATOM   2218  O   GLU   283      43.499  21.039   3.369  1.00  0.00    -0.271 OA\nATOM   2219  CB  GLU   283      44.744  22.461   6.094  1.00  0.00     0.045 C \nATOM   2220  CG  GLU   283      44.480  21.017   6.455  1.00  0.00     0.116 C \nATOM   2221  CD  GLU   283      44.361  20.745   7.929  1.00  0.00     0.172 C \nATOM   2222  OE1 GLU   283      44.705  21.602   8.755  1.00  0.00    -0.648 OA\nATOM   2223  OE2 GLU   283      43.885  19.638   8.249  1.00  0.00    -0.648 OA\nATOM   2224  H   GLU   283      44.847  24.873   5.077  1.00  0.00     0.163 HD\nATOM   2225  N   GLY   284      42.330  22.809   4.168  1.00  0.00    -0.351 N \nATOM   2226  CA  GLY   284      41.047  22.356   3.684  1.00  0.00     0.225 C \nATOM   2227  C   GLY   284      39.944  23.098   4.382  1.00  0.00     0.236 C \nATOM   2228  O   GLY   284      40.120  24.239   4.774  1.00  0.00    -0.272 OA\nATOM   2229  H   GLY   284      42.466  23.694   4.706  1.00  0.00     0.163 HD\nATOM   2230  N   VAL   285      38.804  22.427   4.504  1.00  0.00    -0.346 N \nATOM   2231  CA  VAL   285      37.627  22.982   5.159  1.00  0.00     0.180 C \nATOM   2232  C   VAL   285      37.010  21.981   6.115  1.00  0.00     0.241 C \nATOM   2233  O   VAL   285      37.176  20.763   5.970  1.00  0.00    -0.271 OA\nATOM   2234  CB  VAL   285      36.548  23.462   4.151  1.00  0.00     0.009 C \nATOM   2235  CG1 VAL   285      37.097  24.614   3.321  1.00  0.00     0.012 C \nATOM   2236  CG2 VAL   285      36.023  22.333   3.287  1.00  0.00     0.012 C \nATOM   2237  H   VAL   285      38.825  21.466   4.089  1.00  0.00     0.163 HD\nATOM   2238  N   VAL   286      36.294  22.520   7.097  1.00  0.00    -0.346 N \nATOM   2239  CA  VAL   286      35.398  21.760   7.949  1.00  0.00     0.180 C \nATOM   2240  C   VAL   286      33.979  22.163   7.581  1.00  0.00     0.241 C \nATOM   2241  O   VAL   286      33.669  23.355   7.470  1.00  0.00    -0.271 OA\nATOM   2242  CB  VAL   286      35.682  22.050   9.432  1.00  0.00     0.009 C \nATOM   2243  CG1 VAL   286      34.632  21.442  10.340  1.00  0.00     0.012 C \nATOM   2244  CG2 VAL   286      37.072  21.519   9.801  1.00  0.00     0.012 C \nATOM   2245  H   VAL   286      36.436  23.559   7.203  1.00  0.00     0.163 HD\nATOM   2246  N   ILE   287      33.134  21.156   7.363  1.00  0.00    -0.346 N \nATOM   2247  CA  ILE   287      31.742  21.361   6.970  1.00  0.00     0.180 C \nATOM   2248  C   ILE   287      30.880  20.861   8.110  1.00  0.00     0.241 C \nATOM   2249  O   ILE   287      31.066  19.749   8.613  1.00  0.00    -0.271 OA\nATOM   2250  CB  ILE   287      31.454  20.612   5.658  1.00  0.00     0.013 C \nATOM   2251  CG1 ILE   287      32.210  21.311   4.513  1.00  0.00     0.002 C \nATOM   2252  CG2 ILE   287      29.966  20.532   5.390  1.00  0.00     0.012 C \nATOM   2253  CD1 ILE   287      32.283  20.504   3.229  1.00  0.00     0.005 C \nATOM   2254  H   ILE   287      33.553  20.207   7.497  1.00  0.00     0.163 HD\nATOM   2255  N   ARG   288      29.924  21.684   8.530  1.00  0.00    -0.346 N \nATOM   2256  CA  ARG   288      29.090  21.339   9.667  1.00  0.00     0.176 C \nATOM   2257  C   ARG   288      27.683  21.900   9.508  1.00  0.00     0.241 C \nATOM   2258  O   ARG   288      27.473  22.935   8.895  1.00  0.00    -0.271 OA\nATOM   2259  CB  ARG   288      29.703  21.830  10.978  1.00  0.00     0.036 C \nATOM   2260  CG  ARG   288      29.902  23.331  11.047  1.00  0.00     0.023 C \nATOM   2261  CD  ARG   288      30.782  23.711  12.205  1.00  0.00     0.138 C \nATOM   2262  NE  ARG   288      30.097  23.543  13.479  1.00  0.00    -0.227 N \nATOM   2263  CZ  ARG   288      30.712  23.360  14.638  1.00  0.00     0.665 C \nATOM   2264  NH1 ARG   288      32.034  23.243  14.700  1.00  0.00    -0.235 N \nATOM   2265  NH2 ARG   288      30.000  23.243  15.750  1.00  0.00    -0.235 N \nATOM   2266  HE  ARG   288      29.089  23.567  13.479  1.00  0.00     0.177 HD\nATOM   2267 2HH2 ARG   288      30.454  23.086  16.627  1.00  0.00     0.174 HD\nATOM   2268 1HH2 ARG   288      29.000  23.313  15.715  1.00  0.00     0.174 HD\nATOM   2269  H   ARG   288      29.833  22.562   7.991  1.00  0.00     0.163 HD\nATOM   2270 2HH1 ARG   288      32.481  23.086  15.586  1.00  0.00     0.174 HD\nATOM   2271 1HH1 ARG   288      32.584  23.312  13.870  1.00  0.00     0.174 HD\nATOM   2272  N   HIS   289      26.735  21.216  10.119  1.00  0.00    -0.346 N \nATOM   2273  CA  HIS   289      25.347  21.661  10.166  1.00  0.00     0.182 C \nATOM   2274  C   HIS   289      25.287  22.902  11.031  1.00  0.00     0.241 C \nATOM   2275  O   HIS   289      25.900  22.941  12.095  1.00  0.00    -0.271 OA\nATOM   2276  CB  HIS   289      24.492  20.531  10.767  1.00  0.00     0.095 C \nATOM   2277  CG  HIS   289      23.027  20.678  10.551  1.00  0.00     0.053 A \nATOM   2278  H   HIS   289      27.060  20.327  10.568  1.00  0.00     0.163 HD\nATOM   2279  CD2 HIS   289      22.119  19.816  10.043  1.00  0.00     0.116 A \nATOM   2280  HE2 HIS   289      20.047  20.077   9.706  1.00  0.00     0.166 HD\nATOM   2281  CE1 HIS   289      21.050  21.608  10.664  1.00  0.00     0.207 A \nATOM   2282  ND1 HIS   289      22.317  21.758  10.997  1.00  0.00    -0.247 NA\nATOM   2283  NE2 HIS   289      20.903  20.444  10.073  1.00  0.00    -0.359 N \nATOM   2284  N   VAL   290      24.521  23.905  10.630  1.00  0.00    -0.346 N \nATOM   2285  CA  VAL   290      24.488  25.142  11.390  1.00  0.00     0.180 C \nATOM   2286  C   VAL   290      23.858  25.000  12.770  1.00  0.00     0.241 C \nATOM   2287  O   VAL   290      24.050  25.878  13.606  1.00  0.00    -0.271 OA\nATOM   2288  CB  VAL   290      23.836  26.310  10.618  1.00  0.00     0.009 C \nATOM   2289  CG1 VAL   290      24.584  26.591   9.329  1.00  0.00     0.012 C \nATOM   2290  CG2 VAL   290      22.356  26.089  10.409  1.00  0.00     0.012 C \nATOM   2291  H   VAL   290      23.978  23.737   9.773  1.00  0.00     0.163 HD\nATOM   2292  N   ARG   291      23.121  23.919  13.011  1.00  0.00    -0.346 N \nATOM   2293  CA  ARG   291      22.558  23.636  14.325  1.00  0.00     0.176 C \nATOM   2294  C   ARG   291      23.140  22.375  14.932  1.00  0.00     0.241 C \nATOM   2295  O   ARG   291      22.545  21.780  15.815  1.00  0.00    -0.271 OA\nATOM   2296  CB  ARG   291      21.029  23.594  14.277  1.00  0.00     0.036 C \nATOM   2297  CG  ARG   291      20.465  24.959  13.915  1.00  0.00     0.023 C \nATOM   2298  CD  ARG   291      20.653  26.061  14.968  1.00  0.00     0.138 C \nATOM   2299  NE  ARG   291      19.893  25.853  16.209  1.00  0.00    -0.227 N \nATOM   2300  CZ  ARG   291      19.894  26.689  17.259  1.00  0.00     0.665 C \nATOM   2301  NH1 ARG   291      20.636  27.794  17.257  1.00  0.00    -0.235 N \nATOM   2302  NH2 ARG   291      19.166  26.403  18.335  1.00  0.00    -0.235 N \nATOM   2303  HE  ARG   291      19.329  25.021  16.278  1.00  0.00     0.177 HD\nATOM   2304 2HH2 ARG   291      19.179  27.010  19.121  1.00  0.00     0.174 HD\nATOM   2305 1HH2 ARG   291      18.604  25.574  18.350  1.00  0.00     0.174 HD\nATOM   2306  H   ARG   291      22.983  23.298  12.184  1.00  0.00     0.163 HD\nATOM   2307 2HH1 ARG   291      20.634  28.391  18.058  1.00  0.00     0.174 HD\nATOM   2308 1HH1 ARG   291      21.189  28.023  16.459  1.00  0.00     0.174 HD\nATOM   2309  N   ARG   292      24.344  22.007  14.512  1.00  0.00    -0.346 N \nATOM   2310  CA  ARG   292      25.083  20.949  15.190  1.00  0.00     0.176 C \nATOM   2311  C   ARG   292      25.039  21.172  16.702  1.00  0.00     0.240 C \nATOM   2312  O   ARG   292      25.284  22.279  17.190  1.00  0.00    -0.271 OA\nATOM   2313  CB  ARG   292      26.533  20.932  14.719  1.00  0.00     0.036 C \nATOM   2314  CG  ARG   292      27.425  20.000  15.474  1.00  0.00     0.023 C \nATOM   2315  CD  ARG   292      28.706  19.723  14.710  1.00  0.00     0.138 C \nATOM   2316  NE  ARG   292      29.514  18.683  15.360  1.00  0.00    -0.227 N \nATOM   2317  CZ  ARG   292      30.316  18.903  16.352  1.00  0.00     0.665 C \nATOM   2318  NH1 ARG   292      30.499  20.135  16.795  1.00  0.00    -0.235 N \nATOM   2319  NH2 ARG   292      30.976  17.893  16.905  1.00  0.00    -0.235 N \nATOM   2320  HE  ARG   292      29.426  17.745  14.998  1.00  0.00     0.177 HD\nATOM   2321 2HH2 ARG   292      31.616  18.050  17.664  1.00  0.00     0.174 HD\nATOM   2322 1HH2 ARG   292      30.837  16.958  16.566  1.00  0.00     0.174 HD\nATOM   2323  H   ARG   292      24.700  22.520  13.688  1.00  0.00     0.163 HD\nATOM   2324 2HH1 ARG   292      31.146  20.308  17.565  1.00  0.00     0.174 HD\nATOM   2325 1HH1 ARG   292      30.011  20.902  16.387  1.00  0.00     0.174 HD\nATOM   2326  N   GLY   293      24.719  20.120  17.436  1.00  0.00    -0.351 N \nATOM   2327  CA  GLY   293      24.597  20.200  18.880  1.00  0.00     0.225 C \nATOM   2328  C   GLY   293      23.178  20.390  19.386  1.00  0.00     0.236 C \nATOM   2329  O   GLY   293      22.904  20.105  20.557  1.00  0.00    -0.272 OA\nATOM   2330  H   GLY   293      24.564  19.242  16.896  1.00  0.00     0.163 HD\nATOM   2331  N   ASP   294      22.271  20.868  18.544  1.00  0.00    -0.346 N \nATOM   2332  CA  ASP   294      20.880  21.052  18.953  1.00  0.00     0.186 C \nATOM   2333  C   ASP   294      20.230  19.687  19.098  1.00  0.00     0.243 C \nATOM   2334  O   ASP   294      20.431  18.826  18.249  1.00  0.00    -0.271 OA\nATOM   2335  CB  ASP   294      20.135  21.853  17.899  1.00  0.00     0.147 C \nATOM   2336  CG  ASP   294      18.711  22.155  18.305  1.00  0.00     0.175 C \nATOM   2337  OD1 ASP   294      18.454  23.275  18.779  1.00  0.00    -0.648 OA\nATOM   2338  OD2 ASP   294      17.794  21.334  18.205  1.00  0.00    -0.648 OA\nATOM   2339  H   ASP   294      22.624  21.094  17.597  1.00  0.00     0.163 HD\nATOM   2340  N   PRO   295      19.465  19.452  20.170  1.00  0.00    -0.337 N \nATOM   2341  CA  PRO   295      18.816  18.148  20.347  1.00  0.00     0.179 C \nATOM   2342  C   PRO   295      18.017  17.647  19.148  1.00  0.00     0.241 C \nATOM   2343  O   PRO   295      18.015  16.451  18.918  1.00  0.00    -0.271 OA\nATOM   2344  CB  PRO   295      17.896  18.370  21.551  1.00  0.00     0.037 C \nATOM   2345  CG  PRO   295      18.516  19.459  22.304  1.00  0.00     0.022 C \nATOM   2346  CD  PRO   295      19.209  20.343  21.320  1.00  0.00     0.127 C \nATOM   2347  N   ALA   296      17.338  18.515  18.414  1.00  0.00    -0.346 N \nATOM   2348  CA  ALA   296      16.563  18.083  17.260  1.00  0.00     0.172 C \nATOM   2349  C   ALA   296      17.464  17.609  16.115  1.00  0.00     0.240 C \nATOM   2350  O   ALA   296      17.038  16.817  15.286  1.00  0.00    -0.271 OA\nATOM   2351  CB  ALA   296      15.620  19.183  16.774  1.00  0.00     0.042 C \nATOM   2352  H   ALA   296      17.405  19.502  18.724  1.00  0.00     0.163 HD\nATOM   2353  N   VAL   297      18.696  18.101  16.050  1.00  0.00    -0.346 N \nATOM   2354  CA  VAL   297      19.686  17.573  15.102  1.00  0.00     0.180 C \nATOM   2355  C   VAL   297      20.300  16.291  15.638  1.00  0.00     0.241 C \nATOM   2356  O   VAL   297      20.427  15.294  14.932  1.00  0.00    -0.271 OA\nATOM   2357  CB  VAL   297      20.802  18.600  14.840  1.00  0.00     0.009 C \nATOM   2358  CG1 VAL   297      22.001  17.964  14.107  1.00  0.00     0.012 C \nATOM   2359  CG2 VAL   297      20.248  19.746  14.046  1.00  0.00     0.012 C \nATOM   2360  H   VAL   297      18.898  18.873  16.710  1.00  0.00     0.163 HD\nATOM   2361  N   GLU   298      20.707  16.327  16.889  1.00  0.00    -0.346 N \nATOM   2362  CA  GLU   298      21.426  15.211  17.495  1.00  0.00     0.177 C \nATOM   2363  C   GLU   298      20.585  13.956  17.631  1.00  0.00     0.241 C \nATOM   2364  O   GLU   298      21.129  12.866  17.694  1.00  0.00    -0.271 OA\nATOM   2365  CB  GLU   298      21.936  15.613  18.882  1.00  0.00     0.045 C \nATOM   2366  CG  GLU   298      22.959  16.729  18.859  1.00  0.00     0.116 C \nATOM   2367  CD  GLU   298      24.120  16.391  17.957  1.00  0.00     0.172 C \nATOM   2368  OE1 GLU   298      24.715  15.318  18.185  1.00  0.00    -0.648 OA\nATOM   2369  OE2 GLU   298      24.419  17.155  16.998  1.00  0.00    -0.648 OA\nATOM   2370  H   GLU   298      20.479  17.202  17.404  1.00  0.00     0.163 HD\nATOM   2371  N   LYS   299      19.264  14.103  17.649  1.00  0.00    -0.346 N \nATOM   2372  CA  LYS   299      18.387  12.960  17.831  1.00  0.00     0.176 C \nATOM   2373  C   LYS   299      18.562  11.933  16.722  1.00  0.00     0.241 C \nATOM   2374  O   LYS   299      18.241  10.778  16.910  1.00  0.00    -0.271 OA\nATOM   2375  CB  LYS   299      16.916  13.406  17.924  1.00  0.00     0.035 C \nATOM   2376  CG  LYS   299      16.315  13.879  16.622  1.00  0.00     0.004 C \nATOM   2377  CD  LYS   299      14.823  14.207  16.734  1.00  0.00     0.027 C \nATOM   2378  CE  LYS   299      14.305  14.851  15.448  1.00  0.00     0.229 C \nATOM   2379  NZ  LYS   299      12.830  15.127  15.487  1.00  0.00    -0.079 N \nATOM   2380  HZ1 LYS   299      12.549  15.258  16.435  1.00  0.00     0.274 HD\nATOM   2381  HZ3 LYS   299      12.639  15.952  14.959  1.00  0.00     0.274 HD\nATOM   2382  HZ2 LYS   299      12.343  14.351  15.092  1.00  0.00     0.274 HD\nATOM   2383  H   LYS   299      18.929  15.074  17.526  1.00  0.00     0.163 HD\nATOM   2384  N   HIS   300      19.021  12.354  15.549  1.00  0.00    -0.346 N \nATOM   2385  CA  HIS   300      19.188  11.434  14.433  1.00  0.00     0.182 C \nATOM   2386  C   HIS   300      20.392  10.511  14.561  1.00  0.00     0.241 C \nATOM   2387  O   HIS   300      20.546   9.589  13.774  1.00  0.00    -0.271 OA\nATOM   2388  CB  HIS   300      19.297  12.219  13.143  1.00  0.00     0.093 C \nATOM   2389  CG  HIS   300      18.084  13.033  12.848  1.00  0.00     0.030 A \nATOM   2390  ND1 HIS   300      17.933  14.330  13.284  1.00  0.00    -0.353 N \nATOM   2391  CD2 HIS   300      16.985  12.752  12.109  1.00  0.00     0.143 A \nATOM   2392  CE1 HIS   300      16.767  14.791  12.876  1.00  0.00     0.207 A \nATOM   2393  NE2 HIS   300      16.175  13.857  12.156  1.00  0.00    -0.254 NA\nATOM   2394  HD1 HIS   300      18.603  14.839  13.824  1.00  0.00     0.166 HD\nATOM   2395  H   HIS   300      19.243  13.364  15.501  1.00  0.00     0.163 HD\nATOM   2396  N   ASN   301      21.261  10.773  15.525  1.00  0.00    -0.346 N \nATOM   2397  CA  ASN   301      22.418   9.916  15.780  1.00  0.00     0.185 C \nATOM   2398  C   ASN   301      23.349   9.811  14.570  1.00  0.00     0.241 C \nATOM   2399  O   ASN   301      23.896   8.747  14.298  1.00  0.00    -0.271 OA\nATOM   2400  CB  ASN   301      21.966   8.525  16.227  1.00  0.00     0.137 C \nATOM   2401  CG  ASN   301      23.099   7.680  16.756  1.00  0.00     0.217 C \nATOM   2402  H   ASN   301      21.055  11.629  16.080  1.00  0.00     0.163 HD\nATOM   2403  OD1 ASN   301      23.968   8.160  17.495  1.00  0.00    -0.274 OA\nATOM   2404  ND2 ASN   301      23.075   6.396  16.413  1.00  0.00    -0.370 N \nATOM   2405 2HD2 ASN   301      23.797   5.776  16.736  1.00  0.00     0.159 HD\nATOM   2406 1HD2 ASN   301      22.341   6.045  15.834  1.00  0.00     0.159 HD\nATOM   2407  N   VAL   302      23.537  10.932  13.878  1.00  0.00    -0.346 N \nATOM   2408  CA  VAL   302      24.481  11.024  12.775  1.00  0.00     0.180 C \nATOM   2409  C   VAL   302      25.357  12.247  12.994  1.00  0.00     0.241 C \nATOM   2410  O   VAL   302      24.862  13.374  13.199  1.00  0.00    -0.271 OA\nATOM   2411  CB  VAL   302      23.778  11.098  11.420  1.00  0.00     0.009 C \nATOM   2412  CG1 VAL   302      22.907  12.263  11.285  1.00  0.00     0.012 C \nATOM   2413  CG2 VAL   302      24.795  11.046  10.295  1.00  0.00     0.012 C \nATOM   2414  H   VAL   302      22.949  11.736  14.196  1.00  0.00     0.163 HD\nATOM   2415  N   SER   303      26.668  12.049  12.975  1.00  0.00    -0.344 N \nATOM   2416  CA  SER   303      27.566  13.173  13.179  1.00  0.00     0.200 C \nATOM   2417  C   SER   303      27.408  14.210  12.060  1.00  0.00     0.243 C \nATOM   2418  O   SER   303      27.357  13.875  10.881  1.00  0.00    -0.271 OA\nATOM   2419  CB  SER   303      29.006  12.687  13.260  1.00  0.00     0.199 C \nATOM   2420  OG  SER   303      29.881  13.779  13.215  1.00  0.00    -0.398 OA\nATOM   2421  H   SER   303      26.973  11.084  12.812  1.00  0.00     0.163 HD\nATOM   2422  HG  SER   303      30.794  13.474  12.939  1.00  0.00     0.209 HD\nATOM   2423  N   THR   304      27.349  15.471  12.457  1.00  0.00    -0.344 N \nATOM   2424  CA  THR   304      27.143  16.556  11.494  1.00  0.00     0.205 C \nATOM   2425  C   THR   304      28.367  17.437  11.337  1.00  0.00     0.243 C \nATOM   2426  O   THR   304      28.245  18.641  11.132  1.00  0.00    -0.271 OA\nATOM   2427  CB  THR   304      25.940  17.380  11.818  1.00  0.00     0.146 C \nATOM   2428  OG1 THR   304      26.086  17.865  13.140  1.00  0.00    -0.393 OA\nATOM   2429  CG2 THR   304      24.658  16.565  11.778  1.00  0.00     0.042 C \nATOM   2430  H   THR   304      27.457  15.624  13.473  1.00  0.00     0.163 HD\nATOM   2431  HG1 THR   304      25.467  18.644  13.306  1.00  0.00     0.210 HD\nATOM   2432  N   ILE   305      29.539  16.822  11.373  1.00  0.00    -0.346 N \nATOM   2433  CA  ILE   305      30.775  17.524  11.063  1.00  0.00     0.180 C \nATOM   2434  C   ILE   305      31.656  16.609  10.238  1.00  0.00     0.241 C \nATOM   2435  O   ILE   305      31.798  15.420  10.545  1.00  0.00    -0.271 OA\nATOM   2436  CB  ILE   305      31.451  18.050  12.354  1.00  0.00     0.013 C \nATOM   2437  CG1 ILE   305      32.569  19.040  12.052  1.00  0.00     0.002 C \nATOM   2438  CG2 ILE   305      31.916  16.920  13.274  1.00  0.00     0.012 C \nATOM   2439  CD1 ILE   305      32.917  19.887  13.254  1.00  0.00     0.005 C \nATOM   2440  H   ILE   305      29.500  15.818  11.636  1.00  0.00     0.163 HD\nATOM   2441  N   ILE   306      32.219  17.161   9.169  1.00  0.00    -0.346 N \nATOM   2442  CA  ILE   306      33.111  16.423   8.276  1.00  0.00     0.180 C \nATOM   2443  C   ILE   306      34.209  17.376   7.816  1.00  0.00     0.241 C \nATOM   2444  O   ILE   306      34.140  18.584   8.040  1.00  0.00    -0.271 OA\nATOM   2445  CB  ILE   306      32.398  15.812   7.056  1.00  0.00     0.013 C \nATOM   2446  CG1 ILE   306      31.693  16.886   6.281  1.00  0.00     0.002 C \nATOM   2447  CG2 ILE   306      31.446  14.687   7.431  1.00  0.00     0.012 C \nATOM   2448  CD1 ILE   306      31.159  16.426   4.941  1.00  0.00     0.005 C \nATOM   2449  H   ILE   306      31.971  18.165   9.020  1.00  0.00     0.163 HD\nATOM   2450  N   LYS   307      35.231  16.835   7.169  1.00  0.00    -0.346 N \nATOM   2451  CA  LYS   307      36.295  17.661   6.612  1.00  0.00     0.176 C \nATOM   2452  C   LYS   307      36.569  17.255   5.173  1.00  0.00     0.241 C \nATOM   2453  O   LYS   307      36.283  16.131   4.755  1.00  0.00    -0.271 OA\nATOM   2454  CB  LYS   307      37.584  17.519   7.428  1.00  0.00     0.035 C \nATOM   2455  CG  LYS   307      38.237  16.162   7.232  1.00  0.00     0.004 C \nATOM   2456  CD  LYS   307      39.383  15.905   8.181  1.00  0.00     0.027 C \nATOM   2457  CE  LYS   307      39.971  14.529   7.957  1.00  0.00     0.229 C \nATOM   2458  NZ  LYS   307      40.613  14.028   9.188  1.00  0.00    -0.079 N \nATOM   2459  HZ1 LYS   307      40.700  13.031   9.142  1.00  0.00     0.274 HD\nATOM   2460  HZ3 LYS   307      41.523  14.435   9.284  1.00  0.00     0.274 HD\nATOM   2461  HZ2 LYS   307      40.056  14.274   9.983  1.00  0.00     0.274 HD\nATOM   2462  H   LYS   307      35.209  15.802   7.095  1.00  0.00     0.163 HD\nATOM   2463  N   LEU   308      37.139  18.196   4.427  1.00  0.00    -0.346 N \nATOM   2464  CA  LEU   308      37.752  17.954   3.130  1.00  0.00     0.177 C \nATOM   2465  C   LEU   308      39.129  18.587   3.165  1.00  0.00     0.241 C \nATOM   2466  O   LEU   308      39.283  19.699   3.664  1.00  0.00    -0.271 OA\nATOM   2467  CB  LEU   308      36.969  18.622   2.011  1.00  0.00     0.038 C \nATOM   2468  CG  LEU   308      35.516  18.234   1.803  1.00  0.00    -0.020 C \nATOM   2469  CD1 LEU   308      34.886  19.114   0.754  1.00  0.00     0.009 C \nATOM   2470  CD2 LEU   308      35.368  16.778   1.413  1.00  0.00     0.009 C \nATOM   2471  H   LEU   308      37.108  19.157   4.867  1.00  0.00     0.163 HD\nATOM   2472  N   ARG   309      40.132  17.898   2.636  1.00  0.00    -0.346 N \nATOM   2473  CA  ARG   309      41.481  18.443   2.547  1.00  0.00     0.176 C \nATOM   2474  C   ARG   309      41.906  18.560   1.114  1.00  0.00     0.241 C \nATOM   2475  O   ARG   309      41.480  17.790   0.243  1.00  0.00    -0.271 OA\nATOM   2476  CB  ARG   309      42.493  17.607   3.309  1.00  0.00     0.036 C \nATOM   2477  CG  ARG   309      42.378  17.774   4.797  1.00  0.00     0.023 C \nATOM   2478  CD  ARG   309      43.117  16.728   5.552  1.00  0.00     0.138 C \nATOM   2479  NE  ARG   309      43.581  17.189   6.854  1.00  0.00    -0.227 N \nATOM   2480  CZ  ARG   309      43.845  16.373   7.856  1.00  0.00     0.665 C \nATOM   2481  NH1 ARG   309      43.625  15.061   7.751  1.00  0.00    -0.235 N \nATOM   2482  NH2 ARG   309      44.341  16.863   8.970  1.00  0.00    -0.235 N \nATOM   2483  HE  ARG   309      43.704  18.173   6.991  1.00  0.00     0.177 HD\nATOM   2484 2HH2 ARG   309      44.532  16.257   9.754  1.00  0.00     0.174 HD\nATOM   2485 1HH2 ARG   309      44.537  17.844   9.054  1.00  0.00     0.174 HD\nATOM   2486  H   ARG   309      39.876  16.948   2.295  1.00  0.00     0.163 HD\nATOM   2487 2HH1 ARG   309      43.815  14.460   8.531  1.00  0.00     0.174 HD\nATOM   2488 1HH1 ARG   309      43.274  14.681   6.898  1.00  0.00     0.174 HD\nATOM   2489  N   CYS   310      42.770  19.524   0.828  1.00  0.00    -0.345 N \nATOM   2490  CA  CYS   310      43.314  19.567  -0.523  1.00  0.00     0.185 C \nATOM   2491  C   CYS   310      44.339  18.455  -0.711  1.00  0.00     0.242 C \nATOM   2492  O   CYS   310      45.044  18.057   0.208  1.00  0.00    -0.271 OA\nATOM   2493  CB  CYS   310      43.857  20.929  -0.918  1.00  0.00     0.105 C \nATOM   2494  SG  CYS   310      45.369  21.434  -0.112  1.00  0.00    -0.180 SA\nATOM   2495  H   CYS   310      42.997  20.172   1.571  1.00  0.00     0.163 HD\nATOM   2496  HG  CYS   310      45.179  22.167   0.547  1.00  0.00     0.101 HD\nATOM   2497  N   SER   311      44.400  17.953  -1.933  1.00  0.00    -0.344 N \nATOM   2498  CA  SER   311      45.300  16.868  -2.266  1.00  0.00     0.200 C \nATOM   2499  C   SER   311      46.750  17.269  -2.058  1.00  0.00     0.243 C \nATOM   2500  O   SER   311      47.546  16.462  -1.609  1.00  0.00    -0.271 OA\nATOM   2501  CB  SER   311      45.065  16.404  -3.709  1.00  0.00     0.199 C \nATOM   2502  OG  SER   311      45.466  17.394  -4.643  1.00  0.00    -0.398 OA\nATOM   2503  H   SER   311      43.757  18.398  -2.620  1.00  0.00     0.163 HD\nATOM   2504  HG  SER   311      44.694  17.996  -4.841  1.00  0.00     0.209 HD\nATOM   2505  N   SER   312      47.073  18.521  -2.352  1.00  0.00    -0.344 N \nATOM   2506  CA  SER   312      48.435  19.024  -2.196  1.00  0.00     0.200 C \nATOM   2507  C   SER   312      48.900  18.887  -0.744  1.00  0.00     0.243 C \nATOM   2508  O   SER   312      50.044  18.513  -0.483  1.00  0.00    -0.271 OA\nATOM   2509  CB  SER   312      48.512  20.482  -2.665  1.00  0.00     0.199 C \nATOM   2510  OG  SER   312      48.261  20.581  -4.059  1.00  0.00    -0.398 OA\nATOM   2511  H   SER   312      46.285  19.106  -2.698  1.00  0.00     0.163 HD\nATOM   2512  HG  SER   312      47.611  19.873  -4.330  1.00  0.00     0.209 HD\nATOM   2513  N   PHE   313      48.006  19.197   0.198  1.00  0.00    -0.347 N \nATOM   2514  CA  PHE   313      48.311  19.067   1.617  1.00  0.00     0.166 C \nATOM   2515  C   PHE   313      48.464  17.610   2.025  1.00  0.00     0.219 C \nATOM   2516  O   PHE   313      49.384  17.264   2.757  1.00  0.00    -0.287 OA\nATOM   2517  CB  PHE   313      47.228  19.736   2.465  1.00  0.00     0.072 C \nATOM   2518  CG  PHE   313      47.461  19.608   3.946  1.00  0.00    -0.056 A \nATOM   2519  CD1 PHE   313      48.280  20.508   4.614  1.00  0.00     0.007 A \nATOM   2520  CD2 PHE   313      46.865  18.594   4.661  1.00  0.00     0.007 A \nATOM   2521  CE1 PHE   313      48.513  20.373   5.976  1.00  0.00     0.001 A \nATOM   2522  CE2 PHE   313      47.089  18.456   6.020  1.00  0.00     0.001 A \nATOM   2523  CZ  PHE   313      47.902  19.359   6.681  1.00  0.00     0.000 A \nATOM   2524  H   PHE   313      47.093  19.532  -0.166  1.00  0.00     0.163 HD\nATOM   2525  N   GLU   315      49.404  15.167   0.301  1.00  0.00    -0.326 NA\nATOM   2526  CA  GLU   315      50.629  14.623  -0.282  1.00  0.00     0.191 C \nATOM   2527  C   GLU   315      51.880  14.980   0.523  1.00  0.00     0.242 C \nATOM   2528  O   GLU   315      52.905  14.318   0.386  1.00  0.00    -0.271 OA\nATOM   2529  CB  GLU   315      50.796  15.124  -1.715  1.00  0.00     0.047 C \nATOM   2530  CG  GLU   315      49.827  14.509  -2.714  1.00  0.00     0.116 C \nATOM   2531  CD  GLU   315      49.696  15.322  -3.992  1.00  0.00     0.172 C \nATOM   2532  OE1 GLU   315      50.562  16.189  -4.251  1.00  0.00    -0.648 OA\nATOM   2533  OE2 GLU   315      48.725  15.094  -4.744  1.00  0.00    -0.648 OA\nATOM   2534  H   GLU   315      49.404  15.721   1.151  1.00  0.00     0.180 HD\nATOM   2535  N   LEU   316      51.812  16.028   1.343  1.00  0.00    -0.345 N \nATOM   2536  CA  LEU   316      52.936  16.402   2.205  1.00  0.00     0.185 C \nATOM   2537  C   LEU   316      53.189  15.335   3.270  1.00  0.00     0.196 C \nATOM   2538  O   LEU   316      52.284  14.591   3.657  1.00  0.00    -0.646 OA\nATOM   2539  CB  LEU   316      52.680  17.749   2.881  1.00  0.00     0.040 C \nATOM   2540  CG  LEU   316      52.494  18.953   1.961  1.00  0.00    -0.020 C \nATOM   2541  CD1 LEU   316      52.050  20.171   2.774  1.00  0.00     0.009 C \nATOM   2542  CD2 LEU   316      53.762  19.249   1.167  1.00  0.00     0.009 C \nATOM   2543  OXT LEU   316      54.229  15.053   3.872  1.00  0.00    -0.646 OA\nATOM   2544  H   LEU   316      50.914  16.545   1.319  1.00  0.00     0.163 HD\nTER    2545      LEU   316 \n";
;// CONCATENATED MODULE: ./src/example/ATP.pdbqt
const ATP_pdbqt_namespaceObject = "REMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      41.034  18.978  14.030  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.042  20.083  13.138  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      40.382  19.568  15.268  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      40.973  20.967  15.342  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      41.343  21.265  13.892  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      40.602  22.354  13.240  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      39.267  22.569  13.244  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      38.297  21.903  13.909  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      39.058  23.679  12.418  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      37.057  22.401  13.740  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.760  23.458  12.935  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.744  24.121  12.264  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      40.249  24.145  11.942  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      41.171  23.310  12.442  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.382  25.103  11.430  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      38.118  25.599  10.928  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      36.421  25.426  11.317  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      42.117  20.993  16.172  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      42.486  21.867  16.218  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      40.575  18.803  16.426  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      40.206  17.929  16.380  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      40.228  17.831  13.474  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      40.761  17.421  12.230  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      41.441  16.004  12.024  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      40.573  14.911  12.597  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      41.868  15.977  10.607  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      42.720  16.073  13.004  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      44.166  16.669  12.640  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      44.846  15.767  11.696  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      44.015  18.092  12.214  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      44.807  16.562  14.092  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      46.034  17.442  14.649  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      47.012  16.440  15.214  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      45.415  18.289  15.759  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      46.554  18.251  13.486  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\n";
;// CONCATENATED MODULE: ./src/example/webina_out.pdbqt
const webina_out_pdbqt_namespaceObject = "MODEL 1\nREMARK VINA RESULT:      -9.8      0.000      0.000\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      40.964  18.800  14.022  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      40.959  19.904  13.128  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      40.336  19.394  15.271  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      40.932  20.791  15.332  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      41.276  21.086  13.875  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      40.526  22.176  13.234  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      39.191  22.387  13.251  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      38.229  21.715  13.922  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.971  23.500  12.432  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.986  22.210  13.766  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.678  23.270  12.969  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.655  23.939  12.292  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      40.157  23.972  11.948  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      41.085  23.137  12.436  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.282  24.924  11.466  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      36.337  25.295  11.561  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      37.865  25.278  10.707  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      42.091  20.816  16.141  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      41.969  21.378  16.896  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      40.548  18.630  16.427  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      40.998  19.095  17.122  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      40.145  17.654  13.483  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      40.631  17.265  12.213  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      41.500  15.956  12.002  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      40.742  14.737  12.465  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      42.023  16.052  10.621  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      42.689  16.137  13.077  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      44.130  16.789  12.800  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      45.008  15.791  12.168  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      43.950  18.080  12.070  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      44.543  17.032  14.317  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      45.482  18.222  14.860  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      45.983  17.745  16.202  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      44.531  19.407  15.019  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      46.555  18.439  13.822  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 2\nREMARK VINA RESULT:      -9.1      1.397      3.376\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.126  19.779  14.703  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.519  21.058  14.593  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.334  18.959  13.699  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      39.910  19.460  13.885  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      40.107  20.871  14.431  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      39.654  21.974  13.571  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      38.392  22.427  13.397  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      37.255  22.050  14.023  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.478  23.428  12.423  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.157  22.736  13.655  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.145  23.705  12.698  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.295  24.075  12.067  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      39.775  23.597  12.032  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      40.467  22.687  12.732  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.208  24.979  11.084  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      36.775  25.877  11.297  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      37.488  24.797  10.120  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      39.203  18.655  14.806  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      38.722  17.967  14.360  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      41.479  17.575  13.862  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      40.749  17.157  14.303  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.589  19.834  14.339  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      43.832  19.053  13.186  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      45.263  18.961  12.510  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      45.142  18.997  11.006  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      46.101  19.943  13.233  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      45.726  17.455  12.852  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      44.769  16.241  13.286  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      45.494  14.967  13.140  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      44.191  16.531  14.631  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      43.682  16.412  12.137  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      42.553  15.336  11.739  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      43.210  14.435  10.721  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      41.447  16.172  11.098  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      42.133  14.651  13.017  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 3\nREMARK VINA RESULT:      -8.8      1.486      2.620\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.207  19.596  14.363  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.707  20.924  14.292  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.193  18.826  13.534  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      39.869  19.467  13.917  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      40.276  20.868  14.362  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      39.793  21.982  13.535  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      38.520  22.416  13.387  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      37.399  22.003  14.018  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.576  23.442  12.437  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.283  22.677  13.679  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.242  23.668  12.746  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.377  24.076  12.111  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      39.864  23.644  12.035  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      40.582  22.731  12.704  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.261  25.001  11.151  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      36.326  25.339  10.925  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      38.043  25.337  10.590  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      39.248  18.761  14.973  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      39.890  18.292  15.494  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      41.238  17.440  13.734  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      40.901  17.158  14.576  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.591  19.499  13.773  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      44.139  18.221  14.028  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      44.668  17.278  12.869  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      43.879  15.992  12.831  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      44.771  18.146  11.675  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      46.132  16.850  13.392  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      47.171  17.786  14.181  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      48.514  17.187  14.123  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      47.042  19.188  13.682  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      46.537  17.625  15.631  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      46.681  18.672  16.845  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      48.077  19.233  16.718  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      46.549  17.811  18.100  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      45.572  19.683  16.683  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 4\nREMARK VINA RESULT:      -8.5      1.706      2.810\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.516  18.152  13.942  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      42.535  19.526  13.584  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.045  17.913  14.230  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      40.617  19.185  14.945  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      41.614  20.222  14.435  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      41.061  21.311  13.617  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      39.785  21.758  13.582  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      38.728  21.385  14.338  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      39.755  22.746  12.592  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      37.592  22.063  14.088  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      37.467  23.019  13.126  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      38.536  23.385  12.365  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      40.998  22.915  12.055  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      41.770  22.017  12.683  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      38.333  24.275  11.386  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      37.632  24.056  10.679  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      38.883  25.127  11.271  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      40.714  19.037  16.347  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      39.862  18.873  16.733  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      40.794  16.739  14.952  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      39.873  16.525  15.038  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.006  17.285  12.809  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      43.971  17.981  12.046  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      45.527  17.732  12.214  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      45.901  16.359  11.711  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      46.179  18.947  11.676  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      45.707  17.649  13.815  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      46.791  18.445  14.692  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      48.116  18.326  14.063  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      46.293  19.830  14.945  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      46.699  17.547  16.002  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      47.077  18.014  17.495  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      47.113  16.742  18.308  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      45.908  18.902  17.918  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      48.393  18.746  17.403  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 5\nREMARK VINA RESULT:      -8.2      1.782      3.517\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.316  19.630  14.652  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.700  20.908  14.589  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.545  18.848  13.604  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      40.114  19.330  13.790  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      40.291  20.718  14.399  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      39.842  21.852  13.580  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      38.581  22.313  13.421  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      37.442  21.915  14.031  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.670  23.350  12.486  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.345  22.616  13.687  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.337  23.620  12.768  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.488  24.013  12.153  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      39.967  23.532  12.104  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      40.658  22.596  12.770  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.404  24.953  11.205  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      36.963  25.839  11.448  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      37.695  24.811  10.237  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      39.401  18.480  14.665  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      39.794  17.616  14.698  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      41.699  17.460  13.708  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      42.008  17.166  14.557  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.783  19.712  14.313  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      43.972  19.516  12.925  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      45.399  19.232  12.295  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      45.283  18.980  10.812  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      46.279  20.299  12.823  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      45.793  17.802  12.928  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      45.154  16.381  12.539  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      45.311  15.447  13.666  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      43.765  16.592  12.034  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      46.155  16.020  11.356  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      46.264  14.596  10.615  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      44.844  14.094  10.516  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      47.084  13.735  11.574  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      46.944  14.845   9.290  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 6\nREMARK VINA RESULT:      -8.2      5.798      8.104\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      44.550  18.442  13.114  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      45.306  18.365  14.314  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      45.623  18.702  12.072  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      46.568  19.664  12.775  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      46.343  19.354  14.252  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      47.485  18.780  14.979  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      47.605  18.579  16.311  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      46.691  18.765  17.289  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      48.901  18.089  16.506  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      47.109  18.421  18.522  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      48.359  17.963  18.806  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      49.277  17.782  17.814  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      49.547  17.972  15.310  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      48.670  18.416  14.399  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      50.511  17.403  18.164  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      50.854  17.681  19.083  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      51.151  16.908  17.542  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      46.236  21.007  12.484  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      46.093  21.130  11.553  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      45.123  19.180  10.854  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      45.751  19.676  10.343  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.819  17.150  12.844  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      42.474  17.416  12.498  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      41.336  17.585  13.588  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      39.995  17.189  13.020  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      41.866  16.944  14.812  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      41.250  19.185  13.773  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      40.484  19.967  14.948  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      39.040  19.699  14.857  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      41.141  19.654  16.252  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      40.821  21.446  14.469  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      40.928  21.941  12.941  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      42.199  21.319  12.415  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      41.065  23.458  13.047  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      39.666  21.491  12.247  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 7\nREMARK VINA RESULT:      -7.8      2.046      3.969\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.147  19.856  14.538  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.545  21.138  14.444  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.289  19.027  13.599  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      39.884  19.544  13.861  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      40.124  20.961  14.371  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      39.629  22.053  13.521  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      38.354  22.481  13.376  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      37.240  22.081  14.030  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.397  23.482  12.400  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.120  22.745  13.687  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.065  23.712  12.730  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.193  24.105  12.072  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      39.680  23.677  11.979  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      40.408  22.782  12.663  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.064  25.006  11.091  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      37.552  25.895  11.191  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      36.455  24.880  10.282  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      39.227  18.759  14.837  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      39.298  19.155  15.697  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      41.434  17.644  13.775  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      41.900  17.210  13.071  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.586  19.892  14.086  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      44.268  18.741  14.545  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      45.812  18.756  14.902  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      46.611  18.054  13.832  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      46.112  20.154  15.286  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      45.894  17.782  16.185  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      46.935  17.898  17.402  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      48.279  18.186  16.874  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      46.397  18.853  18.416  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      46.833  16.394  17.909  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      47.785  15.179  17.456  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      47.796  15.229  15.947  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      47.064  13.929  17.957  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      49.126  15.409  18.108  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 8\nREMARK VINA RESULT:      -7.8      1.802      2.811\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      42.212  19.809  14.319  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      41.663  21.117  14.243  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      41.244  19.004  13.470  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      39.889  19.591  13.832  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      40.234  21.006  14.289  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      39.722  22.104  13.456  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      38.441  22.515  13.321  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      37.335  22.091  13.970  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      38.468  23.532  12.359  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      36.204  22.744  13.640  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      36.135  23.724  12.698  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      37.255  24.143  12.044  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      39.748  23.751  11.938  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      40.489  22.856  12.607  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      37.111  25.056  11.076  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      37.248  26.037  11.320  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      36.811  24.834  10.126  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      39.278  18.858  14.875  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      38.952  19.436  15.554  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      41.339  17.620  13.666  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      42.222  17.277  13.597  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.609  19.768  13.753  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      44.109  18.446  13.787  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      44.786  17.762  12.527  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      44.119  16.445  12.216  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      44.882  18.829  11.506  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      46.249  17.365  13.077  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      46.664  15.970  13.754  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      46.455  14.875  12.793  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      48.034  16.097  14.335  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      45.551  15.950  14.891  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      45.605  15.092  16.250  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      46.366  13.837  15.894  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      44.142  14.776  16.554  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      46.267  15.962  17.290  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\nMODEL 9\nREMARK VINA RESULT:      -7.7      6.028      8.430\nREMARK  11 active torsions:\nREMARK  status: ('A' for Active; 'I' for Inactive)\nREMARK    1  A    between atoms: PG_1  and  O3B_8 \nREMARK    2  A    between atoms: PB_5  and  O3A_12 \nREMARK    3  A    between atoms: PB_5  and  O3B_8 \nREMARK    4  A    between atoms: PA_9  and  O5'_13 \nREMARK    5  A    between atoms: PA_9  and  O3A_12 \nREMARK    6  A    between atoms: O5'_13  and  C5'_14 \nREMARK    7  A    between atoms: C5'_14  and  C4'_15 \nREMARK    8  A    between atoms: C3'_17  and  O3'_18 \nREMARK    9  A    between atoms: C2'_20  and  O2'_21 \nREMARK   10  A    between atoms: C1'_23  and  N9_24 \nREMARK   11  A    between atoms: C6_29  and  N6_30 \nROOT\nHETATM    1  C4' ATP A 501      44.648  18.562  13.199  1.00  5.20     0.180 C \nHETATM    2  O4' ATP A 501      45.477  18.396  14.341  1.00  4.96    -0.353 OA\nHETATM    3  C3' ATP A 501      45.665  18.729  12.084  1.00  5.52     0.182 C \nHETATM    4  C2' ATP A 501      46.748  19.585  12.723  1.00  4.80     0.198 C \nHETATM    5  C1' ATP A 501      46.599  19.279  14.211  1.00  4.22     0.262 C \nENDROOT\nBRANCH   5   6\nHETATM    6  N9  ATP A 501      47.727  18.586  14.850  1.00  3.78    -0.297 N \nHETATM    7  C4  ATP A 501      48.169  17.329  14.619  1.00  3.29     0.142 A \nHETATM    8  N3  ATP A 501      47.753  16.434  13.696  1.00  4.79    -0.336 N \nHETATM    9  C5  ATP A 501      49.208  17.117  15.533  1.00  3.65     0.122 A \nHETATM   10  C2  ATP A 501      48.438  15.274  13.690  1.00  4.70     0.183 A \nHETATM   12  N1  ATP A 501      49.442  14.974  14.559  1.00  4.95    -0.337 N \nHETATM   13  C6  ATP A 501      49.852  15.881  15.490  1.00  4.22     0.131 A \nHETATM   15  N7  ATP A 501      49.409  18.236  16.288  1.00  4.47    -0.346 N \nHETATM   16  C8  ATP A 501      48.483  19.109  15.865  1.00  4.18     0.188 A \nBRANCH  13  18\nHETATM   18  N6  ATP A 501      50.791  15.500  16.365  1.00  5.27    -0.383 N \nATOM     19  H62 ATP A 501      51.000  14.505  16.439  1.00  0.00     0.157 HD\nATOM     20  H61 ATP A 501      51.261  16.139  17.006  1.00  0.00     0.157 HD\nENDBRANCH  13  18\nENDBRANCH   5   6\nBRANCH   4  21\nHETATM   21  O2' ATP A 501      46.531  20.957  12.465  1.00  6.19    -0.388 OA\nATOM     22  H2' ATP A 501      45.933  21.078  11.737  1.00  0.00     0.210 HD\nENDBRANCH   4  21\nBRANCH   3  23\nHETATM   23  O3' ATP A 501      45.129  19.269  10.908  1.00  7.48    -0.390 OA\nATOM     24  H3' ATP A 501      45.092  18.658  10.182  1.00  0.00     0.210 HD\nENDBRANCH   3  23\nBRANCH   1  25\nHETATM   25  C5' ATP A 501      43.776  17.352  12.975  1.00  6.42     0.216 C \nBRANCH  25  26\nHETATM   26  O5' ATP A 501      42.461  17.755  12.649  1.00  6.65    -0.287 OA\nBRANCH  26  27\nHETATM   27  PA  ATP A 501      41.241  17.553  13.641  1.00  6.54     0.417 P \nHETATM   28  O2A ATP A 501      40.088  16.883  12.934  1.00  7.34    -0.624 OA\nHETATM   29  O1A ATP A 501      41.827  16.970  14.869  1.00  8.18    -0.624 OA\nBRANCH  27  30\nHETATM   30  O3A ATP A 501      40.741  19.063  13.909  1.00  6.94    -0.180 OA\nBRANCH  30  31\nHETATM   31  PB  ATP A 501      41.239  20.035  15.085  1.00  6.53     0.428 P \nHETATM   32  O1B ATP A 501      40.557  19.678  16.340  1.00  8.60    -0.624 OA\nHETATM   33  O2B ATP A 501      42.732  20.042  15.115  1.00  5.78    -0.624 OA\nBRANCH  31  34\nHETATM   34  O3B ATP A 501      40.663  21.394  14.491  1.00  7.50    -0.173 OA\nBRANCH  34  35\nHETATM   35  PG  ATP A 501      40.872  21.929  12.988  1.00  8.07     0.431 P \nHETATM   36  O2G ATP A 501      39.640  21.486  12.237  1.00  9.86    -0.616 OA\nHETATM   37  O3G ATP A 501      42.112  21.186  12.493  1.00  9.14    -0.616 OA\nHETATM   38  O1G ATP A 501      41.057  23.424  13.079  1.00  6.46    -0.616 OA\nENDBRANCH  34  35\nENDBRANCH  31  34\nENDBRANCH  30  31\nENDBRANCH  27  30\nENDBRANCH  26  27\nENDBRANCH  25  26\nENDBRANCH   1  25\nTORSDOF 11\nENDMDL\n";
;// CONCATENATED MODULE: ./src/Vue/Store.ts
/* provided dependency */ var Store_jQuery = __webpack_require__(755);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.


// @ts-ignore

// @ts-ignore

// @ts-ignore

const Store_store = new Vuex.Store({
    "state": {
        "vinaParams": {},
        "validation": {},
        hideDockingBoxParams: false,
        "tabIdx": 0,
        "receptorFileName": "",
        "ligandFileName": "",
        "receptorContents": "",
        "receptorContentsExample": _1xdn_pdbqt_namespaceObject,
        "showKeepProteinOnlyLink": true,
        "ligandContents": "",
        "ligandContentsExample": ATP_pdbqt_namespaceObject,
        "crystalContents": "",
        "crystalContentsExample": ATP_pdbqt_namespaceObject,
        "outputContents": "",
        "outputContentsExample": webina_out_pdbqt_namespaceObject,
        "dockedContents": "",
        "parametersTabDisabled": false,
        "existingVinaOutputTabDisabled": false,
        "runningTabDisabled": true,
        "startOverTabDisabled": true,
        "outputTabDisabled": true,
        "pdbOutputFrames": [],
        "stdOut": "",
        "convertFileModalShow": false,
        "convertFileExt": "PDB",
        "convertFileType": "receptor",
        "convertFile": null,
        "receptorForceValidate": false,
        "ligandForceValidate": false,
        "drawSmilesModalShow": false,
        "modalShow": false,
        "modalTitle": "Title",
        "modalBody": "Some text here...",
        "vinaParamsValidates": false,
        "time": 0 // Used to keep track of execution time.
    },
    "mutations": {
        /**
         * Set one of the VueX store variables.
         * @param  {any}              state    The VueX state.
         * @param  {IVueXStoreSetVar} payload  An object containing
         *                                     information about which
         *                                     variable to set.
         * @returns void
         */
        "setVar"(state, payload) {
            state[payload.name] = payload.val;
        },
        /**
         * Set one of the vina parameters.
         * @param  {any}        state    The VueX state.
         * @param  {iVueXParam} payload  An object with information about
         *                               which vina parameter to set.
         * @returns void
         */
        "setVinaParam"(state, payload) {
            // By redefining the whole variable, it becomes reactive. Directly
            // changing individual properties is not reactive.
            state["vinaParams"] = getNewObjWithUpdate(state["vinaParams"], payload.name, payload.val);
            state.hideDockingBoxParams = state["vinaParams"]["score_only"] === true;
        },
        /**
         * Set a validation parameter (either validates or doesn't).
         * @param  {any}        state    The VueX state.
         * @param  {iVueXParam} payload  An object containing information
         *                               about what to set.
         * @returns void
         */
        "setValidationParam"(state, payload) {
            // By redefining the whole variable, it becomes reactive. Directly
            // changing individual properties is not reactive.
            state["validation"] = getNewObjWithUpdate(state["validation"], payload.name, payload.val);
        },
        /**
         * Disable or enable tabs.
         * @param  {any} state    The VueX stste.
         * @param  {any} payload  An object containing information about which
         *                        tabs should be enabled or disabled.
         * @returns void
         */
        "disableTabs"(state, payload) {
            const tabDisableVarNames = Object.keys(payload);
            const tabDisableVarNamesLen = tabDisableVarNames.length;
            for (let i = 0; i < tabDisableVarNamesLen; i++) {
                const tabDisableVarName = tabDisableVarNames[i];
                let val = payload[tabDisableVarName];
                val = val === undefined ? true : val;
                state[tabDisableVarName] = val;
            }
            // If the output tab has been enabled, you should also warn the
            // user about closing the website.
            if (payload["outputTabDisabled"] === false) {
                window.addEventListener("beforeunload", (event) => {
                    event.preventDefault();
                    // No modern browser respects the returnValue anymore. See
                    // https://stackoverflow.com/questions/45088861/whats-the-point-of-beforeunload-returnvalue-if-the-message-does-not-get-set
                    event.returnValue = "";
                });
            }
        },
        /**
         * Extract and save relevant data about the poses from the Vina
         * output.
         * @param  {any} state  The VueX state.
         * @returns void
         */
        "outputToData"(state) {
            let data = [];
            let outPdbqtFileTxt = state["outputContents"];
            // Get info like score and rmsd from output file.
            let re = /^REMARK VINA RESULT:\W+?([0-9\.\-]+)\W+?([0-9\.\-]+)\W+?([0-9\.\-]+)$/gm;
            let match;
            let i = 1;
            while (match = re.exec(outPdbqtFileTxt)) {
                // @ts-ignore
                data.push([i, match[1], match[2], match[3]].map(d => +d));
                i++;
            }
            // Get pdb frames from output pdbqt file.
            let framesPDBQTs = outPdbqtFileTxt.split("ENDMDL");
            let framePDBs = framesPDBQTs
                .map(t => pdbqtToPDB(t, this.$store))
                .filter(t => t !== "")
                .map((t, i) => { return [data[i], t]; });
            state["pdbOutputFrames"] = framePDBs;
            // Set the first docked frame as the selected one.
            state["dockedContents"] = framePDBs[0][1];
        },
        /**
         * Open the modal.
         * @param  {*}      state    The VueX state.
         * @param  {IModal} payload  An object with the title and body.
         * @returns void
         */
        "openModal"(state, payload) {
            state["modalTitle"] = payload.title;
            state["modalBody"] = payload.body;
            state["modalShow"] = true;
            Store_jQuery("body").removeClass("waiting");
        },
        /**
         * Open the modal.
         * @param  {*}                 state    The VueX state.
         * @param  {IFileConvertModal} payload  An object with the ext, type,
         *                                      and file.
         * @returns void
         */
        "openConvertFileModal"(state, payload) {
            state["convertFileModalShow"] = true;
            state["convertFileExt"] = payload.ext;
            state["convertFileType"] = payload.type;
            state["convertFile"] = payload.file;
            Store_jQuery("body").removeClass("waiting");
        },
        /**
         * Open the modal.
         * @param  {*}                 state    The VueX state.
         * @returns void
         */
        "drawSmilesModal"(state) {
            state["drawSmilesModalShow"] = true;
            Store_jQuery("body").removeClass("waiting");
        },
        /**
         * Update the filenames of the receptor and ligand input files.
         * @param  {any}             state    The VueX state.
         * @param  {IInputFileNames} payload  An object describing the
         *                                    filename change.
         * @returns void
         */
        "updateFileName"(state, payload) {
            // Also update file names so example vina command line is valid.
            state[payload.type + "FileName"] = payload.filename;
        }
    }
});
// Good for debugging.
window["store"] = Store_store;

;// CONCATENATED MODULE: ./src/UI/UI.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.



/**
 * Setup the main Vue app.
 * @returns void
 */
function UI_setup() {
    new Vue({
        "el": '#app',
        "store": Store_store,
        "template": `
            <div class="container-fluid">
                <open-modal></open-modal>
                <convert-file-modal></convert-file-modal>
                <draw-smiles-modal></draw-smiles-modal>
                <div id="no-mobile">
                    <b-jumbotron class="jumbo" header="Webina ${VERSION}" lead="AutoDock Vina Ported to WebAssembly">
                        <p>Webina ${VERSION} is not designed to work on mobile phones. Please use a device with a larger screen.</p>
                    </b-jumbotron>
                </div>

                <b-jumbotron class="jumbo" style="background-image:url(${curPath()}webina_logo.jpg);" header="Webina ${VERSION}" lead="AutoDock Vina Ported to WebAssembly">
                    <p>Brought to you by the <a target="_blank" href="http://durrantlab.com">Durrant Lab</a>.</p>
                    <b-button variant="primary" target="_blank" href="http://durrantlab.com">More Info</b-button>
                </b-jumbotron>

                <b-card no-body class="mb-3">
                    <b-tabs v-model="tabIdx" card fill pills vertical content-class="mt-3"> <!-- vertical -->
                        <b-tab title="Input Parameters" active :disabled="parametersTabDisabled">
                            <b-card-text>
                                <vina-params></vina-params>
                            </b-card-text>
                        </b-tab>
                        <b-tab title="Existing Vina Output" :disabled="existingVinaOutputTabDisabled">
                            <b-card-text>
                                <vina-existing-output></vina-existing-output>
                            </b-card-text>
                        </b-tab>
                        <b-tab title="Running Webina" :disabled="runningTabDisabled">
                            <b-card-text>
                                <vina-running></vina-running>
                            </b-card-text>
                        </b-tab>
                        <b-tab title="Output" :disabled="outputTabDisabled">
                            <b-card-text>
                                <vina-output></vina-output>
                            </b-card-text>
                        </b-tab>
                        <b-tab title="Start Over" :disabled="startOverTabDisabled">
                            <b-card-text>
                                <start-over></start-over>
                            </b-card-text>
                        </b-tab>
                    </b-tabs>
                </b-card>
            </div>
        `,
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {
                "receptorFile": false,
                "ligandFile": false
            };
        },
        "computed": {
            /** Gets and sets the tabIdx. */
            "tabIdx": {
                get() {
                    return Store_store.state["tabIdx"];
                },
                set(val) {
                    Store_store.commit("setVar", {
                        name: "tabIdx",
                        val: val
                    });
                }
            },
            /**
             * Determine whether the parameters tab is disabled.
             * @returns boolean  True if it is disabled, false otherwise.
             */
            "parametersTabDisabled"() {
                return Store_store.state["parametersTabDisabled"];
            },
            /**
             * Determine whether the running tab is disabled.
             * @returns boolean  True if it is disabled, false otherwise.
             */
            "runningTabDisabled"() {
                return Store_store.state["runningTabDisabled"];
            },
            /**
             * Determine whether the output tab is disabled.
             * @returns boolean  True if it is disabled, false otherwise.
             */
            "outputTabDisabled"() {
                return Store_store.state["outputTabDisabled"];
            },
            /**
             * Determine whether the existing vina output tab is disabled.
             * @returns boolean  True if it is disabled, false otherwise.
             */
            "existingVinaOutputTabDisabled"() {
                return Store_store.state["existingVinaOutputTabDisabled"];
            },
            /**
             * Determine whether the start over tab is disabled.
             * @returns boolean  True if it is disabled, false otherwise.
             */
            "startOverTabDisabled"() {
                return Store_store.state["startOverTabDisabled"];
            }
        },
        "methods": {},
        /**
         * Runs when the vue component is mounted.
         * @returns void
         */
        "mounted"() {
            // (<any>window)["$store"] = store;  // For debugging
        }
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/NumericInput.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let NumericInput_computedFunctions = {
    /** Gets and sets the vinaParams object. In setting, also makes sure that
     * the value meets min/max requirements, etc.*/
    "val": {
        get() {
            return Store_store.state["vinaParams"][this["id"]];
        },
        set(val) {
            // Save the value to the store
            val = (val === "") ? undefined : +val;
            if (isNaN(val)) {
                val = undefined;
            }
            Store_store.commit("setVinaParam", {
                name: this["id"],
                val: val
            });
            // Determine if it is valid. First, make sure there's
            // something here if its required.
            let valid = true;
            let scoreOnly = Store_store.state["vinaParams"]["score_only"];
            if ((this["required"] === true) && (scoreOnly !== true)) {
                this["invalidMsg"] = "This field is required.";
                valid = val !== undefined;
            }
            // Check if min or max requirements met.
            if ((valid === true) && (this["min"] !== undefined) && (this["min"] > val)) {
                this["invalidMsg"] = "Value must be &ge; " + this["min"].toString() + ".";
                valid = false;
            }
            if ((valid === true) && (this["max"] !== undefined) && (this["max"] < val)) {
                this["invalidMsg"] = "Value must be &le; " + this["max"].toString() + ".";
                valid = false;
            }
            Store_store.commit("setValidationParam", {
                name: this["id"],
                val: valid
            });
        }
    },
    /**
     * Generates a description string.
     * @returns string  The description.
     */
    "desc"() {
        let toAdd = "";
        if ((this["required"] !== true) && (this["default"] === undefined)) {
            toAdd = " (Leave blank to use default value.)";
        }
        return this["description"] + toAdd;
    },
    /**
     * Determine whether the component value is valid.
     * @returns boolean  True if it is valid, false otherwise.
     */
    "isValid"() {
        // @ts-ignore
        return Store_store.state["validation"][this["id"]];
    }
};
/**
 * The vue-component mounted function.
 * @returns void
 */
function NumericInput_mountedFunction() {
    // @ts-ignore
    const id = this["id"];
    // @ts-ignore
    const required = this["required"];
    // @ts-ignore
    const defaultVal = this["default"];
    // Always start by assuming it validates fine.
    if (Store_store.state["validation"][id] === undefined) {
        Store_store.commit("setValidationParam", {
            name: id,
            val: !required
        });
    }
    // Set value if it is given.
    if (defaultVal !== undefined) {
        Store_store.commit("setVinaParam", {
            name: id,
            val: defaultVal
        });
    }
}
/**
 * Setup the numeric-input Vue commponent.
 * @returns void
 */
function NumericInput_setup() {
    Vue.component('numeric-input', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {
                "invalidMsg": "This field is required."
            };
        },
        "computed": NumericInput_computedFunctions,
        "template": `
            <form-group
                :label="label"
                :id="'input-group-' + id"
                :style="styl"
                :description="desc"
                :formGroupWrapper="formGroupWrapper"
            >
                <b-form-input
                    :id="id"
                    :name="id"
                    v-model="val"
                    type="number"
                    :required="required"
                    :placeholder="placeholder"
                    :class="{ 'is-invalid': !isValid }"
                    :min="min" :max="max"
                ></b-form-input>
                <small v-if="!isValid" alert tabindex="-1" class="text-danger form-text" v-html="invalidMsg"></small>
            </form-group>
        `,
        "props": {
            "label": String,
            "id": String,
            "description": String,
            "placeholder": String,
            "required": Boolean,
            "styl": String,
            "default": Number,
            "formGroupWrapper": {
                "type": Boolean,
                "default": true
            },
            "min": {
                "type": Number,
                "default": undefined
            },
            "max": {
                "type": Number,
                "default": undefined
            }
        },
        /**
         * Runs when the vue component is mounted.
         * @returns void
         */
        "mounted": NumericInput_mountedFunction
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/CheckBox.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let CheckBox_computedFunctions = {
    /** Gets and sets the vinaParams object. */
    "val": {
        get() {
            return Store_store.state["vinaParams"][this["id"]];
        },
        set(val) {
            Store_store.commit("setVinaParam", {
                name: this["id"],
                val: val
            });
        }
    },
    /**
     * Generates a description string.
     * @returns string  The description.
     */
    "desc"() {
        return this["description"] + (this["required"] !== true ? " (Leave blank to use default value.)" : "");
    }
};
/**
 * Setup the check-box Vue commponent.
 * @returns void
 */
function CheckBox_setup() {
    Vue.component('check-box', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": CheckBox_computedFunctions,
        "template": `
            <b-form-checkbox
                :id="id"
                v-model="val"
                :name="id"
                :value="true"
                :unchecked-value="false"
            >
                {{label}}
            </b-form-checkbox>
        `,
        "props": {
            "label": String,
            "id": String,
        }
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/FileInput.ts
/* provided dependency */ var FileInput_jQuery = __webpack_require__(755);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let FileInput_computedFunctions = {
    /** Gets and sets the file. On setting, also checks for a valid extension
     * and opens the convert modal if necessary. */
    val: {
        get() {
            return this["file"];
        },
        set(val) {
            if (val === null) {
                // Reseting the value. Nothing to do here.
                return;
            }
            // Check if the file extension is ok.
            let namePts = val["name"].toLowerCase().split(/\./g);
            let ext = namePts[namePts.length - 1];
            let acceptableExt = this["accept"]
                .toLowerCase()
                .split(/,/g)
                .map((e) => e.replace(/ /g, "").replace(/\./, ""));
            let convertExt = this["convert"]
                .toLowerCase()
                .split(/,/g)
                .map((e) => e.replace(/ /g, "").replace(/\./, ""));
            if (convertExt.indexOf(ext) !== -1) {
                // Set the filename.
                Store_store.commit("updateFileName", {
                    type: this["id"],
                    filename: val.name,
                });
                // @ts-ignore
                this.getModelFileContents(val).then((text) => {
                    Store_store.commit("openConvertFileModal", {
                        ext: ext,
                        type: this["id"],
                        file: text,
                    });
                });
                return;
            }
            else if (acceptableExt.indexOf(ext) === -1) {
                // It is not one of the acceptable extensions that can be
                // converted to pdbqt. Need to cancel.
                let extsAllowed = acceptableExt.concat(convertExt);
                let msg = "The file must end in ";
                if (extsAllowed.length > 1) {
                    extsAllowed[extsAllowed.length - 1] =
                        "or " + extsAllowed[extsAllowed.length - 1];
                }
                let okFilesString;
                if (extsAllowed.length > 2) {
                    okFilesString = extsAllowed.join('," "');
                }
                else {
                    okFilesString = extsAllowed.join('" "');
                }
                okFilesString = okFilesString.replace(/"or /g, 'or "');
                msg +=
                    '"' + okFilesString + '." Your file ends in "' + ext + '."';
                Store_store.commit("openModal", {
                    title: "Invalid File Extension!",
                    body: "<p>" + msg + "</p>",
                });
                this["file"] = null;
                return;
            }
            this["file"] = val;
            Store_store.commit("setValidationParam", {
                name: this["id"],
                val: true,
            });
            Store_store.commit("updateFileName", {
                type: this["id"],
                filename: val.name,
            });
            // @ts-ignore
            this.getModelFileContents(this["file"]).then((text) => {
                Store_store.commit("setVar", {
                    name: this["id"] + "Contents",
                    val: text,
                });
            });
        },
    },
    /**
     * Generates a string describing all the acceptable file formats.
     * @returns string  The string.
     */
    allAcceptableFiles() {
        return (this["accept"] +
            (this["convert"] === "" ? "" : ", " + this["convert"]));
    },
    /**
     * Determine whether the component value is valid.
     * @returns boolean  True if it is valid, false otherwise.
     */
    isValid() {
        if (this["file"] !== false && this["file"] !== null) {
            return true;
        }
        else if (Store_store.state[this["id"] + "ForceValidate"] ===
            true) {
            // This runs when you convert from a non-pdbqt file
            // converted to pdbqt.
            let flnm = Store_store.state[this["id"] + "FileName"];
            this["file"] = new File([], flnm);
            this["placeholder"] = flnm;
            return true;
        }
        return false;
    },
};
/** An object containing the vue-component methods functions. */
let FileInput_methodsFunctions = {
    /**
     * Given a file object, returns a promise that resolves the text
     * in that file.
     * @param  {*} fileObj  The file object.
     * @returns Promise
     */
    getModelFileContents(fileObj) {
        return new Promise((resolve, reject) => {
            let fr = new FileReader();
            fr.onload = () => {
                // @ts-ignore: Not sure why this causes Typescript problems.
                let data = new Uint8Array(fr.result);
                resolve(new TextDecoder("utf-8").decode(data));
            };
            fr.readAsArrayBuffer(fileObj);
            // Reset the show non-protein atom's link.
            if (this["id"] === "receptor") {
                Store_store.commit("setVar", {
                    name: "showKeepProteinOnlyLink",
                    val: true,
                });
            }
        });
    },
};
/**
 * The vue-component mounted function.
 * @returns void
 */
function FileInput_mountedFunction() {
    // @ts-ignore
    const id = this["id"];
    // Make default validation entry.
    if (Store_store.state["validation"][id] === undefined) {
        Store_store.commit("setValidationParam", {
            // @ts-ignore
            name: id,
            val: false,
        });
    }
    // If it's not required, automatically validate.
    // @ts-ignore
    if (this["required"] === false) {
        // @ts-ignore
        Store_store.commit("setValidationParam", {
            name: id,
            val: true,
        });
        FileInput_jQuery("." + id)
            .find("input")
            .removeClass("is-invalid");
    }
}
/**
 * Setup the file-input Vue commponent.
 * @returns void
 */
function FileInput_setup() {
    Vue.component("file-input", {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        data() {
            return {
                file: false,
                placeholder: "Choose a file or drop it here...",
            };
        },
        methods: FileInput_methodsFunctions,
        template: `
            <form-group
                :label="label"
                :id="'input-group-' + id"
                :description="description"
                styl="line-height:0;"
            >
                <template v-slot:extraDescription>
                    <slot name="extraDescription"></slot>
                </template>
                <b-form-file
                    v-model="val"
                    :state="Boolean(file)"
                    :placeholder="placeholder"
                    drop-placeholder="Drop file here..."
                    :class="id" :accept="allAcceptableFiles"
                    :required="required"
                ></b-form-file>
                <small v-if="(!isValid) && (required === true)" alert tabindex="-1" class="text-danger form-text">{{invalidMsg}}</small>
            </form-group>
        `,
        props: {
            label: String,
            id: String,
            description: String,
            invalidMsg: {
                type: String,
                default: "This field is required!",
            },
            required: {
                type: Boolean,
                default: true,
            },
            accept: {
                type: String,
                default: ".pdbqt, .out, .pdb",
            },
            convert: {
                type: String,
                default: "",
            },
        },
        computed: FileInput_computedFunctions,
        /**
         * Runs when the vue component is mounted.
         * @returns void
         */
        mounted: FileInput_mountedFunction,
    });
}

;// CONCATENATED MODULE: ./src/Webina/Webina.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
// There are a few variables and functions from vina.js that I want to easily
// access from here.
let Webina_VERSION = "XXXXXXXXXXXXX.X"; // Replaced by compile script.
console.log("Webina Library " + Webina_VERSION);
console.log("    Compiled from Vina 1.1.2 codebase:");
console.log("    http://vina.scripps.edu/");
function start(vinaParams, receptorPDBQTTxt, ligandPDBQTTxt, onDone, onError, baseUrl) {
    // baseUrl = undefined;  // For debugging.
    let baseUrlMsg = "\nWEBINA\n======\n\n";
    if (baseUrl !== undefined) {
        if (baseUrl.slice(baseUrl.length - 1) !== "/") {
            baseUrl += "/";
        }
        debugger; // fix below
        // this.WEBINA_BASE_URL = baseUrl;
        baseUrlMsg += "User specified baseUrl: " + baseUrl + "\n";
    }
    else {
        baseUrlMsg += "No baseUrl specified, so using ./\n\n";
        baseUrlMsg += "Use Webina.start() to specify the baseUrl:\n";
        baseUrlMsg += "    function start(vinaParams, receptorPDBQTTxt, \n";
        baseUrlMsg += "                   ligandPDBQTTxt, onDone, \n";
        baseUrlMsg += "                   onError, baseUrl)\n";
    }
    baseUrlMsg += "\nExpecting files at the following locations:\n";
    for (let i = 0; i < 5; i++) {
        const fileName = [
            "Webina.min.js",
            "vina.html.mem",
            "vina.min.js",
            "vina.worker.min.js",
            "vina.wasm",
        ][i];
        baseUrlMsg +=
            "    " + (baseUrl === undefined ? "./" : baseUrl) + fileName + "\n";
    }
    baseUrlMsg += "\n";
    if (baseUrl !== undefined) {
        console.log(baseUrlMsg);
    }
    else {
        console.warn(baseUrlMsg);
    }
    // @ts-ignore
    __webpack_require__.e(/* import() | webina */ 490).then(__webpack_require__.bind(__webpack_require__, 458))
        .then((mod) => {
        const WEBINA_Module = mod.default;
        const webinaMod = new WEBINA_Module({
            logReadFiles: true,
            noInitialRun: true,
            locateFile: (path) => {
                console.log(path);
                return `Webina/${path}`;
            },
            preRun: [
                function (This) {
                    // Save the pdb file to the file system
                    debugger; // fix below
                    // This.FS.writeFile(
                    //     params.pdbFiles.prot.name,
                    //     params.pdbFiles.prot.contents
                    // );
                    // This.FS.writeFile(
                    //     params.pdbFiles.cmpd.name,
                    //     params.pdbFiles.cmpd.contents
                    // );
                },
            ],
            print: (text) => {
                console.log(text);
            },
            printErr: (text) => {
                console.log(text);
            },
        });
        debugger;
        return webinaMod;
    })
        .then((webinaMod) => {
        return webinaMod.ready;
    })
        .then((webinaMod) => {
        debugger;
    });
    // let cmdLineParams: any[] = [];
    // Object.keys(params.userArgs).forEach((key) => {
    //     const val = params.userArgs[key];
    //     if (val === false) {
    //         return;
    //     } else if (val === true) {
    //         cmdLineParams.push(`--${key}`);
    //         return;
    //     }
    //     cmdLineParams.push(`--${key}`);
    //     cmdLineParams.push(val);
    // });
    // // cmdLineParams = ["--help"]
    // cmdLineParams = [
    //     "--receptor",
    //     "/receptor.pdbqt",
    //     "--ligand",
    //     "/ligand.pdbqt",
    // ];
    // console.log(cmdLineParams);
    // debugger;
    // webinaMod.callMain(cmdLineParams);
}
//     if (onError === undefined) {
//         onError = () => {
//             console.log("Webina encountered an error! Does your browser support WebAssembly?");
//         }
//     }
//     // Create a module object for WASM.
//     const Module = {
//         "preRun": [],
//         "postRun": [],
//         "stdOut": "",
//         "stdErr": "",
//         // "print": function() {
//         //     return function(e) {
//         //         1 < arguments.length && (
//         //             e = Array.prototype.slice.call(arguments).join(" ")
//         //         ),
//         //         (<any>window)["WEBINA_Module"]["stdOut"] += e + "\n"
//         //     }
//         // }(),
//         // "printErr": function(e) {
//         //     // 1 < arguments.length && (e = Array.prototype.slice.call(arguments).join(" ")), console.error(e)
//         //     1 < arguments.length && (
//         //         e = Array.prototype.slice.call(arguments).join(" ")
//         //     ),
//         //     (<any>window)["WEBINA_Module"]["stdErr"] += e + "\n"
//         // },
//         "setStatus": (e) => {
//             if (e === "") {
//                 // This happens when it is done running.
//                 if (onDone !== undefined) {
//                     let outTxt: string = new TextDecoder("utf-8").decode(
//                         (<any>window)["FS"]["readFile"]('ligand_out.pdbqt')
//                     );
//                     let stdOut: string = ""; // (<any>window)["WEBINA_Module"]["stdOut"];
//                     let stdErr: string = ""; // (<any>window)["WEBINA_Module"]["stdErr"];
//                     onDone(outTxt, stdOut, stdErr);
//                 }
//             }
//         },
//         "onError": onError,
//         "catchError": (n) => {
//             onError(n);
//             // throw n;  // Don't throw the errr. You're catching it now.
//         },
//         "receptorPDBQTTxt": receptorPDBQTTxt,
//         "ligandPDBQTTxt": ligandPDBQTTxt
//     };
//     if (vinaParams["receptor"] !== undefined) {
//         console.warn("Webina does not support Vina's --receptor parameter. Instead, pass the content of the receptor file as a string to the webina.start() function.");
//     }
//     if (vinaParams["receptor"] !== undefined) {
//         console.warn("Webina does not support Vina's --ligand parameter. Instead, pass the content of the ligand file as a string to the webina.start() function.");
//     }
//     // Receptor and ligand files are always the same.
//     Module['arguments'] = [
//         '--receptor', '/receptor.pdbqt',
//         '--ligand', '/ligand.pdbqt',
//     ];
//     // For some reason, WebAssembly always uses one more processor
//     // than specified. Compensate for that here. But sometimes it
//     // doesn't, so commenting out... Confusing.
//     // if ((vinaParams["cpu"] !== undefined) && (vinaParams["cpu"] > 1)) {
//     //     vinaParams["cpu"] = vinaParams["cpu"] - 1;
//     // }
//     // Add in the remaining values. Note that there is no validation here.
//     const paramNames = Object.keys(vinaParams);
//     const paramNamesLen = paramNames.length;
//     for (let i = 0; i < paramNamesLen; i++) {
//         const key = paramNames[i];
//         const val = vinaParams[key];
//         Module['arguments'].push('--' + key);
//         if (typeof(val) !== "boolean") {
//             Module['arguments'].push(String(val));
//         }
//     }
//     // const webinaMod = new WEBINA_Module(Module);
//     // (<any>window)["WEBINA_Module"] = WEBINA_Module;
//     // Initialize the memory
//     // let memoryInitializer = this.WEBINA_BASE_URL + "vina.html.mem";
//     // memoryInitializer = Module["locateFile"] ? Module["locateFile"](memoryInitializer, "") : memoryInitializer, Module["memoryInitializerRequestURL"] = memoryInitializer;
//     debugger;
//     // let meminitXHR = Module["memoryInitializerRequest"] = new XMLHttpRequest;
//     // meminitXHR.onloadend = () => {
//     //     if (meminitXHR.status === 404) {
//     //         let msg = "Unable to access " + memoryInitializer +". See JavaScript console for warnings. The \"baseUrl\" variable passed to Webina is likely incorrect.";
//     //         Module["catchError"]({"message": msg});
//     //         console.warn(msg);
//     //     } else {
//     //         var script = document.createElement("script");
//     //         script.src = this.WEBINA_BASE_URL + "vina.js";
//     //         document.body.appendChild(script)
//     //     }
//     // }
//     // meminitXHR.open("GET", memoryInitializer, !0);
//     // meminitXHR.responseType = "arraybuffer";
//     // meminitXHR.send(null);
// }
// const webinaMod = new WEBINA_Module({
//     logReadFiles: true,
//     noInitialRun: true,
//     locateFile: (path: string) => {
//         console.log(path);
//         return `webina/${path}`;
//     },
//     preRun: [
//         function (This: any) {
//             // Save the pdb file to the file system
//             // This.FS.writeFile(params.pdbFiles.prot.name, params.pdbFiles.prot.contents);
//             // This.FS.writeFile(params.pdbFiles.cmpd.name, params.pdbFiles.cmpd.contents);
//         }
//     ],
//     print: (text: string) => {
//         console.log(text);
//     },
//     printErr: (text: string) => {
//         console.log(text);
//     },
// });
// debugger;
// // // A shiv for decodeBase64.
// // var decodeBase64 = "function" == typeof atob ? atob : function(r: string) {
// //     var e, t, a, i, n, o, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
// //         m = "",
// //         s = 0;
// //     for (r = r.replace(/[^A-Za-z0-9\+\/\=]/g, ""); e = f.indexOf(r.charAt(s++)) << 2 | (i = f.indexOf(r.charAt(s++))) >> 4, t = (15 & i) << 4 | (n = f.indexOf(r.charAt(s++))) >> 2, a = (3 & n) << 6 | (o = f.indexOf(r.charAt(s++))), m += String.fromCharCode(e), 64 !== n && (m += String.fromCharCode(t)), 64 !== o && (m += String.fromCharCode(a)), s < r.length;)
// //     return m
// // };
// // // Make Webina global namespace.
// // let Webina = (function() {
// //     return {
// //         WEBINA_ENVIRONMENT_IS_NODE: (<any>window)["WEBINA_ENVIRONMENT_IS_NODE"],
// //         WEBINA_lengthBytesUTF8: (<any>window)["WEBINA_lengthBytesUTF8"],
// //         WEBINA_stringToUTF8Array: (<any>window)["WEBINA_stringToUTF8Array"],
// //         WEBINA_assert: (<any>window)["WEBINA_assert"],
// //         WEBINA_ASSERTIONS: 1,
// //         WEBINA_DATA_URI_PREFIX: "data:application/octet-stream;base64,",
// //         WEBINA_BASE_URL: "./",
// //         FS: (<any>window)["FS"],
// //         start: function start(vinaParams: IVinaParams, receptorPDBQTTxt: string, ligandPDBQTTxt: string, onDone?: any, onError?: any, baseUrl?: string): void {
// //             // baseUrl = undefined;  // For debugging.
// //             let baseUrlMsg = "\nWEBINA\n======\n\n";
// //             if (baseUrl !== undefined) {
// //                 if (baseUrl.slice(baseUrl.length - 1) !== "/") {
// //                     baseUrl += "/";
// //                 }
// //                 this.WEBINA_BASE_URL = baseUrl;
// //                 baseUrlMsg += "User specified baseUrl: " + baseUrl + "\n";
// //             } else {
// //                 baseUrlMsg += "No baseUrl specified, so using ./\n\n";
// //                 baseUrlMsg += "Use Webina.start() to specify the baseUrl:\n";
// //                 baseUrlMsg += "    function start(vinaParams, receptorPDBQTTxt, \n"
// //                 baseUrlMsg += "                   ligandPDBQTTxt, onDone, \n";
// //                 baseUrlMsg += "                   onError, baseUrl)\n";
// //             }
// //             baseUrlMsg += "\nExpecting files at the following locations:\n";
// //             for (let i = 0; i < 5; i++) {
// //                 const fileName = ["Webina.min.js", "vina.html.mem",
// //                                   "vina.min.js", "vina.worker.min.js",
// //                                   "vina.wasm"][i];
// //                 baseUrlMsg += "    " + (baseUrl === undefined ? "./" : baseUrl) + fileName + "\n";
// //             }
// //             baseUrlMsg += "\n";
// //             if (baseUrl !== undefined) {
// //                 console.log(baseUrlMsg);
// //             } else {
// //                 console.warn(baseUrlMsg);
// //             }
// //             if (onError === undefined) {
// //                 onError = () => {
// //                     console.log("Webina encountered an error! Does your browser support WebAssembly?");
// //                 }
// //             }
// //             // Create a module object for WASM.
// //             const Module = {
// //                 "preRun": [],
// //                 "postRun": [],
// //                 "stdOut": "",
// //                 "stdErr": "",
// //                 // "print": function() {
// //                 //     return function(e) {
// //                 //         1 < arguments.length && (
// //                 //             e = Array.prototype.slice.call(arguments).join(" ")
// //                 //         ),
// //                 //         (<any>window)["WEBINA_Module"]["stdOut"] += e + "\n"
// //                 //     }
// //                 // }(),
// //                 // "printErr": function(e) {
// //                 //     // 1 < arguments.length && (e = Array.prototype.slice.call(arguments).join(" ")), console.error(e)
// //                 //     1 < arguments.length && (
// //                 //         e = Array.prototype.slice.call(arguments).join(" ")
// //                 //     ),
// //                 //     (<any>window)["WEBINA_Module"]["stdErr"] += e + "\n"
// //                 // },
// //                 "setStatus": (e) => {
// //                     if (e === "") {
// //                         // This happens when it is done running.
// //                         if (onDone !== undefined) {
// //                             let outTxt: string = new TextDecoder("utf-8").decode(
// //                                 (<any>window)["FS"]["readFile"]('ligand_out.pdbqt')
// //                             );
// //                             let stdOut: string = ""; // (<any>window)["WEBINA_Module"]["stdOut"];
// //                             let stdErr: string = ""; // (<any>window)["WEBINA_Module"]["stdErr"];
// //                             onDone(outTxt, stdOut, stdErr);
// //                         }
// //                     }
// //                 },
// //                 "onError": onError,
// //                 "catchError": (n) => {
// //                     onError(n);
// //                     // throw n;  // Don't throw the errr. You're catching it now.
// //                 },
// //                 "receptorPDBQTTxt": receptorPDBQTTxt,
// //                 "ligandPDBQTTxt": ligandPDBQTTxt
// //             };
// //             if (vinaParams["receptor"] !== undefined) {
// //                 console.warn("Webina does not support Vina's --receptor parameter. Instead, pass the content of the receptor file as a string to the webina.start() function.");
// //             }
// //             if (vinaParams["receptor"] !== undefined) {
// //                 console.warn("Webina does not support Vina's --ligand parameter. Instead, pass the content of the ligand file as a string to the webina.start() function.");
// //             }
// //             // Receptor and ligand files are always the same.
// //             Module['arguments'] = [
// //                 '--receptor', '/receptor.pdbqt',
// //                 '--ligand', '/ligand.pdbqt',
// //             ];
// //             // For some reason, WebAssembly always uses one more processor
// //             // than specified. Compensate for that here. But sometimes it
// //             // doesn't, so commenting out... Confusing.
// //             // if ((vinaParams["cpu"] !== undefined) && (vinaParams["cpu"] > 1)) {
// //             //     vinaParams["cpu"] = vinaParams["cpu"] - 1;
// //             // }
// //             // Add in the remaining values. Note that there is no validation here.
// //             const paramNames = Object.keys(vinaParams);
// //             const paramNamesLen = paramNames.length;
// //             for (let i = 0; i < paramNamesLen; i++) {
// //                 const key = paramNames[i];
// //                 const val = vinaParams[key];
// //                 Module['arguments'].push('--' + key);
// //                 if (typeof(val) !== "boolean") {
// //                     Module['arguments'].push(String(val));
// //                 }
// //             }
// //             // const webinaMod = new WEBINA_Module(Module);
// //             // (<any>window)["WEBINA_Module"] = WEBINA_Module;
// //             // Initialize the memory
// //             // let memoryInitializer = this.WEBINA_BASE_URL + "vina.html.mem";
// //             // memoryInitializer = Module["locateFile"] ? Module["locateFile"](memoryInitializer, "") : memoryInitializer, Module["memoryInitializerRequestURL"] = memoryInitializer;
// //             debugger;
// //             // let meminitXHR = Module["memoryInitializerRequest"] = new XMLHttpRequest;
// //             // meminitXHR.onloadend = () => {
// //             //     if (meminitXHR.status === 404) {
// //             //         let msg = "Unable to access " + memoryInitializer +". See JavaScript console for warnings. The \"baseUrl\" variable passed to Webina is likely incorrect.";
// //             //         Module["catchError"]({"message": msg});
// //             //         console.warn(msg);
// //             //     } else {
// //             //         var script = document.createElement("script");
// //             //         script.src = this.WEBINA_BASE_URL + "vina.js";
// //             //         document.body.appendChild(script)
// //             //     }
// //             // }
// //             // meminitXHR.open("GET", memoryInitializer, !0);
// //             // meminitXHR.responseType = "arraybuffer";
// //             // meminitXHR.send(null);
// //         },
// //         isDataURI: function(r) {
// //             // @ts-ignore
// //             return String.prototype.startsWith ? r.startsWith(this.WEBINA_DATA_URI_PREFIX) : 0 === r.indexOf(this.WEBINA_DATA_URI_PREFIX)
// //         },
// //         intArrayFromBase64: function (e) {
// //             if ("boolean" == typeof this.WEBINA_ENVIRONMENT_IS_NODE && this.WEBINA_ENVIRONMENT_IS_NODE) {
// //                 var t;
// //                 try {
// //                     t = Buffer.from(e, "base64")
// //                 } catch (r) {
// //                     t = new Buffer(e, "base64")
// //                 }
// //                 return new Uint8Array(t.buffer, t.byteOffset, t.byteLength)
// //             }
// //             try {
// //                 for (var r = decodeBase64(e) as string, a = new Uint8Array(r.length), i = 0; i < r.length; ++i) a[i] = r.charCodeAt(i);
// //                 return a
// //             } catch (r) {
// //                 throw new Error("Converting base64 string to bytes failed.")
// //             }
// //         },
// //         // Not used?
// //         tryParseAsDataURI: function (r) {
// //             if (this.isDataURI(r)) return this.intArrayFromBase64(r.slice(this.WEBINA_DATA_URI_PREFIX.length))
// //         },
// //         // Not used?
// //         intArrayFromString: function (r, e, t) {
// //             var a = 0 < t ? t : this.WEBINA_lengthBytesUTF8(r) + 1,
// //                 i = new Array(a),
// //                 n = this.WEBINA_stringToUTF8Array(r, i, 0, i.length);
// //             return e && (i.length = n), i
// //         },
// //         // Not used?
// //         intArrayToString: function (r) {
// //             for (var e = [], t = 0; t < r.length; t++) {
// //                 var a = r[t];
// //                 255 < a && (this.WEBINA_ASSERTIONS && this.WEBINA_assert(!1, "Character code " + a + " (" + String.fromCharCode(a) + ")  at offset " + t + " not in 0x00-0xFF."), a &= 255), e.push(String.fromCharCode(a))
// //             }
// //             return e.join("")
// //         }
// //     };
// // })();

;// CONCATENATED MODULE: ./src/UI/Tabs/VinaParams.ts
/* provided dependency */ var VinaParams_jQuery = __webpack_require__(755);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.



// declare let Webina;
/** An object containing the vue-component computed functions. */
let VinaParams_computedFunctions = {
    /**
     * Whether to hide the vina docking-box parameters.
     * @returns boolean  True if they should be hidden, false otherwise.
     */
    "hideDockingBoxParams"() {
        return Store_store.state.hideDockingBoxParams;
    },
    /** Whether to show the keep-protein-only link. Has both a getter and a setter. */
    "showKeepProteinOnlyLink": {
        get() {
            return Store_store.state["showKeepProteinOnlyLink"];
        },
        set(val) {
            Store_store.commit("setVar", {
                name: "showKeepProteinOnlyLink",
                val: val
            });
        }
    },
};
/** An object containing the vue-component methods functions. */
let VinaParams_methodsFunctions = {
    /**
     * Runs when user indicates theye want to use example vina input files,
     * rather than provide their own.
     * @returns void
     */
    "useExampleVinaInputFiles"() {
        this["showFileInputs"] = false;
        setTimeout(() => {
            // Update some values.
            Store_store.commit("setVar", {
                name: "receptorContents",
                val: Store_store.state["receptorContentsExample"]
            });
            Store_store.commit("setVar", {
                name: "ligandContents",
                val: Store_store.state["ligandContentsExample"]
            });
            Store_store.commit("setVar", {
                name: "crystalContents",
                val: Store_store.state["crystalContentsExample"]
            });
            Store_store.commit("setVinaParam", {
                name: "center_x",
                val: 41.03
            });
            Store_store.commit("setVinaParam", {
                name: "center_y",
                val: 18.98
            });
            Store_store.commit("setVinaParam", {
                name: "center_z",
                val: 14.03
            });
            Store_store.commit("setVinaParam", {
                name: "size_x",
                val: 20.00
            });
            Store_store.commit("setVinaParam", {
                name: "size_y",
                val: 20.00
            });
            Store_store.commit("setVinaParam", {
                name: "size_z",
                val: 20.00
            });
            // Also update file names so example vina command line is valid.
            Store_store.commit("updateFileName", { type: "ligand", filename: "ligand_example.pdbqt" });
            Store_store.commit("updateFileName", { type: "receptor", filename: "receptor_example.pdbqt" });
            // These values should now validate.
            let validateVars = [
                "receptor", "ligand", "center_x", "center_y", "center_z",
                "size_x", "size_y", "size_z"
            ];
            const validateVarsLen = validateVars.length;
            for (let i = 0; i < validateVarsLen; i++) {
                const validateVar = validateVars[i];
                Store_store.commit("setValidationParam", {
                    name: validateVar,
                    val: true
                });
            }
        }, 100);
    },
    /**
     * Runs when the user presses the submit button.
     * @returns void
     */
    "onSubmitClick"() {
        if (this["validate"]() === true) {
            Store_store.commit("disableTabs", {
                "parametersTabDisabled": true,
                "existingVinaOutputTabDisabled": true,
                "runningTabDisabled": false,
            });
            VinaParams_jQuery("body").addClass("waiting");
            Vue.nextTick(() => {
                Store_store.commit("setVar", {
                    name: "tabIdx",
                    val: 2
                });
                Vue.nextTick(() => {
                    // setTimeout(() => {
                    //     this.afterWASM(this["testVinaOut"], this["testStdOut"]);
                    // }, 1000);
                    // Keep track of start time
                    Store_store.commit("setVar", {
                        name: "time",
                        val: new Date().getTime()
                    });
                    start(Store_store.state["vinaParams"], Store_store.state["receptorContents"], Store_store.state["ligandContents"], 
                    // onDone
                    (outPdbqtFileTxt, stdOut, stdErr) => {
                        Store_store.commit("setVar", {
                            name: "time",
                            val: Math.round((new Date().getTime() - Store_store.state["time"]) / 100) / 10
                        });
                        this.afterWASM(outPdbqtFileTxt, stdOut, stdErr);
                    }, 
                    // onError
                    (errObj) => {
                        // Disable some tabs
                        Store_store.commit("disableTabs", {
                            "parametersTabDisabled": true,
                            "existingVinaOutputTabDisabled": true,
                            "runningTabDisabled": true,
                            "outputTabDisabled": true,
                            "startOverTabDisabled": false
                        });
                        this.showWebinaError(errObj["message"]);
                    }, curPath() + "Webina/");
                });
            });
        }
    },
    /**
     * Opens the draw ligand modal.
     * @param  {*} e  A click event so you can stop the propagation.
     * @returns void
     */
    "onDrawLigClick"(e) {
        Store_store.commit("drawSmilesModal");
        e.preventDefault();
        e.stopPropagation();
    },
    /**
     * Removes residues from protein model that are not protein amino acids.
     * @param  {any} e  The click event.
     * @returns void
     */
    "onShowKeepProteinOnlyClick"(e) {
        let linesToKeep = keepOnlyProteinAtoms(Store_store.state["receptorContents"]);
        Store_store.commit("setVar", {
            name: "receptorContents",
            val: linesToKeep
        });
        Store_store.commit("updateFileName", {
            type: "receptor",
            filename: replaceExt(Store_store.state["receptorFileName"], "protein.pdbqt")
        });
        this["showKeepProteinOnlyLink"] = false;
        e.preventDefault();
        e.stopPropagation();
    },
    /**
     * Determines whether all form values are valid.
     * @param  {boolean=true} modalWarning  Whether to show a modal if
     *                                      they are not valid.
     * @returns boolean  True if they are valid, false otherwise.
     */
    "validate"(modalWarning = true) {
        let validations = Store_store.state["validation"];
        let pass = true;
        const paramName = Object.keys(validations);
        const paramNameLen = paramName.length;
        let badParams = [];
        for (let i = 0; i < paramNameLen; i++) {
            const name = paramName[i];
            if (name === "output") {
                // This one isn't part of the validation.
                continue;
            }
            const valid = validations[name];
            if (valid === false) {
                pass = false;
                badParams.push(name);
            }
        }
        if (pass === false) {
            if (modalWarning === true) {
                Store_store.commit("openModal", {
                    title: "Invalid Parameters!",
                    body: "<p>Please correct the following parameter(s) before continuing: <code>" + badParams.join(" ") + "</code></p>"
                });
            }
        }
        Store_store.commit("setVar", {
            name: "vinaParamsValidates",
            val: pass
        });
        return pass;
    },
    /**
     * Runs after the Vina WASM file is complete.
     * @param  {string} outPdbqtFileTxt  The contents of the Vina output pdbqt file.
     * @param  {string} stdOut           The contents of the Vina standard output.
     * @param  {string} stdErr           The contents of the Vina standard error.
     * @returns void
     */
    afterWASM(outPdbqtFileTxt, stdOut, stdErr) {
        // Disable some tabs
        Store_store.commit("disableTabs", {
            "parametersTabDisabled": true,
            "existingVinaOutputTabDisabled": true,
            "runningTabDisabled": true,
            "outputTabDisabled": false,
            "startOverTabDisabled": false
        });
        // Switch to output tab.
        Store_store.commit("setVar", {
            name: "tabIdx",
            val: 3
        });
        Store_store.commit("setVar", {
            name: "stdOut",
            val: stdOut
        });
        Store_store.commit("setVar", {
            name: "outputContents",
            val: outPdbqtFileTxt
        });
        if (stdErr !== "") {
            this.showWebinaError(stdErr);
        }
        // Process the standard output (extract scores and rmsds) and
        // frames.
        Store_store.commit("outputToData");
        VinaParams_jQuery("body").removeClass("waiting");
    },
    /**
     * Shows a Webina error.
     * @param  {string} message  The error message.
     * @returns void
     */
    showWebinaError(message) {
        Store_store.commit("openModal", {
            title: "Webina Error!",
            body: "<p>Webina returned the following error: <code>" + message + "</code></p>"
        });
    }
};
/**
 * The vue-component mounted function.
 * @returns void
 */
function VinaParams_mountedFunction() {
    // @ts-ignore
    this["webAssemblyAvaialble"] = webAssemblySupported();
}
/**
 * Setup the vina-params Vue commponent.
 * @returns void
 */
function VinaParams_setup() {
    Vue.component('vina-params', {
        "template": `
            <div>
                <b-form v-if="webAssemblyAvaialble">
                    <b-card
                        class="mb-2 text-center"
                        style="margin-bottom:1.4rem !important;"
                    >
                        <b-card-text>
                            Use this tab to setup a Webina job in your browser.
                            Specify the input files and Vina parameters below.
                        </b-card-text>
                    </b-card>

                    <sub-section title="Input (PDBQT) Files" v-if="showFileInputs">
                        <file-input
                            label="Receptor"
                            id="receptor"
                            description="Formats: PDBQT (best), PDB, ENT, XYZ, PQR, MCIF, MMCIF. If PDB, be sure to add polar hydrogen atoms."
                            accept=".pdbqt" convert=".pdb, .ent, .xyz, .pqr, .mcif, .mmcif"
                        >
                            <template v-slot:extraDescription>
                                <span v-if="showKeepProteinOnlyLink">
                                    <a href='' @click="onShowKeepProteinOnlyClick($event);">Automatically remove all non-protein atoms?</a>
                                </span>
                                <span v-else>
                                    <b>(Removed all non-protein atoms!)</b>
                                </span>
                            </template>
                        </file-input>

                        <file-input
                            label="Ligand"
                            id="ligand"
                            description="Formats: PDBQT (best), CAN, MDL, MOL, MOL2, PDB, SD, SDF, SMI, SMILES, XYZ,"
                            accept=".pdbqt" convert=".can, .mdl, .mol, .mol2, .pdb, .sd, .sdf, .smi, .smiles, .xyz"
                        >
                            <template v-slot:extraDescription>or <a href='' @click="onDrawLigClick($event);">draw your ligand</a>. We recommend preparing ligand files separately with <a target='_blank' href='https://git.durrantlab.pitt.edu/jdurrant/gypsum_dl'>Gypsum-DL</a>.</template>
                        </file-input>

                        <file-input
                            label="Correct Pose"
                            id="crystal"
                            :required="false"
                            description="The correct ligand pose, if known from experiment. This PDBQT or PDB file is optional."
                            accept=".pdbqt, .pdb"
                        ></file-input>

                        <form-button @click.native="useExampleVinaInputFiles" cls="float-right">Use Example Files</form-button>  <!-- variant="default" -->
                    </sub-section>

                    <sub-section title="Docking Box">
                        <form-group
                            label=""
                            id="input-group-receptor-3dmol"
                            description=""
                        >
                            <div class="bv-example-row container-fluid">
                                <b-row>
                                    <b-col style="padding-left: 0; padding-right: 10px;">
                                        <threedmol type="receptor"></threedmol>
                                    </b-col>
                                    <b-col style="padding-right: 0; padding-left: 10px;">
                                        <threedmol type="ligand"></threedmol>
                                    </b-col>
                                </b-row>
                            </div>
                        </form-group>

                        <triple-numeric-input
                            :hide="hideDockingBoxParams"
                            label="Box Center"
                            id1="center_x"
                            id2="center_y"
                            id3="center_z"
                            description="X, Y, and Z coordinates of the docking-box center."
                        ></triple-numeric-input>

                        <triple-numeric-input
                            :hide="hideDockingBoxParams"
                            label="Box Size"
                            id1="size_x"
                            id2="size_y"
                            id3="size_z"
                            description="Size of docking box in the X, Y, and Z dimensions (Angstroms)."
                            :min="0"
                        ></triple-numeric-input>
                    </sub-section>

                    <sub-section title="Other Critical Parameters">
                        <numeric-input
                            label="CPU(s)" id="cpu"
                            description="The number of CPUs to use. Leave a few CPUs free to maintain computer responsiveness."
                            placeholder="${navigator.hardwareConcurrency <= 2 ? 1 : 2}"
                            :default="${navigator.hardwareConcurrency <= 2 ? 1 : 2}"
                            :min="1"
                            :max="${navigator.hardwareConcurrency == 1 ? 1 : navigator.hardwareConcurrency - 1}"
                        ></numeric-input>

                        <numeric-input
                            label="Exhaustiveness" id="exhaustiveness"
                            description="Exhaustiveness of the global search (roughly proportional to time). Webina defaults to 4 to speed execution in the browser, but the Vina default is 8. Use 8 when accuracy is critical."
                            placeholder="8"
                            :default="8"
                            :min="1"
                        ></numeric-input>
                    </sub-section>

                    <sub-section title="Advanced Parameters">
                        <div role="tablist">
                            <b-card no-body class="mb-1">
                                <b-card-header header-tag="header" class="p-1" role="tab">
                                    <b-button block href="#" v-b-toggle.accordion-2 variant="default">Output  Parameters (Optional)</b-button>
                                </b-card-header>
                                <b-collapse id="accordion-2" role="tabpanel">
                                    <b-card-body>
                                        <b-card
                                            class="mb-2 text-center"
                                            style="margin-bottom:1.4rem !important;"
                                        >
                                            <b-card-text>
                                                Optional parameters to control Webina output.
                                            </b-card-text>
                                        </b-card>

                                        <check-box
                                            label="Perform a local search only." id="local_only"
                                        ></check-box>
                                        <check-box
                                            label="Score only, without docking. Docking-box center and size will be ignored."
                                            id="score_only"
                                        ></check-box>
                                        <check-box
                                            label="Randomize input, attempting to avoid clashes."
                                            id="randomize_only"
                                        ></check-box>
                                    </b-card-body>
                                </b-collapse>
                            </b-card>

                            <b-card no-body class="mb-1">
                                <b-card-header header-tag="header" class="p-1" role="tab">
                                    <b-button block href="#" v-b-toggle.accordion-3 variant="default">Misc Parameters (Optional)</b-button>
                                </b-card-header>
                                <b-collapse id="accordion-3" role="tabpanel">
                                    <b-card-body>
                                        <b-card
                                            class="mb-2 text-center"
                                            style="margin-bottom:1.4rem !important;"
                                        >
                                            <b-card-text>
                                                Advanced parameters that are best left unmodified.
                                            </b-card-text>
                                        </b-card>
                                        <numeric-input
                                            label="Random Seed" id="seed"
                                            description="The explicit random seed."
                                            placeholder="${new Date().getTime()}"
                                            :min="1"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Number of Modes" id="num_modes"
                                            description="Maximum number of binding modes to generate."
                                            placeholder="9"
                                            :min="1"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Energy Range" id="energy_range"
                                            description="Maximum energy difference between the best binding mode and the worst one displayed (kcal/mol)."
                                            placeholder="3"
                                            :min="0"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Gauss_1 Weight" id="weight_gauss1"
                                            description="Gauss_1 weight."
                                            placeholder="-0.035579"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Gauss2 Weight" id="weight_gauss2"
                                            description="Gauss_1 weight term."
                                            placeholder="-0.005156"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Repulsion Weight"
                                            id="weight_repulsion"
                                            description="Repulsion weight term."
                                            placeholder="0.84024500000000002"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Hydrophobic Weight"
                                            id="weight_hydrophobic"
                                            description="Hydrophobic weight term."
                                            placeholder="-0.035069000000000003"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Hydrogen Weight"
                                            id="weight_hydrogen"
                                            description="Hydrogen bond weight term."
                                            placeholder="-0.58743900000000004"
                                        ></numeric-input>

                                        <numeric-input
                                            label="Rot Weight" id="weight_rot"
                                            description="N_rot weight term."
                                            placeholder="0.058459999999999998"
                                        ></numeric-input>
                                    </b-card-body>
                                </b-collapse>
                            </b-card>
                        </div>
                    </sub-section>

                    <vina-commandline></vina-commandline>

                    <span style="display:none;">{{validate(false)}}</span>  <!-- Hackish. Just to make reactive. -->
                    <form-button @click.native="onSubmitClick" variant="primary" cls="float-right mb-4">Start Webina</form-button>

                </b-form>
                <div v-else>
                    <p>Unfortunately, your browser does not support WebAssembly.
                    Please <a href='https://developer.mozilla.org/en-US/docs/WebAssembly#Browser_compatibility'
                    target='_blank'>switch to a browser that does</a> (e.g., Google Chrome).</p>

                    <p>Note that you can still use the "Existing Vina Output" option
                    (see menu on the left) even without WebAssembly.</p>
                </div>
            </div>
        `,
        "props": {},
        "computed": VinaParams_computedFunctions,
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {
                "showFileInputs": true,
                "webAssemblyAvaialble": true
            };
        },
        "methods": VinaParams_methodsFunctions,
        /**
         * Runs when the vue component is mounted.
         * @returns void
         */
        "mounted": VinaParams_mountedFunction
    });
}

;// CONCATENATED MODULE: ./src/UI/Tabs/VinaRunning.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/**
 * Setup the vina-running Vue commponent.
 * @returns void
 */
function VinaRunning_setup() {
    Vue.component('vina-running', {
        "template": `
            <div class="text-center">
                <b-spinner style="width: 4rem; height: 4rem;" label="Working"></b-spinner>
                <br /><br />
                <p>Running Webina in your browser. Docking may take some minutes.</p>
                <p>This page may become unresponsive while performing calculations.
                   Need to stop Webina but can't close this tab? Use your browser or
                   operating-system Task Manager.</p>
            </div>
        `,
        "props": {},
        "computed": {},
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {
                "msg": "",
                msgIdx: 0
            };
        },
        "methods": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/Tabs/VinaOutput.ts
/* provided dependency */ var FileSaver = __webpack_require__(162);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let VinaOutput_computedFunctions = {
    /**
     * Get's Vina's standard output.
     * @returns string  The standard output.
     */
    "stdOut"() {
        return Store_store.state["stdOut"];
    },
    /**
     * Get's Vina's output file.
     * @returns string  The output file.
     */
    "outputContents"() {
        return Store_store.state["outputContents"];
    },
    /**
     * Get the execution time.
     * @returns string  The time.
     */
    "time"() {
        return Store_store.state["time"].toString();
    }
};
/** An object containing the vue-component methods functions. */
let VinaOutput_methodsFunctions = {
    /**
     * Runs when the user clicks the stdout download button.
     * @returns void
     */
    "stdOutDownload"() {
        const blob = new Blob([this["stdOut"]], { type: "text/plain;charset=utf-8" });
        FileSaver.saveAs(blob, "stdout.txt");
    },
    /**
     * Runs when the user clicks the download output button.
     * @returns void
     */
    "vinaOutputContentsDownload"() {
        const blob = new Blob([this["outputContents"]], { type: "text/plain;charset=utf-8" });
        FileSaver.saveAs(blob, "webina_out.pdbqt");
    }
};
/**
 * Setup the vina-output Vue commponent.
 * @returns void
 */
function VinaOutput_setup() {
    Vue.component('vina-output', {
        "template": `
            <div>
                <sub-section title="Visualization">
                    <form-group
                        label=""
                        id="input-group-receptor-3dmol"
                        description=""
                    >
                        <threedmol :autoLoad="true" type="docked" :proteinSurface="true"></threedmol>
                    </form-group>
                    <results-table></results-table>
                    <p class="text-center mb-0">Execution time: {{time}} seconds</p>
                </sub-section>

                <sub-section title="Output Files">
                    <form-group v-if="stdOut !== ''"
                        label="Standard Output"
                        id="input-group-standard-output"
                        description="Webina's standard output, including the docking scores and RMSD values."
                        :labelToLeft="false"
                    >
                        <b-form-textarea
                            readonly
                            id="textarea"
                            v-model="stdOut"
                            placeholder="Standard Output"
                            rows="3"
                            max-rows="6"
                            style="white-space: pre;"
                            class="text-monospace"
                            size="sm"
                        ></b-form-textarea>
                        <form-button :small="true" @click.native="stdOutDownload">Download</form-button>
                    </form-group>

                    <form-group
                        label="Output PDBQT File"
                        id="input-group-standard-output"
                        description="Webina's output file with the docked ligand poses."
                        :labelToLeft="false"
                    >
                        <b-form-textarea
                            readonly
                            id="textarea"
                            v-model="outputContents"
                            placeholder="Standard Output"
                            rows="3"
                            max-rows="6"
                            style="white-space: pre;"
                            class="text-monospace"
                            size="sm"
                        ></b-form-textarea>
                        <form-button :small="true" @click.native="vinaOutputContentsDownload">Download</form-button>
                    </form-group>
                </sub-section>

                <vina-commandline></vina-commandline>
            </div>
        `,
        "props": {},
        "computed": VinaOutput_computedFunctions,
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {};
        },
        "methods": VinaOutput_methodsFunctions
    });
}

;// CONCATENATED MODULE: ./src/UI/Tabs/VinaExistingOutput.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component methods functions. */
let VinaExistingOutput_methodsFunctions = {
    /**
     * Runs when the user indicates he or she wants to use example
     * output files rather than provide their own.
     * @returns void
     */
    "useExampleOutputFiles"() {
        // These values should now validate.
        let validateVars = ["receptor", "output"];
        const validateVarsLen = validateVars.length;
        for (let i = 0; i < validateVarsLen; i++) {
            const validateVar = validateVars[i];
            // @ts-ignore
            Store_store.commit("setValidationParam", {
                name: validateVar,
                val: true
            });
        }
        let promise = new Promise((resolve, reject) => {
            setTimeout(() => {
                Store_store.commit("setVar", {
                    name: "receptorContents",
                    val: Store_store.state["receptorContentsExample"]
                });
                Store_store.commit("setVar", {
                    name: "outputContents",
                    val: Store_store.state["outputContentsExample"]
                });
                Store_store.commit("setVar", {
                    name: "crystalContents",
                    val: Store_store.state["crystalContentsExample"]
                });
                resolve(undefined);
            }, 100);
        });
        this["onSubmitClick"](null, promise);
    },
    /**
     * Runs when the user clicks the submit button.
     * @param  {any}                    e        Not sure what this
     *                                           is.
     * @param  {Promise<any>=undefined} promise  A promise to continue
     *                                           from.
     * @returns void
     */
    "onSubmitClick"(e, promise = undefined) {
        if (this["validate"]() === true) {
            // Disable some tabs
            Store_store.commit("disableTabs", {
                "parametersTabDisabled": true,
                "runningTabDisabled": true,
                "existingVinaOutputTabDisabled": true,
                "outputTabDisabled": false,
                "startOverTabDisabled": false
            });
            // Switch to that tab.
            Vue.nextTick(() => {
                Store_store.commit("setVar", {
                    name: "tabIdx",
                    val: 3
                });
                if (promise !== undefined) {
                    promise.then(() => {
                        Store_store.commit("outputToData");
                    });
                }
                else {
                    Store_store.commit("outputToData");
                }
            });
        }
    },
    /**
     * Determines whether valid parameters have been provided.
     * Otherwise, cannot display the mock Vina output.
     * @returns boolean  True if everything is valid, false otherwise.
     */
    "validate"() {
        let validations = Store_store.state["validation"];
        let badParams = [];
        if (validations["receptor"] === false) {
            badParams.push("receptor");
        }
        if (validations["output"] === false) {
            badParams.push("output");
        }
        let validate = badParams.length === 0;
        if (validate === false) {
            Store_store.commit("openModal", {
                title: "Invalid Parameters!",
                body: "<p>Please correct the following parameter(s) before continuing: <code>" + badParams.join(" ") + "</code></p>"
            });
        }
        return validate;
    },
};
/**
 * Setup the vina-existing-output Vue commponent.
 * @returns void
 */
function VinaExistingOutput_setup() {
    Vue.component('vina-existing-output', {
        "template": `
            <b-form>
                <b-card
                    class="mb-2 text-center"
                    style="margin-bottom:1.4rem !important;"
                >
                    <b-card-text>
                        Use this tab if you've already run Webina or Vina and
                        have an existing docked-ligand PDBQT output file.
                    </b-card-text>
                </b-card>

                <sub-section title="Existing Output Files">
                    <file-input
                        label="Receptor"
                        id="receptor"
                        description="The rigid part of the receptor (PDBQT or PDB)."
                        accept=".pdbqt, .pdb"
                    ></file-input>

                    <file-input
                        label="Docked Output"
                        id="output"
                        description="The Webina/Vina output file (PDBQT, OUT, VINA, or TXT) containing docked ligand poses."
                        accept=".pdbqt, .out, .vina, .txt"
                    ></file-input>

                    <file-input
                        label="Correct Pose"
                        id="crystal"
                        :required="false"
                        description="The correct ligand pose, if known from experiment. This PDBQT or PDB file is optional."
                        accept=".pdbqt, .pdb"
                    ></file-input>
                </sub-section>

                <form-button cls="float-right mb-4" @click.native="onSubmitClick" variant="primary">Load Files</form-button>
                <form-button @click.native="useExampleOutputFiles" cls="float-right mr-2">Use Example Files</form-button>
            </b-form>
        `,
        "props": {},
        "computed": {},
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {};
        },
        "methods": VinaExistingOutput_methodsFunctions
    });
}

;// CONCATENATED MODULE: ./src/UI/Tabs/StartOver.ts
/* provided dependency */ var StartOver_jQuery = __webpack_require__(755);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/** An object containing the vue-component methods functions. */
let StartOver_methodsFunctions = {
    /**
     * Runs when the start-over button is clicked.
     * @returns void
     */
    "onSubmitClick"() {
        StartOver_jQuery("body").addClass("waiting");
        location.reload();
    }
};
/**
 * Setup the start-over Vue commponent.
 * @returns void
 */
function StartOver_setup() {
    Vue.component('start-over', {
        "template": `
            <div class="text-center">
                <b-alert show variant="warning">If you start over, your existing data will be deleted. Proceed only if you have already saved your data using the "Download" button(s) in the "Output" tab.</b-alert>
                <form-button @click.native="onSubmitClick" variant="primary">Start Over</form-button>
            </div>
        `,
        "props": {},
        "computed": {},
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {};
        },
        "methods": StartOver_methodsFunctions
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/FormGroup.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/** An object containing the vue-component computed functions. */
let FormGroup_computedFunctions = {
    /**
     * Determines whether this component has a label.
     * @returns boolean  True if it does, false otherwise.
     */
    hasLabel() {
        return this["label"] !== "" && this["label"] !== undefined;
    },
    /**
     * Determines if label should be placed to the left or above.
     * @returns number  Returns 3 if it has a label, 0 otherwise.
     */
    "labelCols"() {
        // @ts-ignore
        return ((this.hasLabel === true) && (this["labelToLeft"] === true)) ? 3 : 0;
    },
    /**
     * Determines if label should be placed to the left or above.
     * @returns number  Returns 2 if it has a label, 0 otherwise.
     */
    "labelColsLg"() {
        // @ts-ignore
        return ((this.hasLabel === true) && (this["labelToLeft"] === true)) ? 2 : 0;
    }
};
/**
 * Setup the form-group Vue commponent.
 * @returns void
 */
function FormGroup_setup() {
    Vue.component('form-group', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": FormGroup_computedFunctions,
        "template": `
            <span>
                <b-form-group
                    v-if="formGroupWrapper"
                    :label-cols="labelCols" :label-cols-lg="labelColsLg"
                    :label="label"
                    :label-for="id"
                    :id="'input-group-' + id"
                    :style="styl"
                >
                    <slot></slot>
                    <small
                        tabindex="-1"
                        :id="'input-group-input-group-' + id + '__BV_description_'"
                        class="form-text text-muted" style="display:inline;"
                        v-html="description">
                    </small>
                    <small class="form-text text-muted" style="display:inline;">
                        <slot name="extraDescription"></slot>
                    </small>
                </b-form-group>
                <div v-else>
                    <slot></slot>
                </div>
            </span>
        `,
        "props": {
            "label": String,
            "id": String,
            "styl": String,
            "description": String,
            "formGroupWrapper": {
                "type": Boolean,
                "default": true
            },
            "labelToLeft": {
                "type": Boolean,
                "default": true
            }
        },
        "methods": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/TripleNumeric.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/**
 * Setup the triple-numeric-input Vue commponent.
 * @returns void
 */
function TripleNumeric_setup() {
    Vue.component('triple-numeric-input', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": {},
        "template": `
            <form-group
                :label="label"
                :id="'input-group-' + id1 + '-' + id2 + '-' + id3"
                :style="styl"
                :description="description"
                v-if="!hide"
            >
                <div class="bv-example-row container-fluid">
                    <b-row>
                        <b-col style="padding-left: 0;">
                            <numeric-input
                                :id="id1"
                                description=""
                                placeholder="Missing X value..."
                                required
                                :formGroupWrapper="false"
                                :min="min"
                            ></numeric-input>
                        </b-col>

                        <b-col style="">
                            <numeric-input
                                :id="id2"
                                description=""
                                placeholder="Missing Y value..."
                                required
                                :formGroupWrapper="false"
                                :min="min"
                            ></numeric-input>
                        </b-col>

                        <b-col style="padding-right: 0;">
                            <numeric-input
                                :id="id3"
                                description=""
                                placeholder="Missing Z value..."
                                required
                                :formGroupWrapper="false"
                                :min="min"
                            ></numeric-input>
                        </b-col>
                    </b-row>
                </div>

            </form-group>
        `,
        "props": {
            "hide": Boolean,
            "label": String,
            "id1": String,
            "id2": String,
            "id3": String,
            "styl": String,
            "description": String,
            "min": {
                "type": Number,
                "default": undefined
            }
        },
        "methods": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/ResultsTable.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let ResultsTable_computedFunctions = {
    /**
     * Gets the items in the results table.
     * @returns any[]  The array of items.
     */
    "items"() {
        // let data = [[[1,48.4,0,0],"HETATM    1  C"],[[1,48.4,0,0],"HETATM    1  C"],[[1,48.4,0,0],"HETATM    1  C"]];  //store.state["pdbOutputFrames"];
        let data = Store_store.state["pdbOutputFrames"];
        const dataLen = data.length;
        let items = [];
        let errorDetected = false;
        for (let i = 0; i < dataLen; i++) {
            const dataItem = data[i][0]; // The info about RMSD and such.
            if (dataItem !== undefined) {
                items.push({
                    "mode": dataItem[0],
                    "affinity (kcal/mol)": dataItem[1],
                    "dist from rmsd L.B.": dataItem[2],
                    "dist from rmsd U.B.": dataItem[3]
                });
            }
            else {
                // The pdbqt didn't have this meta information.
                errorDetected = true;
                items.push({
                    "mode": "---",
                    "affinity (kcal/mol)": "---",
                    "dist from rmsd L.B.": "---",
                    "dist from rmsd U.B.": "---",
                });
            }
        }
        if (errorDetected === true) {
            Store_store.commit("openModal", {
                title: "Output File Invalid!",
                body: "<p>The output PDBQT file does not appear to be properly formatted.</p>"
            });
        }
        return items;
    },
    /**
     * Get's the field descriptions of each item in the results list.
     * @returns any[]  A list of the field descriptions.
     */
    "fields"() {
        return [
            {
                "key": "mode"
            },
            {
                "key": "affinity (kcal/mol)"
            },
            {
                "key": "dist from rmsd L.B."
            },
            {
                "key": "dist from rmsd U.B."
            }
        ];
    }
};
/** An object containing the vue-component methods functions. */
let ResultsTable_methodsFunctions = {
    /**
     * Runs when the table row is clicked. Updates visualization.
     * @param  {any}    data  Not used.
     * @param  {number} idx   The index of the clicked row.
     * @returns void
     */
    "rowClicked"(data, idx) {
        let ligPDBTxt = Store_store.state["pdbOutputFrames"][idx][1];
        Store_store.commit("setVar", {
            name: "dockedContents",
            val: ligPDBTxt
        });
    }
};
/**
 * Setup the results-table Vue commponent.
 * @returns void
 */
function ResultsTable_setup() {
    Vue.component('results-table', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": ResultsTable_computedFunctions,
        "template": `
            <b-table
                striped hover small
                :items="items"
                :fields="fields"
                @row-clicked="rowClicked">
            </b-table>
        `,
        "props": {},
        "methods": ResultsTable_methodsFunctions
    });
}

;// CONCATENATED MODULE: ./src/UI/Modal/OpenModal.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/** An object containing the vue-component computed functions. */
let OpenModal_computedFunctions = {
    /** The visibility (boolean, open/closed) of the modal. Can both get and
     * set. */
    "modalShow": {
        get() {
            // @ts-ignore
            return store.state["modalShow"];
        },
        set(val) {
            // @ts-ignore
            store.commit("setVar", {
                name: "modalShow",
                val
            });
        }
    },
    /**
     * Gets the modal title.
     * @returns string  The title.
     */
    "title"() {
        // @ts-ignore
        return store.state["modalTitle"];
    },
    /**
     * Get's the modal body.
     * @returns string  The body.
     */
    "body"() {
        // @ts-ignore
        return store.state["modalBody"];
    }
};
/**
 * Setup the open-modal Vue commponent.
 * @returns void
 */
function OpenModal_setup() {
    Vue.component('open-modal', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": OpenModal_computedFunctions,
        "template": `
            <b-modal ok-only :size="size" ok-title="Close" v-model="modalShow" id="msg-modal" :title="title">
                <p class="my-4" v-html="body"><slot></slot></p>
            </b-modal>
        `,
        "props": {
            "size": {
                "type": String,
                "default": "lg" // could also be xl and sm
            }
        }
    });
}

;// CONCATENATED MODULE: ./src/UI/Modal/ConvertFileModal.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.


/** An object containing the vue-component computed functions. */
let ConvertFileModal_computedFunctions = {
    /** The visibility (boolean, open/closed) of the convert file modal. Can
     * both get and set. */
    "convertFileModalShow": {
        get() {
            return Store_store.state["convertFileModalShow"];
        },
        set(val) {
            Store_store.commit("setVar", {
                name: "convertFileModalShow",
                val,
            });
        },
    },
    /**
     * Get the extension of the user-submitted file.
     * @returns string The extension.
     */
    "currentExt"() {
        return Store_store.state["convertFileExt"].toUpperCase();
    },
    /**
     * Get the current type of the user-submitted file. "receptor" or
     * "ligand".
     * @returns string The type.
     */
    "currentType"() {
        return Store_store.state["convertFileType"];
    },
    /**
     * Determine whether 3D coordinates must be generated, given the file
     * extension. If they are required regardless, don't give the user the
     * option.
     * @returns boolean  True if generating 3D coordinates is required.
     */
    "gen3DRequired"() {
        if (["CAN", "SMI", "SMILES"].indexOf(this["currentExt"]()) !== -1) {
            // It's one of the formats that always required that 3D
            // coordinates be generated.
            this["gen3D"] = true;
            return true;
        }
        return false;
    }
};
/** An object containing the vue-component methods functions. */
let ConvertFileModal_methodsFunctions = {
    /**
     * Begin to convert the file to PDBQT.
     * @param  {*}      e                              The click event.
     * @param  {number=1} currentPDBOptimizationLevel  To what extent the PDB
     *                                                 file should be
     *                                                 optimized (to keep size
     *                                                 low for converting).
     * @param  {string[]} successMsgs                  The messages to display
     *                                                 to the user on success
     *                                                 (if any).
     * @returns void
     */
    "beginConvert"(e, currentPDBOptimizationLevel = 1, successMsgs = []) {
        let frameWindow = document.getElementById("convert-frame")["contentWindow"];
        frameWindow["startSpinner"]();
        let content = Store_store.state["convertFile"];
        while (content.substr(content.length - 1, 1) === "\n") {
            content = content.substr(0, content.length - 1);
        }
        if (this["currentExt"]().toUpperCase() === "PDB") {
            let msg = this.pdbOptimization(currentPDBOptimizationLevel);
            if (msg !== "") {
                successMsgs.push(msg);
            }
        }
        if (this["currentType"] !== "ligand") {
            // If it's not a ligand, there's no need to generate 3D
            // coordinates.
            this["gen3D"] = false;
        }
        const html = frameWindow.document.querySelector("html");
        if (html === null) {
            throw new Error("Could not find html element in convert frame.");
        }
        html.style.overflow = "hidden";
        frameWindow["PDBQTConvert"]["convert"](content, this["currentExt"]().toLowerCase(), this["currentType"] === "ligand", this["addHydrogens"], this["gen3D"], parseFloat(this["phVal"])).then((out) => {
            Store_store.commit("setVar", {
                name: this["currentType"] + "Contents",
                val: out
            });
            this["$refs"]["convert-modal"].hide();
            // This makes it look like it validated.
            Store_store.commit("setVar", {
                name: this["currentType"] + "ForceValidate",
                val: true
            });
            // This actually sets the validation.
            Store_store.commit("setValidationParam", {
                name: this["currentType"],
                val: true
            });
            // Update the filename to end in pdbqt.
            let newFilename = replaceExt(Store_store.state[this["currentType"] + "FileName"], "converted.pdbqt");
            Store_store.commit("updateFileName", { type: this["currentType"], filename: newFilename });
            if (successMsgs.length !== 0) {
                let overallMsg = successMsgs.map((m, i) => { return "(" + (i + 1).toString() + ") " + m; }).join(" ");
                this["$bvModal"]["msgBoxOk"]("To convert your file to PDBQT, Webina had to make the following modifications: " + overallMsg, {
                    "title": "Warning: File Too Big!",
                });
            }
        }).catch((msg) => {
            // The conversion failed. But if it's a PDB file, it might be
            // worth trying to optimize it further.
            if (currentPDBOptimizationLevel <= 4) { // one less than max number in pdbOptimization.
                this["beginConvert"](e, currentPDBOptimizationLevel + 1, successMsgs);
                return;
            }
            this["$refs"]["convert-modal"].hide();
            this["$bvModal"]["msgBoxOk"]("Could not convert your file. Are you sure it is a properly formatted " + this["currentExt"]() + " file? If so, it may be too large to convert in the browser.", {
                "title": "Error Converting File!",
            });
            Store_store.commit("setVar", {
                name: this["currentType"] + "ForceValidate",
                val: false
            });
            Store_store.commit("updateFileName", { type: this["currentType"], filename: "" });
            console.log("ERROR: " + msg);
        });
        e.preventDefault();
    },
    /**
     * PDB files are very common, yet openbabel.js cannot convert them if they
     * are too large. Here we make efforts to "optimize" the PDB file to
     * maximize the changes that openbabel.js will succeed.
     * @param  {number} level  The optimization level.
     * @returns string  A message to show the user re. any modifications made
     *                  to the PDB file.
     */
    pdbOptimization(level) {
        let pdbTxt = Store_store.state["convertFile"];
        let msg = "";
        switch (level) {
            case 1:
                // Always run this optimization. Just removes lines that don't
                // start with ATOM and HETATM. Also keeps only the first frame
                // if it's a multi-frame PDB.
                if (pdbTxt.indexOf("\nEND") !== -1) {
                    // Perhaps a multi-frame PDB.
                    pdbTxt = pdbTxt.split("\nEND")[0];
                    msg = "Keep only the first frame.";
                }
                pdbTxt = pdbTxt.split("\n").filter((l) => l.slice(0, 5) === "ATOM " || l.slice(0, 7) === "HETATM ").join("\n");
                break;
            case 2:
                // Try removing everything but protein atoms.
                pdbTxt = keepOnlyProteinAtoms(pdbTxt);
                msg = "Discard non-protein atoms.";
                break;
            case 3:
                // Keep only the first chain.
                let chain = pdbTxt.slice(21, 22); // first chain
                pdbTxt = pdbTxt.split("\n").filter((l) => l.slice(21, 22) === chain).join("\n");
                msg = "Keep only the first chain (chain " + chain + ").";
                break;
            case 4:
                // Remove existing hydrogen atoms.
                pdbTxt = pdbTxt.split("\n").filter((l) => l.substr(12, 4).replace(/ /g, "").substr(0, 1) !== "H").join("\n");
                msg = "Remove original hydrogen atoms.";
                break;
            case 5:
                // Remove beta, occupancy, etc. columns.
                pdbTxt = pdbTxt.split("\n").map((l) => l.substr(0, 54)).join("\n");
                msg = "Remove original occupancy, beta, and element columns.";
                break;
        }
        // console.log("HHHHH>>> " + msg + " >>>> " + pdbTxt.length.toString());
        Store_store.commit("setVar", {
            name: "convertFile",
            val: pdbTxt
        });
        return msg;
    },
    /**
     * The cancel button is pressed.
     * @returns void
     */
    "cancelPressed"() {
        // Not sure the below is really necessary, but let's just make
        // sure.
        Store_store.commit("setVar", {
            name: this["currentType"] + "FileName",
            val: undefined
        });
        Store_store.commit("setValidationParam", {
            name: this["currentType"],
            val: false
        });
        Store_store.commit("updateFileName", { type: this["currentType"], filename: "" });
    },
    /**
     * Reload the iframe containing the PDBConvert app.
     * @returns void
     */
    "reloadIFrame"() {
        document.getElementById("convert-frame")["src"] = "./pdbqt_convert/index.html?startBlank";
    }
};
/**
 * Setup the convert-file-modal Vue commponent.
 * @returns void
 */
function ConvertFileModal_setup() {
    Vue.component("convert-file-modal", {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {
                "addHydrogens": true,
                "gen3D": false,
                "phVal": 7.4
            };
        },
        "computed": ConvertFileModal_computedFunctions,
        "methods": ConvertFileModal_methodsFunctions,
        "template": `
            <b-modal
              ref="convert-modal"
              @shown="reloadIFrame"
              ok-title="Convert" v-model="convertFileModalShow"
              id="convert-msg-modal" title="Convert File to PDBQT"
              @ok="beginConvert" @cancel="cancelPressed">
                <p class="my-4">
                    Webina works with PDBQT files, not {{currentExt}} files. We suggest you:
                    <span v-if="this['currentType']==='receptor'">
                        <ol>
                            <li>Add hydrogen atoms using <a href="http://www.poissonboltzmann.org/" target="_blank">PDB2PQR</a></li>
                            <li>Convert the resulting PQR file to PDB using <a href="http://openbabel.org/wiki/Main_Page" target="_blank">Open Babel</a></li>
                            <li>Convert the PDB file to PDBQT using <a target='_blank' href='http://mgltools.scripps.edu/'>MGLTools</a></li>
                        </ol>
                    </span>
                    <span v-else-if="this['currentType']==='ligand'">
                        <ol>
                            <li>Add hydrogen atoms to your ligand files (SMILES or SDF format) using <a target='_blank' href='https://git.durrantlab.pitt.edu/jdurrant/gypsum_dl'>Gypsum-DL</a></li>
                            <li>Convert the resulting PDB or SDF file(s) to PDBQT using <a target='_blank' href='http://mgltools.scripps.edu/'>MGLTools</a></li>
                        </ol>
                    </span>
                </p>

                <p>Or click "Convert" below to convert with the PDBQTConvert app, which should be good enough for most purposes.</p>

                <b-form-checkbox
                    id="babel-add-hydrogens"
                    v-model="addHydrogens"
                    name="babel-add-hydrogens"
                    :value="true"
                    :unchecked-value="false"
                >
                    Add hydrogen atoms at pH
                    <b-form-input
                        id="ph-val"
                        v-model="phVal"
                        type="text"
                        placeholder="7.4"
                        class="form-control-sm"
                        @click.stop.prevent
                        style="width: 45px; height: 23px; text-align: center; margin-left: 2px; display: inline-block;"
                    ></b-form-input>
                </b-form-checkbox>

                <b-form-checkbox
                    v-if="(this['currentType']==='ligand') && (!gen3DRequired)"
                    id="babel-gen-3d"
                    v-model="gen3D"
                    name="babel-gen-3d"
                    :value="true"
                    :unchecked-value="false"
                >
                    Generate 3D coordinates.
                </b-form-checkbox>

                <iframe id="convert-frame" style="border: 0; width: 100%; height: 65px;"></iframe>

                <small class="form-text text-muted">
                    PDBQTConvert is an optional GPL-licensed helper app
                    built on <a
                    href="https://github.com/partridgejiang/cheminfo-to-web/tree/master/OpenBabel/OpenBabel-js" target="_blank">
                    OpenBabel JS</a>. It communicates with Webina at "arms
                    length" via an iframe.
                </small>
            </b-modal>`,
        "props": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/Modal/DrawSmilesModal.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let DrawSmilesModal_computedFunctions = {
    /** The visibility (boolean, open/closed) of the draw smiles modal. Can
     * both get and set. */
    "drawSmilesModalShow": {
        get() {
            // @ts-ignore
            return Store_store.state["drawSmilesModalShow"];
        },
        set(val) {
            // @ts-ignore
            Store_store.commit("setVar", {
                name: "drawSmilesModalShow",
                val
            });
        }
    },
};
/** An object containing the vue-component methods functions. */
let DrawSmilesModal_methodsFunctions = {
    "startConversion"() {
        // Get smiles from widget
        let frameWindow = document.getElementById("draw-widget")["contentWindow"];
        // @ts-ignore
        let smiles = frameWindow["getSmiles"]();
        Store_store.commit("setVar", {
            name: "convertFileExt",
            val: "smi"
        });
        Store_store.commit("setVar", {
            name: "convertFileType",
            val: "ligand"
        });
        Store_store.commit("setVar", {
            name: "convertFile",
            val: smiles
        });
        Store_store.commit("setVar", {
            name: "convertFileModalShow",
            val: true
        });
        Store_store.commit("setVar", {
            name: "ligandFileName",
            val: "drawn_ligand.pdbqt"
        });
    }
};
/**
 * Setup the draw-smiles-modal Vue commponent.
 * @returns void
 */
function DrawSmilesModal_setup() {
    /** Test */
    Vue.component('draw-smiles-modal', {
        /** Computed */
        "computed": DrawSmilesModal_computedFunctions,
        "methods": DrawSmilesModal_methodsFunctions,
        "data"() {
            return {};
        },
        "template": `
            <b-modal
              size="xl" ok-title="Convert to PDBQT" v-model="drawSmilesModalShow"
              id="draw-structure-modal" title="Draw Ligand Structure"
              @ok="startConversion">
                <p class="my-4">
                    <iframe id="draw-widget" style="border:0; width:100%; height:350px; margin-left:auto; margin-right:auto; display:block;" src="mol_editor/index.html"></iframe>
                </p>
            </b-modal>`,
        "props": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/SubSection.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/**
 * Setup the sub-section Vue commponent.
 * @returns void
 */
function SubSection_setup() {
    Vue.component('sub-section', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {};
        },
        "computed": {},
        "template": `
            <b-card :title="title" class="mb-4">
                <b-card-text style="margin-top: 16px;">
                    <slot></slot>
                </b-card-text>
            </b-card>
        `,
        "props": {
            "title": String
        }
    });
}

;// CONCATENATED MODULE: ./src/UI/VinaCommandline.ts
/* provided dependency */ var VinaCommandline_FileSaver = __webpack_require__(162);
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.

/** An object containing the vue-component computed functions. */
let VinaCommandline_computedFunctions = {
    /**
     * Determines whether the provided vina parameters validate.
     * @returns boolean  True if the validate, false otherwise.
     */
    "vinaParamsValidate"() {
        return Store_store.state["vinaParamsValidates"];
    },
    /**
     * Generates a mock vina command line.
     * @returns string  The mock command line.
     */
    "commandlineStr"() {
        // @ts-ignore
        if (this.vinaParamsValidate === false) {
            return "First fix parameter problems above...";
        }
        else {
            let params = Store_store.state["vinaParams"];
            const paramNames = Object.keys(params);
            const paramNamesLen = paramNames.length;
            const keyValPairs = [];
            for (let i = 0; i < paramNamesLen; i++) {
                const paramName = paramNames[i];
                const val = params[paramName];
                if ((val !== false) && (val !== null) && (val !== undefined)) {
                    let keyValPair = [paramName];
                    if (typeof (val) !== "boolean") {
                        keyValPair.push(val.toString());
                    }
                    else {
                        keyValPair.push("");
                    }
                    keyValPairs.push(keyValPair);
                }
            }
            keyValPairs.sort();
            let cmdStr = "";
            const keyValPairsLen = keyValPairs.length;
            for (let i = 0; i < keyValPairsLen; i++) {
                const keyValPair = keyValPairs[i];
                const paramName = keyValPair[0];
                const val = keyValPair[1];
                cmdStr = cmdStr + " --" + paramName;
                if (val !== "") {
                    cmdStr = cmdStr + " " + val.toString();
                }
            }
            return "/path/to/vina " +
                "--receptor " + Store_store.state["receptorFileName"] + " " +
                "--ligand " + Store_store.state["ligandFileName"] +
                cmdStr;
        }
    },
    /**
     * Gets the receptor file name from the VueX store.
     * @returns string  The receptor file name.
     */
    "receptorFileName"() {
        return Store_store.state["receptorFileName"];
    },
    /**
     * Gets the ligand file name from the VueX store.
     * @returns string  The ligand file name.
     */
    "ligandFileName"() {
        return Store_store.state["ligandFileName"];
    }
};
/** An object containing the vue-component methods functions. */
let VinaCommandline_methodsFunctions = {
    /**
     * Downloads either the receptor or ligand files.
     * @param  {*}      e     The click event.
     * @param  {string} type  The type of file, either "receptor" or "ligand".
     * @returns void
     */
    "downloadFile"(e, type) {
        let blob = new Blob([Store_store.state[type + "Contents"]], {
            type: "text/plain;charset=utf-8"
        });
        VinaCommandline_FileSaver.saveAs(blob, Store_store.state[type + "FileName"]);
        e.preventDefault();
        e.stopPropagation();
    }
};
/**
 * Setup the vina-commandline Vue commponent.
 * @returns void
 */
function VinaCommandline_setup() {
    Vue.component('vina-commandline', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data"() {
            return {};
        },
        "computed": VinaCommandline_computedFunctions,
        "methods": VinaCommandline_methodsFunctions,
        "template": `
            <sub-section v-if="vinaParamsValidate" title="Run Vina from the Command Line">
                <p>
                    Webina is convenient but slower than stand-alone Vina.
                    You may wish to <a href="http://vina.scripps.edu/download.html"
                    target="_blank">download a binary copy</a>
                    of Vina to run from the command line instead.
                </p>
                <form-group
                    id="input-group-commandline"
                    description="Type this into the command line (replacing the path) to run command-line Vina with your specified parameters."
                >
                    <b-form-input
                        name="commandline"
                        v-model="commandlineStr"
                        type="text"
                        readonly
                    ></b-form-input>

                    <template v-slot:extraDescription>
                        Click to download the <a href="" @click="downloadFile($event, 'receptor');">receptor</a>
                        and <a href="" @click="downloadFile($event, 'ligand');">ligand</a> PDBQT files.
                    </template>
                </form-group>
            </sub-section>
        `,
        "props": {}
    });
}

;// CONCATENATED MODULE: ./src/UI/Forms/FormButton.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.
/** An object containing the vue-component computed functions. */
let FormButton_computedFunctions = {
    /**
     * Determine which class to add to this button.
     * @returns string  The classes.
     */
    "classToUse"() {
        let classes = [this["cls"]];
        // @ts-ignore
        if (this["small"] === true) {
            classes.push("download-button float-right ml-1");
        }
        return classes.join(" ");
    },
    /**
     * Determine which button size to use.
     * @returns string  The size.
     */
    "sizeToUse"() {
        // @ts-ignore
        if (this["small"] === true) {
            return "sm";
        }
        return "";
    }
};
/**
 * Setup the form-button Vue commponent.
 * @returns void
 */
function FormButton_setup() {
    Vue.component('form-button', {
        /**
         * Get the data associated with this component.
         * @returns any  The data.
         */
        "data": function () {
            return {};
        },
        "computed": FormButton_computedFunctions,
        "template": `
            <b-button :pill="small" :size="sizeToUse" :class="classToUse" :variant="variant"><slot></slot></b-button>
        `,
        "props": {
            "variant": String,
            "cls": String,
            "small": {
                type: Boolean,
                default: false
            }
        }
    });
}

;// CONCATENATED MODULE: ./src/Vue/Setup.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.


















/**
 * Load and setup all Vue components.
 * @returns void
 */
function Setup_setup() {
    Vue.use(BootstrapVue);
    Vue.use(Vuex);
    SubSection_setup();
    FormButton_setup();
    VinaCommandline_setup();
    OpenModal_setup();
    ConvertFileModal_setup();
    DrawSmilesModal_setup();
    FormGroup_setup();
    setup();
    NumericInput_setup();
    TripleNumeric_setup();
    CheckBox_setup();
    FileInput_setup();
    ResultsTable_setup();
    VinaParams_setup();
    VinaRunning_setup();
    VinaOutput_setup();
    StartOver_setup();
    VinaExistingOutput_setup();
}

;// CONCATENATED MODULE: ./src/index.ts
// This file is part of Webina, released under the Apache 2.0 License. See
// LICENSE.md or go to https://opensource.org/licenses/Apache-2.0 for full
// details. Copyright 2020 Jacob D. Durrant.



console.log("Webina Web App " + VERSION);
Setup_setup();
UI_setup();
// If the url has "durrantlab" in it, contact google analytics. Logging all
// usage would be ideal for grant reporting, but some users may wish to run
// versions of webina on their own servers specifically to maintain privacy
// (e.g., in case of proprietary data). Calls to google analytics in such
// scenarios could be alarming, even though I'm only recording basic
// demographics anyway.
if (window.location.href.indexOf("durrantlab") !== -1) {
    setTimeout(() => {
        // Just to make sure it isn't blocking...
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments);
            }, i[r].l = 1 * new Date().getTime();
            // @ts-ignore
            a = s.createElement(o);
            // @ts-ignore
            m = s.getElementsByTagName(o)[0];
            // @ts-ignore
            a.async = 1;
            // @ts-ignore
            a.src = g;
            // @ts-ignore
            m.parentNode.insertBefore(a, m);
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-144382730-1', {
            'name': 'webina'
        });
        // UA-144382730-1 reports to pcaviz account.
        ga('webina.send', {
            "hitType": 'event',
            "eventCategory": 'webina',
            "eventAction": 'pageview',
            "eventLabel": window.location.href
        });
    }, 0);
}


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, [216], () => (__webpack_exec__(896)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);