"use strict";
(self["webpackChunkwebina"] = self["webpackChunkwebina"] || []).push([[584],{

/***/ "6UdS":
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "bebc927f1933c354483e.wasm";

/***/ })

}]);