declare module '*.txt'
